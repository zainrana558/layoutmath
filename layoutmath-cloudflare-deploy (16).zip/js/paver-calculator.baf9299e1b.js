/* Paver calculator — two-column layout (form LEFT, results RIGHT).
   Simplified inputs (radio toggle for area, paver size dropdown, pattern
   dropdown, optional price per paver, Calculate button). Results panel
   leads with PAVER COUNT, then base gravel and bedding sand estimates,
   then plain-English WHAT THIS MEANS and WHAT TO DO sections, and an
   optional COST line. Units are spelled out. No live updates. */
(function () {
  'use strict';

  // ---------- Unit conversion tables ----------
  // All inputs are converted to a common internal unit (feet for length,
  // square feet for area, cubic feet for volume). Results are converted out.

  // Length: factor to multiply by to get feet.
  var LEN_TO_FT = { ft: 1, m: 3.28084, yd: 3, in: 1 / 12, cm: 0.0328084 };
  // Area: factor to multiply by to get square feet.
  var AREA_TO_SQFT = { sqft: 1, sqm: 10.7639, sqyd: 9, acre: 43560 };
  // Square feet back to a target area unit.
  var SQFT_TO_AREA = { sqft: 1, sqm: 1 / 10.7639, sqyd: 1 / 9, acre: 1 / 43560 };
  var AREA_WORDS = {
    sqft: 'square feet', sqm: 'square meters',
    sqyd: 'square yards', acre: 'acres'
  };
  // Volume: factor to multiply cubic feet by to get cubic yards.
  var FT3_TO_YD3 = 1 / 27;

  // Paver sizes in inches (length × width). label is the friendly display.
  var PAVER_SIZES = {
    '4x8':   { l: 4,  w: 8,  label: '4\u00d78'   },
    '6x6':   { l: 6,  w: 6,  label: '6\u00d76'   },
    '12x12': { l: 12, w: 12, label: '12\u00d712' },
    '16x16': { l: 16, w: 16, label: '16\u00d716' },
    '24x24': { l: 24, w: 24, label: '24\u00d724' }
  };

  // Patterns: waste percent + display name.
  var PATTERNS = {
    running:     { waste: 5,  label: 'running bond'  },
    herringbone: { waste: 10, label: 'herringbone'   },
    basket:      { waste: 10, label: 'basket weave'  },
    straight:    { waste: 5,  label: 'straight'      }
  };

  // ---------- Helpers ----------
  function parseNum(str) {
    if (str == null) return null;
    var s = String(str).trim();
    if (!s) return null;
    // Allow $ and common unit suffixes / fraction chars.
    s = s.replace(/[$,\s]/g, '').replace(/[\u2032\u2019]/g, "'").replace(/[\u2033\u201c\u201d]/g, '"');
    s = s.replace(/\u00bd/g, ' 1/2').replace(/\u00bc/g, ' 1/4').replace(/\u00be/g, ' 3/4')
         .replace(/\u215b/g, ' 1/8').replace(/\u215c/g, ' 3/8').replace(/\u215d/g, ' 5/8').replace(/\u215e/g, ' 7/8')
         .replace(/\u2153/g, ' 1/3').replace(/\u2154/g, ' 2/3');
    // "5' 6"" style or "5-6" style — treat as feet+inches if it has ' and "
    var m = s.match(/^(-?\d+(?:\.\d+)?)['\u2032]\s*(\d+(?:\.\d+)?)["\u2033]$/);
    if (m) return Number(m[1]) * 12 + Number(m[2]);
    // Mixed fraction like "3 1/2"
    m = s.match(/^(-?\d+)\s+(\d+)\/(\d+)$/);
    if (m) {
      var d = Number(m[3]);
      if (d === 0) return null;
      return Number(m[1]) + Number(m[2]) / d;
    }
    // Simple fraction "3/4"
    m = s.match(/^(-?\d+)\/(\d+)$/);
    if (m) {
      var d2 = Number(m[2]);
      if (d2 === 0) return null;
      return Number(m[1]) / d2;
    }
    // Plain decimal
    if (!/^-?\d*\.?\d+$/.test(s)) return null;
    var n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  function fmt(n, d) {
    if (!Number.isFinite(n)) return '\u2014';
    return Number(n.toFixed(d)).toString();
  }

  function fmtMoney(n, cur) {
    if (!Number.isFinite(n)) return '\u2014';
    var sym = cur === 'GBP' ? '\u00a3' : cur === 'EUR' ? '\u20ac' : '$';
    return sym + n.toFixed(2);
  }

  // Money without trailing .00 — for per-unit prices ($40 not $40.00)
  function fmtMoneyPlain(n, cur) {
    if (!Number.isFinite(n)) return '\u2014';
    var sym = cur === 'GBP' ? '\u00a3' : cur === 'EUR' ? '\u20ac' : '$';
    return sym + (Number.isInteger(n) ? String(n) : n.toFixed(2));
  }

  function plural(n, sing) {
    return (n === 1) ? sing : sing + 's';
  }

  function describeAreaWords(value, unit) {
    var v = (unit === 'acre') ? fmt(value, 2)
            : (value >= 100 ? fmt(value, 0) : fmt(value, 1));
    return v + ' ' + AREA_WORDS[unit];
  }

  // ---------- DOM ----------
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  // ---------- Row management for "Enter dimensions" ----------
  var MAX_ROWS = 5;
  function rowTemplate(idx) {
    var wrap = document.createElement('div');
    wrap.className = 'scalc-row';
    wrap.setAttribute('data-row', '');
    wrap.innerHTML =
      '<div class="field"><label for="sc-len-' + idx + '">Length</label>' +
        '<div class="inp">' +
          '<input id="sc-len-' + idx + '" name="len' + idx + '" type="text" inputmode="decimal" autocomplete="off" spellcheck="false" value="">' +
          '<select class="sc-unit" name="lenUnit' + idx + '" aria-label="Length unit">' +
            '<option value="ft" selected>ft</option><option value="m">m</option><option value="yd">yd</option><option value="in">in</option><option value="cm">cm</option>' +
          '</select>' +
        '</div>' +
      '</div>' +
      '<span class="scalc-x" aria-hidden="true">\u00d7</span>' +
      '<div class="field"><label for="sc-wid-' + idx + '">Width</label>' +
        '<div class="inp">' +
          '<input id="sc-wid-' + idx + '" name="wid' + idx + '" type="text" inputmode="decimal" autocomplete="off" spellcheck="false" value="">' +
          '<select class="sc-unit" name="widUnit' + idx + '" aria-label="Width unit">' +
            '<option value="ft" selected>ft</option><option value="m">m</option><option value="yd">yd</option><option value="in">in</option><option value="cm">cm</option>' +
          '</select>' +
        '</div>' +
      '</div>' +
      '<button type="button" class="scalc-del needs-js" data-del aria-label="Remove this area">&times;</button>';
    return wrap;
  }

  function refreshRowsUI() {
    var rows = $all('.scalc-row', rowsEl);
    var n = rows.length;
    rows.forEach(function (r) {
      var del = r.querySelector('[data-del]');
      if (del) del.hidden = (n <= 1);
    });
    var addBtn = $('#sc-addrow');
    if (addBtn) addBtn.hidden = (n >= MAX_ROWS);
    var help = $('.scalc-rowhelp');
    if (help) help.hidden = (n < 2);
  }

  function addRow() {
    var rows = $all('.scalc-row', rowsEl);
    if (rows.length >= MAX_ROWS) return;
    var idx = rows.length;
    var newRow = rowTemplate(idx);
    rowsEl.appendChild(newRow);
    refreshRowsUI();
    var inp = newRow.querySelector('input');
    if (inp) inp.focus();
  }

  function removeRow(btn) {
    var row = btn.closest('.scalc-row');
    if (!row || $all('.scalc-row', rowsEl).length <= 1) return;
    row.remove();
    refreshRowsUI();
  }

  // ---------- Area mode toggle ----------
  function setMode(mode) {
    $all('.scalc-section', formEl).forEach(function (sec) {
      sec.hidden = (sec.getAttribute('data-mode') !== mode);
    });
  }

  // ---------- Compute area ----------
  function computeAreaSqft() {
    var mode = formEl.querySelector('input[name="areaMode"]:checked');
    mode = mode ? mode.value : 'total';
    if (mode === 'total') {
      var area = parseNum($('#sc-area').value);
      var areaUnit = formEl.querySelector('[name="areaUnit"]').value;
      if (area == null || area <= 0) return { ok: false, msg: 'Enter the area to pave.' };
      return {
        ok: true,
        sqft: area * AREA_TO_SQFT[areaUnit],
        describe: describeArea(area, areaUnit),
        primaryAreaValue: area,
        primaryAreaUnit: areaUnit
      };
    } else {
      var rows = $all('.scalc-row', rowsEl);
      var total = 0;
      var parts = [];
      var firstLenUnit = 'ft';
      for (var i = 0; i < rows.length; i++) {
        var len = parseNum(rows[i].querySelector('input[name^="len"]').value);
        var lenUnit = rows[i].querySelector('[name^="lenUnit"]').value;
        var wid = parseNum(rows[i].querySelector('input[name^="wid"]').value);
        var widUnit = rows[i].querySelector('[name^="widUnit"]').value;
        if (len == null || len <= 0 || wid == null || wid <= 0) {
          return { ok: false, msg: 'Enter length and width for every area.' };
        }
        var lf = len * LEN_TO_FT[lenUnit];
        var wf = wid * LEN_TO_FT[widUnit];
        total += lf * wf;
        parts.push(describeDim(len, lenUnit, wid, widUnit));
        if (i === 0) firstLenUnit = lenUnit;
      }
      var primaryAreaUnit = 'sqft';
      if (firstLenUnit === 'm' || firstLenUnit === 'cm') primaryAreaUnit = 'sqm';
      else if (firstLenUnit === 'yd') primaryAreaUnit = 'sqyd';
      var primaryAreaValue = total * SQFT_TO_AREA[primaryAreaUnit];
      return {
        ok: true,
        sqft: total,
        describe: parts.join(' + '),
        primaryAreaValue: primaryAreaValue,
        primaryAreaUnit: primaryAreaUnit
      };
    }
  }

  function describeArea(n, unit) {
    var labels = { sqft: 'ft\u00b2', sqm: 'm\u00b2', sqyd: 'yd\u00b2', acre: 'acres' };
    var v = (unit === 'acre') ? fmt(n, 2) : fmt(n, 0);
    return v + ' ' + labels[unit];
  }
  function describeDim(l, lu, w, wu) {
    var lbl = { ft: 'ft', m: 'm', yd: 'yd', in: 'in', cm: 'cm' };
    return fmt(l, 0) + lbl[lu] + ' \u00d7 ' + fmt(w, 0) + lbl[wu];
  }

  // ---------- Compute ----------
  function compute() {
    var areaRes = computeAreaSqft();
    if (!areaRes.ok) return areaRes;

    var paverSizeKey = $('#sc-paversize').value;
    var patternKey = $('#sc-pattern').value;
    var paver = PAVER_SIZES[paverSizeKey];
    var pattern = PATTERNS[patternKey];
    if (!paver || !pattern) return { ok: false, msg: 'Pick a paver size and pattern.' };

    // Optional price
    var priceInput = $('#sc-price');
    var price = parseNum(priceInput.value);
    var priceUnit = formEl.querySelector('[name="priceUnit"]').value;
    var hasPrice = (price != null && price >= 0 && priceInput.value.trim() !== '');

    // Paver area in square feet
    var paverAreaIn2 = paver.l * paver.w;
    var paverAreaSqft = paverAreaIn2 / 144;

    // Raw paver count (one paver covers paverAreaSqft)
    var rawPavers = areaRes.sqft / paverAreaSqft;
    // With waste, rounded up so a partial paver still gets bought
    var pavers = Math.ceil(rawPavers * (1 + pattern.waste / 100) - 1e-9);

    // Base gravel: 4 to 6 inches compacted gravel (compute both ends)
    var baseLowYd3  = areaRes.sqft * (4 / 12) * FT3_TO_YD3;
    var baseHighYd3 = areaRes.sqft * (6 / 12) * FT3_TO_YD3;
    // Bedding sand: 1 inch screeded
    var sandYd3 = areaRes.sqft * (1 / 12) * FT3_TO_YD3;

    // Cost
    var cost = null;
    if (hasPrice) {
      if (priceUnit === 'perpaver') cost = pavers * price;
      else if (priceUnit === 'persqft') cost = areaRes.sqft * price;
    }

    return {
      ok: true,
      pavers: pavers,
      rawPavers: rawPavers,
      baseLowYd3: baseLowYd3,
      baseHighYd3: baseHighYd3,
      sandYd3: sandYd3,
      cost: cost, hasPrice: hasPrice, price: price, priceUnit: priceUnit,
      paver: paver,
      pattern: pattern,
      areaDesc: areaRes.describe,
      primaryAreaValue: areaRes.primaryAreaValue,
      primaryAreaUnit: areaRes.primaryAreaUnit,
      sqft: areaRes.sqft
    };
  }

  // ---------- Render ----------
  // Simplified, calculator.net-style result panel:
  //   1. ONE plain-English sentence with the lead number bolded inline
  //   2. Optional cost line (only if a price was entered)
  //   3. "What this means" — 1-2 sentence explanation
  //   4. "What to do" — 4 short bullets (not numbered)
  function renderEmptyState() {
    outEl.innerHTML =
      '<div class="scalc-empty">' +
        '<p>Enter your area, paver size, and pattern, then click <b>Calculate</b>.</p>' +
        '<p>The answer will show:</p>' +
        '<ul>' +
          '<li>How many pavers to buy (with waste)</li>' +
          '<li>How much gravel and sand to order for the base</li>' +
          '<li>What that means in plain English</li>' +
          '<li>What to do next</li>' +
        '</ul>' +
      '</div>';
  }

  function render(r) {
    if (!r.ok) {
      outEl.innerHTML = '<p class="scalc-err">' + esc(r.msg) + '</p>';
      resultsEl.classList.add('calculated');
      hidePeek();
      if (liveEl) liveEl.textContent = r.msg;
      return;
    }

    var pavers = r.pavers;
    var paverWord = plural(pavers, 'paver');
    var areaPhrase = describeAreaWords(r.primaryAreaValue, r.primaryAreaUnit);
    var paverLabel = r.paver.label + ' in';
    var patternLabel = r.pattern.label;
    var waste = r.pattern.waste;

    var html = '';

    // --- 1. Plain-English answer sentence (leads with PAVER COUNT) ---
    html += '<p class="scalc-answer">';
    html += 'You need about <span class="num">' + pavers + ' ' + esc(paverWord) + '</span> ' +
            '(' + esc(paverLabel) + ', ' + esc(patternLabel) + ', with ' + waste + ' percent extra).';
    html += '</p>';

    // --- 2. Cost line (only if a price was entered) ---
    if (r.hasPrice && r.cost != null) {
      var priceUnitWord = r.priceUnit === 'perpaver' ? 'paver' : 'square foot';
      html += '<p class="scalc-cost-line">At ' + esc(fmtMoneyPlain(r.price, 'USD')) + ' per ' +
              esc(priceUnitWord) + ', the total cost is about <strong>' +
              esc(fmtMoney(r.cost, 'USD')) + '</strong>.</p>';
    }

    // --- 3. What this means ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What this means</h4>';
    var meaning = 'Covering ' + esc(areaPhrase) + ' with ' + esc(paverLabel) + ' pavers in a ' +
                  esc(patternLabel) + ' pattern uses this many pavers, with ' + waste +
                  ' percent extra for cuts and waste. Underneath, plan on ' +
                  fmt(r.baseLowYd3, 2) + ' to ' + fmt(r.baseHighYd3, 2) +
                  ' cubic yards of compacted gravel for the base, and ' +
                  fmt(r.sandYd3, 2) + ' cubic yards of bedding sand.';
    html += '<p class="scalc-meaning">' + meaning + '</p>';

    // --- 4. What to do (bullets, not numbered) ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What to do</h4>';
    html += '<ul class="scalc-todo">';
    html += '<li>Buy ' + pavers + ' ' + esc(paverWord) + ' (' + esc(paverLabel) + ') plus ' +
            waste + ' percent extra for cuts and waste</li>';
    html += '<li>Lay 4 to 6 inches of compacted gravel base, then 1 inch of screeded bedding sand</li>';
    html += '<li>Set pavers in the ' + esc(patternLabel) + ' pattern, tapping with a rubber mallet</li>';
    html += '<li>Sweep polymeric sand into the joints and mist with water to harden</li>';
    html += '</ul>';

    outEl.innerHTML = html;
    resultsEl.classList.add('calculated');

    // Peek button (floating "jump to result" bar)
    showPeek(pavers + ' ' + paverWord);

    // SR live region — short summary
    if (liveEl) {
      liveEl.textContent = 'You need about ' + pavers + ' ' + paverWord +
                           ' (' + paverLabel + ', ' + patternLabel + ').';
    }
  }

  // ---------- Peek button ----------
  function showPeek(text) {
    if (!peekEl) return;
    var pv = $('.pv', peekEl);
    if (pv) pv.textContent = text;
    peekEl.removeAttribute('hidden');
    peekEl.classList.add('on');
  }
  function hidePeek() {
    if (!peekEl) return;
    peekEl.setAttribute('hidden', '');
    peekEl.classList.remove('on');
  }

  function clearResults() {
    resultsEl.classList.remove('calculated');
    renderEmptyState();
    hidePeek();
    if (liveEl) liveEl.textContent = '';
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ---------- Reset ----------
  function resetForm() {
    // Defaults match the static worked example.
    $('#sc-area').value = '200';
    formEl.querySelector('[name="areaUnit"]').value = 'sqft';
    var rows = $all('.scalc-row', rowsEl);
    for (var i = 1; i < rows.length; i++) rows[i].remove();
    var firstRow = rows[0];
    if (firstRow) {
      firstRow.querySelector('input[name^="len"]').value = '20';
      firstRow.querySelector('[name^="lenUnit"]').value = 'ft';
      firstRow.querySelector('input[name^="wid"]').value = '10';
      firstRow.querySelector('[name^="widUnit"]').value = 'ft';
    }
    $('#sc-paversize').value = '4x8';
    $('#sc-pattern').value = 'running';
    $('#sc-price').value = '';
    formEl.querySelector('[name="priceUnit"]').value = 'perpaver';
    var totalRadio = formEl.querySelector('input[name="areaMode"][value="total"]');
    if (totalRadio) totalRadio.checked = true;
    setMode('total');
    refreshRowsUI();
    clearResults();
  }

  // ---------- Init ----------
  var formEl, rowsEl, resultsEl, outEl, liveEl, peekEl;

  function init() {
    formEl = document.getElementById('calc');
    rowsEl = document.getElementById('sc-rows');
    resultsEl = document.getElementById('results');
    outEl = document.getElementById('out');
    liveEl = document.getElementById('live');
    peekEl = document.getElementById('peek');
    if (!formEl || !resultsEl || !outEl) return;

    // Initial UI state
    refreshRowsUI();

    // Show the friendly empty state in the results panel until Calculate is clicked.
    // (For noscript users, the static worked-example markup remains visible.)
    resultsEl.classList.remove('calculated');
    renderEmptyState();

    // Radio toggle for area mode
    formEl.addEventListener('change', function (e) {
      if (e.target.name === 'areaMode') {
        setMode(e.target.value);
      }
    });

    // Add another area row
    var addBtn = document.getElementById('sc-addrow');
    if (addBtn) addBtn.addEventListener('click', addRow);

    // Remove a row (event delegation)
    rowsEl.addEventListener('click', function (e) {
      var del = e.target.closest('[data-del]');
      if (del) removeRow(del);
    });

    // Calculate / submit
    formEl.addEventListener('submit', function (e) {
      e.preventDefault();
      var r = compute();
      render(r);
      // Scroll the results into view (gentle, only if off-screen)
      if (resultsEl.classList.contains('calculated')) {
        var rect = resultsEl.getBoundingClientRect();
        if (rect.bottom > window.innerHeight || rect.top < 0) {
          resultsEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }
    });

    // Clear button
    var clearBtn = document.getElementById('sc-clear');
    if (clearBtn) clearBtn.addEventListener('click', function () {
      resetForm();
    });

    // Peek button — clicking scrolls to the result
    if (peekEl) {
      peekEl.addEventListener('click', function () {
        if (resultsEl) resultsEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
