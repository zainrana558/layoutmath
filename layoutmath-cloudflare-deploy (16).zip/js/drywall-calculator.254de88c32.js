/* Drywall calculator — two-column layout (form LEFT, results RIGHT).
   Simplified inputs (radio toggle for total area vs dimensions, sheet size
   dropdown, optional price per sheet). Results panel leads with SHEET COUNT,
   gives equivalent area, then plain-English WHAT THIS MEANS and WHAT TO DO
   sections, and an optional COST line. Standard US sheet sizes: 4x8, 4x10, 4x12.
   10% waste for cuts and offcuts is always applied. No live updates. */
(function () {
  'use strict';

  // ---------- Unit conversion tables ----------
  // All inputs are converted to a common internal unit (square feet for area).
  // Length conversions are only used for the dimensions mode.

  // Length: factor to multiply by to get feet.
  var LEN_TO_FT = { ft: 1, m: 3.28084, yd: 3, in: 1 / 12, cm: 0.0328084 };
  // Area: factor to multiply by to get square feet.
  var AREA_TO_SQFT = { sqft: 1, sqm: 10.7639, sqyd: 9 };

  // Standard drywall sheet sizes (US): 4 ft wide × 8/10/12 ft long.
  var SHEET_SIZES = {
    '4x8':  { label: '4 \u00d7 8 feet',  area: 32, short: '4\u00d78' },
    '4x10': { label: '4 \u00d7 10 feet', area: 40, short: '4\u00d710' },
    '4x12': { label: '4 \u00d7 12 feet', area: 48, short: '4\u00d712' }
  };

  // Waste factor: 10% for walls (cuts, mistakes, damaged edges).
  var WASTE_PCT = 10;

  // ---------- Helpers ----------
  function parseNum(str) {
    if (str == null) return null;
    var s = String(str).trim();
    if (!s) return null;
    s = s.replace(/[$,\s]/g, '').replace(/[\u2032\u2019]/g, "'").replace(/[\u2033\u201c\u201d]/g, '"');
    s = s.replace(/\u00bd/g, ' 1/2').replace(/\u00bc/g, ' 1/4').replace(/\u00be/g, ' 3/4')
         .replace(/\u215b/g, ' 1/8').replace(/\u215e/g, ' 3/8').replace(/\u215d/g, ' 5/8').replace(/\u215f/g, ' 7/8')
         .replace(/\u2153/g, ' 1/3').replace(/\u2154/g, ' 2/3');
    // "5' 6"" style
    var m = s.match(/^(-?\d+(?:\.\d+)?)['\u2032]\s*(\d+(?:\.\d+)?)["\u2033]$/);
    if (m) return Number(m[1]) * 12 + Number(m[2]);
    // Mixed fraction like "3 1/2"
    m = s.match(/^(-?\d+)\s+(\d+)\/(\d+)$/);
    if (m) {
      var d = Number(m[3]);
      if (d === 0) return null;
      return Number(m[1]) + Number(m[2]) / d;
    }
    // Simple fraction "3/4"
    m = s.match(/^(-?\d+)\/(\d+)$/);
    if (m) {
      var d2 = Number(m[2]);
      if (d2 === 0) return null;
      return Number(m[1]) / d2;
    }
    if (!/^-?\d*\.?\d+$/.test(s)) return null;
    var n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  function fmt(n, d) {
    if (!Number.isFinite(n)) return '\u2014';
    return Number(n.toFixed(d)).toString();
  }

  function fmtMoney(n) {
    if (!Number.isFinite(n)) return '\u2014';
    return '$' + n.toFixed(2);
  }

  function fmtMoneyPlain(n) {
    if (!Number.isFinite(n)) return '\u2014';
    return '$' + (Number.isInteger(n) ? String(n) : n.toFixed(2));
  }

  function plural(n, sing) {
    return (n === 1) ? sing : sing + 's';
  }

  // Square feet back to a target area unit.
  var SQFT_TO_AREA = { sqft: 1, sqm: 1 / 10.7639, sqyd: 1 / 9 };
  var AREA_WORDS = { sqft: 'square feet', sqm: 'square meters', sqyd: 'square yards' };
  var AREA_SHORT = { sqft: 'ft\u00b2', sqm: 'm\u00b2', sqyd: 'yd\u00b2' };

  function describeAreaWords(value, unit) {
    var v = (value >= 100 ? fmt(value, 0) : fmt(value, 1));
    return v + ' ' + AREA_WORDS[unit];
  }

  function describeAreaShort(value, unit) {
    var v = (value >= 100 ? fmt(value, 0) : fmt(value, 1));
    return v + ' ' + AREA_SHORT[unit];
  }

  // ---------- DOM ----------
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  // ---------- Row management for "Enter dimensions" ----------
  var MAX_ROWS = 5;
  function rowTemplate(idx) {
    var wrap = document.createElement('div');
    wrap.className = 'scalc-row';
    wrap.setAttribute('data-row', '');
    wrap.innerHTML =
      '<div class="field"><label for="sc-len-' + idx + '">Length</label>' +
        '<div class="inp">' +
          '<input id="sc-len-' + idx + '" name="len' + idx + '" type="text" inputmode="decimal" autocomplete="off" spellcheck="false" value="">' +
          '<select class="sc-unit" name="lenUnit' + idx + '" aria-label="Length unit">' +
            '<option value="ft" selected>ft</option><option value="m">m</option><option value="yd">yd</option><option value="in">in</option><option value="cm">cm</option>' +
          '</select>' +
        '</div>' +
      '</div>' +
      '<span class="scalc-x" aria-hidden="true">\u00d7</span>' +
      '<div class="field"><label for="sc-wid-' + idx + '">Width</label>' +
        '<div class="inp">' +
          '<input id="sc-wid-' + idx + '" name="wid' + idx + '" type="text" inputmode="decimal" autocomplete="off" spellcheck="false" value="">' +
          '<select class="sc-unit" name="widUnit' + idx + '" aria-label="Width unit">' +
            '<option value="ft" selected>ft</option><option value="m">m</option><option value="yd">yd</option><option value="in">in</option><option value="cm">cm</option>' +
          '</select>' +
        '</div>' +
      '</div>' +
      '<button type="button" class="scalc-del needs-js" data-del aria-label="Remove this area">&times;</button>';
    return wrap;
  }

  function refreshRowsUI() {
    var rows = $all('.scalc-row', rowsEl);
    var n = rows.length;
    rows.forEach(function (r) {
      var del = r.querySelector('[data-del]');
      if (del) del.hidden = (n <= 1);
    });
    var addBtn = $('#sc-addrow');
    if (addBtn) addBtn.hidden = (n >= MAX_ROWS);
    var help = $('.scalc-rowhelp');
    if (help) help.hidden = (n < 2);
  }

  function addRow() {
    var rows = $all('.scalc-row', rowsEl);
    if (rows.length >= MAX_ROWS) return;
    var idx = rows.length;
    var newRow = rowTemplate(idx);
    rowsEl.appendChild(newRow);
    refreshRowsUI();
    var inp = newRow.querySelector('input');
    if (inp) inp.focus();
  }

  function removeRow(btn) {
    var row = btn.closest('.scalc-row');
    if (!row || $all('.scalc-row', rowsEl).length <= 1) return;
    row.remove();
    refreshRowsUI();
  }

  // ---------- Area mode toggle ----------
  function setMode(mode) {
    $all('.scalc-section', formEl).forEach(function (sec) {
      sec.hidden = (sec.getAttribute('data-mode') !== mode);
    });
  }

  // ---------- Compute ----------
  function computeAreaSqft() {
    var mode = formEl.querySelector('input[name="areaMode"]:checked');
    mode = mode ? mode.value : 'total';
    if (mode === 'total') {
      var area = parseNum($('#sc-area').value);
      var areaUnit = formEl.querySelector('[name="areaUnit"]').value;
      if (area == null || area <= 0) return { ok: false, msg: 'Enter the area to cover.' };
      return {
        ok: true,
        sqft: area * AREA_TO_SQFT[areaUnit],
        describe: describeArea(area, areaUnit),
        primaryAreaValue: area,
        primaryAreaUnit: areaUnit
      };
    } else {
      var rows = $all('.scalc-row', rowsEl);
      var total = 0;
      var parts = [];
      var firstLenUnit = 'ft';
      for (var i = 0; i < rows.length; i++) {
        var len = parseNum(rows[i].querySelector('input[name^="len"]').value);
        var lenUnit = rows[i].querySelector('[name^="lenUnit"]').value;
        var wid = parseNum(rows[i].querySelector('input[name^="wid"]').value);
        var widUnit = rows[i].querySelector('[name^="widUnit"]').value;
        if (len == null || len <= 0 || wid == null || wid <= 0) {
          return { ok: false, msg: 'Enter length and width for every area.' };
        }
        var lf = len * LEN_TO_FT[lenUnit];
        var wf = wid * LEN_TO_FT[widUnit];
        total += lf * wf;
        parts.push(describeDim(len, lenUnit, wid, widUnit));
        if (i === 0) firstLenUnit = lenUnit;
      }
      var primaryAreaUnit = 'sqft';
      if (firstLenUnit === 'm' || firstLenUnit === 'cm') primaryAreaUnit = 'sqm';
      else if (firstLenUnit === 'yd') primaryAreaUnit = 'sqyd';
      var primaryAreaValue = total * SQFT_TO_AREA[primaryAreaUnit];
      return {
        ok: true,
        sqft: total,
        describe: parts.join(' + '),
        primaryAreaValue: primaryAreaValue,
        primaryAreaUnit: primaryAreaUnit
      };
    }
  }

  function describeArea(n, unit) {
    var v = fmt(n, 0);
    return v + ' ' + AREA_SHORT[unit];
  }
  function describeDim(l, lu, w, wu) {
    var lbl = { ft: 'ft', m: 'm', yd: 'yd', in: 'in', cm: 'cm' };
    return fmt(l, 0) + lbl[lu] + ' \u00d7 ' + fmt(w, 0) + lbl[wu];
  }

  function compute() {
    var areaRes = computeAreaSqft();
    if (!areaRes.ok) return areaRes;

    // Sheet size
    var sheetKey = formEl.querySelector('[name="sheetSize"]').value;
    var sheet = SHEET_SIZES[sheetKey] || SHEET_SIZES['4x8'];
    var sheetArea = sheet.area;       // sq ft per sheet
    var sheetLabel = sheet.label;     // "4 × 8 ft"

    // Optional price per sheet
    var priceInput = $('#sc-price');
    var price = parseNum(priceInput.value);
    var hasPrice = (price != null && price >= 0 && priceInput.value.trim() !== '');

    // Sheet count: ceil(area * (1 + waste%) / sheetArea)
    var netArea = areaRes.sqft;
    var grossArea = netArea * (1 + WASTE_PCT / 100);
    var sheets = Math.ceil(grossArea / sheetArea - 1e-9);

    // Cost
    var cost = null;
    if (hasPrice) cost = sheets * price;

    return {
      ok: true,
      sheets: sheets,
      sheetArea: sheetArea,
      sheetLabel: sheetLabel,
      netArea: netArea,
      grossArea: grossArea,
      wastePct: WASTE_PCT,
      cost: cost,
      hasPrice: hasPrice,
      price: price,
      areaDesc: areaRes.describe,
      primaryAreaValue: areaRes.primaryAreaValue,
      primaryAreaUnit: areaRes.primaryAreaUnit
    };
  }

  // ---------- Render ----------
  // Simplified, calculator.net-style result panel:
  //   1. ONE plain-English sentence with the lead number (sheets) bolded inline
  //   2. Optional cost line (only if a price was entered)
  //   3. "What this means" — 1-2 sentence explanation
  //   4. "What to do" — 4 short bullets
  // No stat cards. No competing big numbers. Just clean text.
  function renderEmptyState() {
    outEl.innerHTML =
      '<div class="scalc-empty">' +
        '<p>Enter your area and sheet size, then click <b>Calculate</b>.</p>' +
        '<p>The answer will show:</p>' +
        '<ul>' +
          '<li>How many drywall sheets to buy</li>' +
          '<li>What that means in plain English</li>' +
          '<li>What to do next</li>' +
        '</ul>' +
      '</div>';
  }

  function render(r) {
    if (!r.ok) {
      outEl.innerHTML = '<p class="scalc-err">' + esc(r.msg) + '</p>';
      resultsEl.classList.add('calculated');
      if (liveEl) liveEl.textContent = r.msg;
      return;
    }

    var sheets = r.sheets;
    var sheetWord = plural(sheets, 'sheet');
    var areaPhrase = describeAreaWords(r.primaryAreaValue, r.primaryAreaUnit);   // "200 square feet"
    var sheetLabel = r.sheetLabel; // "4 × 8 ft"

    var html = '';

    // --- 1. Plain-English answer sentence (LEAD WITH SHEET COUNT) ---
    html += '<p class="scalc-answer">';
    html += 'Covering ' + esc(areaPhrase) + ' with ' + esc(sheetLabel) + ' drywall sheets uses ' +
            '<span class="num">' + sheets + ' ' + esc(sheetWord) + '</span>, ' +
            'with ' + r.wastePct + ' percent extra for cuts and waste.';
    html += '</p>';

    // --- 2. Cost line (only if a price was entered) ---
    if (r.hasPrice && r.cost != null) {
      html += '<p class="scalc-cost-line">At ' + esc(fmtMoneyPlain(r.price)) + ' per sheet, ' +
              'the total cost is about <strong>' + esc(fmtMoney(r.cost)) + '</strong>.</p>';
    }

    // --- 3. What this means ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What this means</h4>';
    var meaning = 'A ' + esc(areaPhrase) + ' area takes ' + sheets + ' ' + esc(sheetWord) + ' of ' +
                  esc(sheetLabel) + ' drywall, once the area is rounded up to whole sheets and ' +
                  r.wastePct + ' percent is added for cuts and waste.';
    html += '<p class="scalc-meaning">' + meaning + '</p>';

    // --- 4. What to do (bullets, not numbered) ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What to do</h4>';
    html += '<ul class="scalc-todo">';
    html += '<li>Buy ' + sheets + ' ' + esc(sheetWord) + ' (' + esc(sheetLabel) + ') plus ' +
            r.wastePct + ' percent extra for cuts and waste</li>';
    html += '<li>Hang sheets perpendicular to framing, screws every 8 inches on walls, 12 inches on ceilings</li>';
    html += '<li>Stagger joints between rows &mdash; don\u2019t create a continuous seam</li>';
    html += '<li>Tape and mud all joints, then sand smooth before painting</li>';
    html += '</ul>';

    outEl.innerHTML = html;
    resultsEl.classList.add('calculated');

    // SR live region — short summary
    if (liveEl) {
      liveEl.textContent = 'You need about ' + sheets + ' ' + sheetWord + ' of drywall.';
    }
  }

  function clearResults() {
    resultsEl.classList.remove('calculated');
    renderEmptyState();
    if (liveEl) liveEl.textContent = '';
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ---------- Reset ----------
  function resetForm() {
    // Defaults match the static worked example.
    $('#sc-area').value = '200';
    formEl.querySelector('[name="areaUnit"]').value = 'sqft';
    var rows = $all('.scalc-row', rowsEl);
    for (var i = 1; i < rows.length; i++) rows[i].remove();
    var firstRow = rows[0];
    if (firstRow) {
      firstRow.querySelector('input[name^="len"]').value = '20';
      firstRow.querySelector('[name^="lenUnit"]').value = 'ft';
      firstRow.querySelector('input[name^="wid"]').value = '10';
      firstRow.querySelector('[name^="widUnit"]').value = 'ft';
    }
    formEl.querySelector('[name="sheetSize"]').value = '4x8';
    $('#sc-price').value = '';
    var totalRadio = formEl.querySelector('input[name="areaMode"][value="total"]');
    if (totalRadio) totalRadio.checked = true;
    setMode('total');
    refreshRowsUI();
    clearResults();
  }

  // ---------- Init ----------
  var formEl, rowsEl, resultsEl, outEl, liveEl;

  function init() {
    formEl = document.getElementById('calc');
    rowsEl = document.getElementById('sc-rows');
    resultsEl = document.getElementById('results');
    outEl = document.getElementById('out');
    liveEl = document.getElementById('live');
    if (!formEl || !resultsEl || !outEl) return;

    refreshRowsUI();

    resultsEl.classList.remove('calculated');
    renderEmptyState();

    // Radio toggle for area mode
    formEl.addEventListener('change', function (e) {
      if (e.target.name === 'areaMode') {
        setMode(e.target.value);
      }
    });

    // Add another area row
    var addBtn = document.getElementById('sc-addrow');
    if (addBtn) addBtn.addEventListener('click', addRow);

    // Remove a row (event delegation)
    rowsEl.addEventListener('click', function (e) {
      var del = e.target.closest('[data-del]');
      if (del) removeRow(del);
    });

    // Calculate / submit
    formEl.addEventListener('submit', function (e) {
      e.preventDefault();
      var r = compute();
      render(r);
      if (resultsEl.classList.contains('calculated')) {
        var rect = resultsEl.getBoundingClientRect();
        if (rect.bottom > window.innerHeight || rect.top < 0) {
          resultsEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }
    });

    // Clear button
    var clearBtn = document.getElementById('sc-clear');
    if (clearBtn) clearBtn.addEventListener('click', function () {
      resetForm();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
