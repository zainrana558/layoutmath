/* French drain calculator — two-column layout (form LEFT, results RIGHT).
   Simplified inputs: trench length, width, depth (with per-input unit
   dropdowns) + Calculate button. Results panel leads with cubic yards of
   gravel + feet of perforated pipe, then plain-English WHAT THIS MEANS and
   WHAT TO DO sections, and an optional COST line. Units are spelled out.
   No live updates. */
(function () {
  'use strict';

  // ---------- Unit conversion tables ----------
  // All inputs are converted to a common internal unit (feet for length, width
  // and depth). Results are converted out.

  // Length / width: factor to multiply by to get feet.
  var LEN_TO_FT = { ft: 1, m: 3.28084, yd: 3, in: 1 / 12, cm: 0.0328084 };
  // Depth: factor to multiply by to get feet.
  var DEPTH_TO_FT = { in: 1 / 12, cm: 0.0328084, ft: 1, m: 3.28084, yd: 3 };
  // Volume: factor to multiply cubic feet by to get target.
  var FT3_TO_YD3 = 1 / 27;
  var FT3_TO_M3 = 0.0283168;
  var FT_TO_M = 0.3048;

  // ---------- Helpers ----------
  function parseNum(str) {
    if (str == null) return null;
    var s = String(str).trim();
    if (!s) return null;
    // Allow $ and common unit suffixes / fraction chars.
    s = s.replace(/[$,\s]/g, '').replace(/[′’]/g, "'").replace(/[″“”]/g, '"');
    s = s.replace(/½/g, ' 1/2').replace(/¼/g, ' 1/4').replace(/¾/g, ' 3/4')
         .replace(/⅛/g, ' 1/8').replace(/⅜/g, ' 3/8').replace(/⅝/g, ' 5/8').replace(/⅞/g, ' 7/8')
         .replace(/⅓/g, ' 1/3').replace(/⅔/g, ' 2/3');
    // "5' 6"" style — treat as feet+inches if it has ' and "
    var m = s.match(/^(-?\d+(?:\.\d+)?)['′]\s*(\d+(?:\.\d+)?)["″]$/);
    if (m) return Number(m[1]) * 12 + Number(m[2]);
    // Mixed fraction like "3 1/2"
    m = s.match(/^(-?\d+)\s+(\d+)\/(\d+)$/);
    if (m) {
      var d = Number(m[3]);
      if (d === 0) return null;
      return Number(m[1]) + Number(m[2]) / d;
    }
    // Simple fraction "3/4"
    m = s.match(/^(-?\d+)\/(\d+)$/);
    if (m) {
      var d2 = Number(m[2]);
      if (d2 === 0) return null;
      return Number(m[1]) / d2;
    }
    // Plain decimal
    if (!/^-?\d*\.?\d+$/.test(s)) return null;
    var n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  function fmt(n, d) {
    if (!Number.isFinite(n)) return '—';
    return Number(n.toFixed(d)).toString();
  }

  function fmtMoney(n, cur) {
    if (!Number.isFinite(n)) return '—';
    var sym = cur === 'GBP' ? '£' : cur === 'EUR' ? '€' : '$';
    return sym + n.toFixed(2);
  }

  // Money without trailing .00 — for per-unit prices ($40 not $40.00)
  function fmtMoneyPlain(n, cur) {
    if (!Number.isFinite(n)) return '—';
    var sym = cur === 'GBP' ? '£' : cur === 'EUR' ? '€' : '$';
    return sym + (Number.isInteger(n) ? String(n) : n.toFixed(2));
  }

  var PRICE_WORDS = {
    peryd3: 'cubic yard', perft: 'foot of pipe'
  };

  // e.g. "50 feet", "1 foot", "12 inches", "1 inch", "15 meters", "30 cm"
  function lenNoun(n, unit) {
    var v = (unit === 'in' || unit === 'cm') ? fmt(n, 1) : fmt(n, 2);
    var lbl = { in: 'inches', cm: 'cm', ft: 'feet', m: 'meters', yd: 'yards' }[unit] || unit;
    if (Number(v) === 1) {
      lbl = { in: 'inch', cm: 'cm', ft: 'foot', m: 'meter', yd: 'yard' }[unit] || unit;
    }
    return v + ' ' + lbl;
  }

  // Adjective form: e.g. "50 foot", "12 inch", "4 inch" (always singular).
  function lenAdj(n, unit) {
    var v = (unit === 'in' || unit === 'cm') ? fmt(n, 1) : fmt(n, 2);
    var lbl = { in: 'inch', cm: 'cm', ft: 'foot', m: 'meter', yd: 'yard' }[unit] || unit;
    return v + ' ' + lbl;
  }

  // ---------- DOM ----------
  function $(sel, root) { return (root || document).querySelector(sel); }

  // ---------- Compute ----------
  function compute() {
    var len = parseNum($('#sc-len').value);
    var lenUnit = formEl.querySelector('[name="lenUnit"]').value;
    var wid = parseNum($('#sc-wid').value);
    var widUnit = formEl.querySelector('[name="widUnit"]').value;
    var dep = parseNum($('#sc-depth').value);
    var depUnit = formEl.querySelector('[name="depthUnit"]').value;

    if (len == null || len <= 0) return { ok: false, msg: 'Enter the trench length.' };
    if (wid == null || wid <= 0) return { ok: false, msg: 'Enter the trench width.' };
    if (dep == null || dep <= 0) return { ok: false, msg: 'Enter the trench depth.' };

    // Optional price
    var priceInput = $('#sc-price');
    var price = parseNum(priceInput.value);
    var priceUnit = formEl.querySelector('[name="priceUnit"]').value;
    var hasPrice = (price != null && price >= 0 && priceInput.value.trim() !== '');

    // Convert to feet
    var lenFt = len * LEN_TO_FT[lenUnit];
    var widFt = wid * LEN_TO_FT[widUnit];
    var depFt = dep * DEPTH_TO_FT[depUnit];

    // Trench volume in cubic feet, gravel in cubic yards / cubic meters
    var trenchFt3 = lenFt * widFt * depFt;
    var gravelYd3 = trenchFt3 * FT3_TO_YD3;
    var gravelM3 = trenchFt3 * FT3_TO_M3;

    // Pipe length = trench length (4 inch / 100 mm perforated pipe)
    var pipeLenFt = lenFt;
    var pipeLenM = lenFt * FT_TO_M;

    // Cost
    var cost = null;
    if (hasPrice) {
      if (priceUnit === 'peryd3') cost = gravelYd3 * price;
      else if (priceUnit === 'perft') cost = pipeLenFt * price;
    }

    // Detect metric: any input unit in m or cm
    var isMetric = (lenUnit === 'm' || lenUnit === 'cm' ||
                    widUnit === 'm' || widUnit === 'cm' ||
                    depUnit === 'm' || depUnit === 'cm');

    return {
      ok: true,
      gravelYd3: gravelYd3,
      gravelM3: gravelM3,
      trenchFt3: trenchFt3,
      pipeLenFt: pipeLenFt,
      pipeLenM: pipeLenM,
      cost: cost,
      hasPrice: hasPrice,
      price: price,
      priceUnit: priceUnit,
      isMetric: isMetric,
      lenValue: len, lenUnit: lenUnit,
      widValue: wid, widUnit: widUnit,
      depValue: dep, depUnit: depUnit
    };
  }

  // ---------- Render ----------
  // Simplified, calculator.net-style result panel:
  //   1. ONE plain-English sentence with the lead number bolded inline
  //   2. Optional cost line (only if a price was entered)
  //   3. "What this means" — 1-2 sentence explanation
  //   4. "What to do" — 4 short bullets (not numbered)
  function renderEmptyState() {
    outEl.innerHTML =
      '<div class="scalc-empty">' +
        '<p>Enter your trench length, width and depth, then click <b>Calculate</b>.</p>' +
        '<p>The answer will show:</p>' +
        '<ul>' +
          '<li>How many cubic yards of gravel to order</li>' +
          '<li>How many feet of perforated pipe to buy</li>' +
          '<li>What that means in plain English</li>' +
          '<li>What to do next</li>' +
        '</ul>' +
      '</div>';
  }

  function render(r) {
    if (!r.ok) {
      outEl.innerHTML = '<p class="scalc-err">' + esc(r.msg) + '</p>';
      resultsEl.classList.add('calculated');
      if (liveEl) liveEl.textContent = r.msg;
      return;
    }

    var gravelYd3 = r.gravelYd3;
    var gravelM3 = r.gravelM3;
    var pipeLenFt = r.pipeLenFt;
    var pipeLenM = r.pipeLenM;
    var isMetric = r.isMetric;

    // Length, width, depth phrases in the user's chosen units
    var lenNounPhrase = lenNoun(r.lenValue, r.lenUnit);   // "50 feet" or "15 meters"
    var lenAdjPhrase  = lenAdj(r.lenValue, r.lenUnit);    // "50 foot" or "15 meter"
    var widNounPhrase = lenNoun(r.widValue, r.widUnit);   // "12 inches" or "30 cm"
    var depNounPhrase = lenNoun(r.depValue, r.depUnit);   // "18 inches" or "45 cm"

    // Pipe length phrase — use the user's length unit so it matches the trench
    // length they entered (e.g. "50 feet" or "15 meters").
    var pipeLenPhrase = isMetric
      ? fmt(pipeLenM, 1) + ' meters'
      : fmt(pipeLenFt, 0) + ' feet';

    // Pipe diameter phrase — "4 inch" (imperial) or "100 mm" (metric)
    var pipeDiaPhrase = isMetric ? '100 mm' : '4 inch';

    var html = '';

    // --- 1. Plain-English answer sentence ---
    html += '<p class="scalc-answer">';
    if (isMetric) {
      html += 'You need about <span class="num">' + fmt(gravelM3, 2) + ' cubic meters</span> of gravel and ' +
              esc(pipeLenPhrase) + ' of ' + esc(pipeDiaPhrase) + ' perforated pipe.';
    } else {
      html += 'You need about <span class="num">' + fmt(gravelYd3, 2) + ' cubic yards</span> of gravel and ' +
              esc(pipeLenPhrase) + ' of ' + esc(pipeDiaPhrase) + ' perforated pipe.';
    }
    html += '</p>';

    // --- 2. Cost line (only if a price was entered) ---
    if (r.hasPrice && r.cost != null) {
      html += '<p class="scalc-cost-line">At ' + esc(fmtMoneyPlain(r.price, 'USD')) + ' per ' +
              esc(PRICE_WORDS[r.priceUnit] || r.priceUnit) + ', the total cost is about <strong>' +
              esc(fmtMoney(r.cost, 'USD')) + '</strong>.</p>';
    }

    // --- 3. What this means ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What this means</h4>';
    var meaning;
    if (isMetric) {
      meaning = 'A ' + esc(lenAdjPhrase) + ' trench at ' + esc(widNounPhrase) + ' wide and ' + esc(depNounPhrase) +
                ' deep needs ' + fmt(gravelM3, 2) + ' cubic meters of gravel and ' + esc(pipeLenPhrase) +
                ' of ' + esc(pipeDiaPhrase) + ' perforated pipe. The trench should slope 1 cm per meter for drainage.';
    } else {
      meaning = 'A ' + esc(lenAdjPhrase) + ' trench at ' + esc(widNounPhrase) + ' wide and ' + esc(depNounPhrase) +
                ' deep needs ' + fmt(gravelYd3, 2) + ' cubic yards of gravel and ' + esc(pipeLenPhrase) +
                ' of ' + esc(pipeDiaPhrase) + ' perforated pipe. The trench should slope 1 inch per 10 feet for drainage.';
    }
    html += '<p class="scalc-meaning">' + meaning + '</p>';

    // --- 4. What to do (bullets, not numbered) ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What to do</h4>';
    html += '<ul class="scalc-todo">';
    if (isMetric) {
      html += '<li>Dig the trench ' + esc(widNounPhrase) + ' wide and ' + esc(depNounPhrase) + ' deep, sloping 1 cm per meter</li>';
      html += '<li>Line the trench with landscape fabric to prevent soil mixing</li>';
      html += '<li>Lay ' + esc(pipeDiaPhrase) + ' perforated pipe at the bottom, holes facing down</li>';
      html += '<li>Cover with ' + fmt(gravelM3, 2) + ' cubic meters of gravel, then fold the fabric over the top</li>';
    } else {
      html += '<li>Dig the trench ' + esc(widNounPhrase) + ' wide and ' + esc(depNounPhrase) + ' deep, sloping 1 inch per 10 feet</li>';
      html += '<li>Line the trench with landscape fabric to prevent soil mixing</li>';
      html += '<li>Lay ' + esc(pipeDiaPhrase) + ' perforated pipe at the bottom, holes facing down</li>';
      html += '<li>Cover with ' + fmt(gravelYd3, 2) + ' cubic yards of gravel, then fold the fabric over the top</li>';
    }
    html += '</ul>';

    outEl.innerHTML = html;
    resultsEl.classList.add('calculated');

    // SR live region — short summary
    if (liveEl) {
      var lead = isMetric
        ? (fmt(gravelM3, 2) + ' cubic meters of gravel and ' + pipeLenPhrase + ' of pipe')
        : (fmt(gravelYd3, 2) + ' cubic yards of gravel and ' + pipeLenPhrase + ' of pipe');
      liveEl.textContent = 'You need about ' + lead + '.';
    }
  }

  function clearResults() {
    resultsEl.classList.remove('calculated');
    renderEmptyState();
    if (liveEl) liveEl.textContent = '';
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ---------- Reset ----------
  function resetForm() {
    // Defaults match the static worked example (50 ft × 12 in × 18 in).
    $('#sc-len').value = '50';
    formEl.querySelector('[name="lenUnit"]').value = 'ft';
    $('#sc-wid').value = '12';
    formEl.querySelector('[name="widUnit"]').value = 'in';
    $('#sc-depth').value = '18';
    formEl.querySelector('[name="depthUnit"]').value = 'in';
    $('#sc-price').value = '';
    formEl.querySelector('[name="priceUnit"]').value = 'peryd3';
    clearResults();
  }

  // ---------- Init ----------
  var formEl, resultsEl, outEl, liveEl;

  function init() {
    formEl = document.getElementById('calc');
    resultsEl = document.getElementById('results');
    outEl = document.getElementById('out');
    liveEl = document.getElementById('live');
    if (!formEl || !resultsEl || !outEl) return;

    // Show the friendly empty state in the results panel until Calculate is
    // clicked. (For noscript users, the static worked-example markup remains
    // visible.)
    resultsEl.classList.remove('calculated');
    renderEmptyState();

    // Calculate / submit
    formEl.addEventListener('submit', function (e) {
      e.preventDefault();
      var r = compute();
      render(r);
      // Scroll the results into view (gentle, only if off-screen)
      if (resultsEl.classList.contains('calculated')) {
        var rect = resultsEl.getBoundingClientRect();
        if (rect.bottom > window.innerHeight || rect.top < 0) {
          resultsEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }
    });

    // Clear button
    var clearBtn = document.getElementById('sc-clear');
    if (clearBtn) clearBtn.addEventListener('click', function () {
      resetForm();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
