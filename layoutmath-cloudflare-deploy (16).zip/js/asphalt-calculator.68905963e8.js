/* Asphalt calculator — two-column layout (form LEFT, results RIGHT).
   Simplified inputs (radio toggle, per-input unit dropdowns, +add area rows,
   Calculate button). Results panel LEADS WITH TONS (asphalt is sold by the ton),
   lists equivalent volumes, then plain-English WHAT THIS MEANS and WHAT TO DO
   sections, and an optional COST line. Units are spelled out. No live updates.

   Asphalt math:
     - 1 cubic yard of compacted asphalt weighs ~4,050 lb = 2.025 tons.
     - 1 ton covers ~80 sq ft at 2 inches thick (2000 lb / (150 lb/ft³ × 2/12 ft)).
     - Cold patch: 50 lb bags, ~0.333 ft³ each (50 lb / 150 lb/ft³).
     - Typical depths: driveway 2–3 in, commercial 3–4 in, patching 2–4 in.
*/
(function () {
  'use strict';

  // ---------- Unit conversion tables ----------
  // All inputs are converted to a common internal unit (feet for length/depth,
  // square feet for area, cubic feet for volume). Results are converted out.

  // Length: factor to multiply by to get feet.
  var LEN_TO_FT = { ft: 1, m: 3.28084, yd: 3, in: 1 / 12, cm: 0.0328084 };
  // Area: factor to multiply by to get square feet.
  var AREA_TO_SQFT = { sqft: 1, sqm: 10.7639, sqyd: 9, acre: 43560 };
  // Depth: factor to multiply by to get feet.
  var DEPTH_TO_FT = { in: 1 / 12, cm: 0.0328084, ft: 1, m: 3.28084, yd: 3 };
  // Volume: factor to multiply cubic feet by to get target.
  var FT3_TO_YD3 = 1 / 27;
  var FT3_TO_M3 = 0.0283168;
  // Asphalt weight: 1 cubic yard of compacted hot mix weighs ~4,050 lb = 2.025 tons.
  var TONS_PER_YD3 = 2.025;
  // Cold patch bags: 50 lb per bag, compacted asphalt ~150 lb/ft³ → 0.333 ft³ per bag.
  var BAG_FT3 = 0.333;

  // ---------- Helpers ----------
  function parseNum(str) {
    if (str == null) return null;
    var s = String(str).trim();
    if (!s) return null;
    // Allow $ and common unit suffixes / fraction chars.
    s = s.replace(/[$,\s]/g, '').replace(/[′’]/g, "'").replace(/[″“”]/g, '"');
    s = s.replace(/½/g, ' 1/2').replace(/¼/g, ' 1/4').replace(/¾/g, ' 3/4')
         .replace(/⅛/g, ' 1/8').replace(/⅜/g, ' 3/8').replace(/⅝/g, ' 5/8').replace(/⅞/g, ' 7/8')
         .replace(/⅓/g, ' 1/3').replace(/⅔/g, ' 2/3');
    // "5' 6"" style or "5-6" style — treat as feet+inches if it has ' and "
    var m = s.match(/^(-?\d+(?:\.\d+)?)['′]\s*(\d+(?:\.\d+)?)["″]$/);
    if (m) return Number(m[1]) * 12 + Number(m[2]);
    // Mixed fraction like "3 1/2"
    m = s.match(/^(-?\d+)\s+(\d+)\/(\d+)$/);
    if (m) {
      var d = Number(m[3]);
      if (d === 0) return null;
      return Number(m[1]) + Number(m[2]) / d;
    }
    // Simple fraction "3/4"
    m = s.match(/^(-?\d+)\/(\d+)$/);
    if (m) {
      var d2 = Number(m[2]);
      if (d2 === 0) return null;
      return Number(m[1]) / d2;
    }
    // Plain decimal
    if (!/^-?\d*\.?\d+$/.test(s)) return null;
    var n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  function fmt(n, d) {
    if (!Number.isFinite(n)) return '—';
    return Number(n.toFixed(d)).toString();
  }

  function fmtMoney(n, cur) {
    if (!Number.isFinite(n)) return '—';
    var sym = cur === 'GBP' ? '£' : cur === 'EUR' ? '€' : '$';
    return sym + n.toFixed(2);
  }

  // Money without trailing .00 — for per-unit prices ($40 not $40.00)
  function fmtMoneyPlain(n, cur) {
    if (!Number.isFinite(n)) return '—';
    var sym = cur === 'GBP' ? '£' : cur === 'EUR' ? '€' : '$';
    return sym + (Number.isInteger(n) ? String(n) : n.toFixed(2));
  }

  function plural(n, sing) {
    return (n === 1) ? sing : sing + 's';
  }

  // Square feet back to a target area unit.
  var SQFT_TO_AREA = { sqft: 1, sqm: 1 / 10.7639, sqyd: 1 / 9, acre: 1 / 43560 };
  var AREA_WORDS = { sqft: 'square feet', sqm: 'square meters', sqyd: 'square yards', acre: 'acres' };
  var PRICE_WORDS = {
    perton: 'ton', persqft: 'square foot', perbag: '50 pound bag'
  };

  function describeAreaWords(value, unit) {
    var v = (unit === 'acre') ? fmt(value, 2)
            : (value >= 100 ? fmt(value, 0) : fmt(value, 1));
    return v + ' ' + AREA_WORDS[unit];
  }

  // e.g. "4-inch", "10-cm", "0.25-foot"
  function describeDepthPhrase(n, unit) {
    var v = (unit === 'in' || unit === 'cm') ? fmt(n, 1) : fmt(n, 2);
    var suf = { in: '-inch', cm: '-cm', ft: '-foot', m: '-m', yd: '-yard' }[unit] || (' ' + unit);
    return v + suf;
  }

  // e.g. "4 inches", "10 cm", "1 inch", "0.25 feet", "1 foot" — friendly for prose
  function describeDepthPlain(n, unit) {
    var v = (unit === 'in' || unit === 'cm') ? fmt(n, 1) : fmt(n, 2);
    var lbl = { in: 'inches', cm: 'cm', ft: 'feet', m: 'm', yd: 'yards' }[unit] || unit;
    if (Number(v) === 1) {
      if (unit === 'in') lbl = 'inch';
      else if (unit === 'ft') lbl = 'foot';
      else if (unit === 'yd') lbl = 'yard';
    }
    return v + ' ' + lbl;
  }

  // ---------- DOM ----------
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  // ---------- Row management for "Enter dimensions" ----------
  var MAX_ROWS = 5;
  function rowTemplate(idx) {
    var wrap = document.createElement('div');
    wrap.className = 'scalc-row';
    wrap.setAttribute('data-row', '');
    wrap.innerHTML =
      '<div class="field"><label for="sc-len-' + idx + '">Length</label>' +
        '<div class="inp">' +
          '<input id="sc-len-' + idx + '" name="len' + idx + '" type="text" inputmode="decimal" autocomplete="off" spellcheck="false" value="">' +
          '<select class="sc-unit" name="lenUnit' + idx + '" aria-label="Length unit">' +
            '<option value="ft" selected>ft</option><option value="m">m</option><option value="yd">yd</option><option value="in">in</option><option value="cm">cm</option>' +
          '</select>' +
        '</div>' +
      '</div>' +
      '<span class="scalc-x" aria-hidden="true">×</span>' +
      '<div class="field"><label for="sc-wid-' + idx + '">Width</label>' +
        '<div class="inp">' +
          '<input id="sc-wid-' + idx + '" name="wid' + idx + '" type="text" inputmode="decimal" autocomplete="off" spellcheck="false" value="">' +
          '<select class="sc-unit" name="widUnit' + idx + '" aria-label="Width unit">' +
            '<option value="ft" selected>ft</option><option value="m">m</option><option value="yd">yd</option><option value="in">in</option><option value="cm">cm</option>' +
          '</select>' +
        '</div>' +
      '</div>' +
      '<button type="button" class="scalc-del needs-js" data-del aria-label="Remove this area">&times;</button>';
    return wrap;
  }

  function refreshRowsUI() {
    var rows = $all('.scalc-row', rowsEl);
    var n = rows.length;
    rows.forEach(function (r) {
      var del = r.querySelector('[data-del]');
      if (del) del.hidden = (n <= 1);
    });
    var addBtn = $('#sc-addrow');
    if (addBtn) addBtn.hidden = (n >= MAX_ROWS);
    var help = $('.scalc-rowhelp');
    if (help) help.hidden = (n < 2);
  }

  function addRow() {
    var rows = $all('.scalc-row', rowsEl);
    if (rows.length >= MAX_ROWS) return;
    var idx = rows.length;
    var newRow = rowTemplate(idx);
    rowsEl.appendChild(newRow);
    refreshRowsUI();
    // Focus the new length input
    var inp = newRow.querySelector('input');
    if (inp) inp.focus();
  }

  function removeRow(btn) {
    var row = btn.closest('.scalc-row');
    if (!row || $all('.scalc-row', rowsEl).length <= 1) return;
    row.remove();
    refreshRowsUI();
  }

  // ---------- Area mode toggle ----------
  function setMode(mode) {
    $all('.scalc-section', formEl).forEach(function (sec) {
      sec.hidden = (sec.getAttribute('data-mode') !== mode);
    });
  }

  // ---------- Compute ----------
  function computeAreaSqft() {
    var mode = formEl.querySelector('input[name="areaMode"]:checked');
    mode = mode ? mode.value : 'total';
    if (mode === 'total') {
      var area = parseNum($('#sc-area').value);
      var areaUnit = formEl.querySelector('[name="areaUnit"]').value;
      if (area == null || area <= 0) return { ok: false, msg: 'Enter the area to pave.' };
      return {
        ok: true,
        sqft: area * AREA_TO_SQFT[areaUnit],
        describe: describeArea(area, areaUnit),
        primaryAreaValue: area,
        primaryAreaUnit: areaUnit
      };
    } else {
      var rows = $all('.scalc-row', rowsEl);
      var total = 0;
      var parts = [];
      var firstLenUnit = 'ft';
      for (var i = 0; i < rows.length; i++) {
        var len = parseNum(rows[i].querySelector('input[name^="len"]').value);
        var lenUnit = rows[i].querySelector('[name^="lenUnit"]').value;
        var wid = parseNum(rows[i].querySelector('input[name^="wid"]').value);
        var widUnit = rows[i].querySelector('[name^="widUnit"]').value;
        if (len == null || len <= 0 || wid == null || wid <= 0) {
          return { ok: false, msg: 'Enter length and width for every area.' };
        }
        var lf = len * LEN_TO_FT[lenUnit];
        var wf = wid * LEN_TO_FT[widUnit];
        total += lf * wf;
        parts.push(describeDim(len, lenUnit, wid, widUnit));
        if (i === 0) firstLenUnit = lenUnit;
      }
      // Pick a friendly primary area unit based on the first row's length unit.
      var primaryAreaUnit = 'sqft';
      if (firstLenUnit === 'm' || firstLenUnit === 'cm') primaryAreaUnit = 'sqm';
      else if (firstLenUnit === 'yd') primaryAreaUnit = 'sqyd';
      var primaryAreaValue = total * SQFT_TO_AREA[primaryAreaUnit];
      return {
        ok: true,
        sqft: total,
        describe: parts.join(' + '),
        primaryAreaValue: primaryAreaValue,
        primaryAreaUnit: primaryAreaUnit
      };
    }
  }

  function describeArea(n, unit) {
    var labels = { sqft: 'ft²', sqm: 'm²', sqyd: 'yd²', acre: 'acres' };
    var v = (unit === 'acre') ? fmt(n, 2) : fmt(n, 0);
    return v + ' ' + labels[unit];
  }
  function describeDim(l, lu, w, wu) {
    var lbl = { ft: 'ft', m: 'm', yd: 'yd', in: 'in', cm: 'cm' };
    return fmt(l, 0) + lbl[lu] + ' × ' + fmt(w, 0) + lbl[wu];
  }
  function describeDepth(n, unit) {
    var lbl = { in: 'in', cm: 'cm', ft: 'ft', m: 'm', yd: 'yd' };
    var v = (unit === 'in' || unit === 'cm') ? fmt(n, 1) : fmt(n, 2);
    return v + ' ' + lbl[unit];
  }

  function compute() {
    var areaRes = computeAreaSqft();
    if (!areaRes.ok) return areaRes;

    var depthInput = $('#sc-depth');
    var depth = parseNum(depthInput.value);
    var depthUnit = formEl.querySelector('[name="depthUnit"]').value;
    if (depth == null || depth <= 0) return { ok: false, msg: 'Enter a compacted thickness greater than zero.' };

    // Optional price
    var priceInput = $('#sc-price');
    var price = parseNum(priceInput.value);
    var priceUnit = formEl.querySelector('[name="priceUnit"]').value;
    var hasPrice = (price != null && price >= 0 && priceInput.value.trim() !== '');

    // Volume in cubic feet
    var depthFt = depth * DEPTH_TO_FT[depthUnit];
    var ft3 = areaRes.sqft * depthFt;
    var yd3 = ft3 * FT3_TO_YD3;
    var m3 = ft3 * FT3_TO_M3;

    // Tons (asphalt: 1 cu yd ≈ 2.025 tons compacted) and cold-patch bags (0.333 ft³ each)
    var tons = yd3 * TONS_PER_YD3;
    var bags = Math.ceil(ft3 / BAG_FT3 - 1e-9);

    // Cost
    var cost = null;
    if (hasPrice) {
      if (priceUnit === 'perton') cost = tons * price;
      else if (priceUnit === 'persqft') cost = areaRes.sqft * price;
      else if (priceUnit === 'perbag') cost = bags * price;
    }

    return {
      ok: true,
      yd3: yd3, m3: m3, ft3: ft3,
      tons: tons, bags: bags,
      cost: cost, hasPrice: hasPrice, price: price, priceUnit: priceUnit,
      areaSqft: areaRes.sqft,
      areaDesc: areaRes.describe,
      depthDesc: describeDepth(depth, depthUnit),
      depthValue: depth, depthUnit: depthUnit,
      primaryAreaValue: areaRes.primaryAreaValue,
      primaryAreaUnit: areaRes.primaryAreaUnit
    };
  }

  // ---------- Render ----------
  // Simplified, calculator.net-style result panel:
  //   1. ONE plain-English sentence with the lead number bolded inline (TONS)
  //   2. Optional cost line (only if a price was entered)
  //   3. "What this means" — 1-2 sentence explanation
  //   4. "What to do" — 3-4 short bullets (not numbered)
  // Asphalt is sold by the ton, so the result ALWAYS leads with tons.
  function renderEmptyState() {
    outEl.innerHTML =
      '<div class="scalc-empty">' +
        '<p>Enter your area and compacted thickness, then click <b>Calculate</b>.</p>' +
        '<p>The answer will show:</p>' +
        '<ul>' +
          '<li>How many tons of asphalt to order (sold by the ton)</li>' +
          '<li>What that means in plain English</li>' +
          '<li>What to do next — DIY repair or hire a paving contractor</li>' +
        '</ul>' +
      '</div>';
  }

  function render(r) {
    if (!r.ok) {
      outEl.innerHTML = '<p class="scalc-err">' + esc(r.msg) + '</p>';
      resultsEl.classList.add('calculated');
      if (liveEl) liveEl.textContent = r.msg;
      return;
    }

    var tons = r.tons;
    var yd3 = r.yd3;
    var bags = r.bags;
    var bagWord = plural(bags, 'bag');
    var depthPhrase = describeDepthPhrase(r.depthValue, r.depthUnit);   // "4-inch" / "10-cm"
    var depthPlain  = describeDepthPlain(r.depthValue, r.depthUnit);    // "4 inches" / "10 cm"
    var areaPhrase  = describeAreaWords(r.primaryAreaValue, r.primaryAreaUnit);  // "600 square feet"

    // Detect metric: area in sqm OR depth in cm/m
    var isMetric = (r.primaryAreaUnit === 'sqm' || r.depthUnit === 'cm' || r.depthUnit === 'm');

    // Small job = under 5 tons → DIY / millings / cold-patch territory.
    // Large job = 5 tons or more → professional hot-mix paving job.
    var smallJob = (tons < 5);
    // Very small repair (under 1 ton) → cold patch bags are the practical unit.
    var tinyRepair = (tons < 1);

    var html = '';

    // --- 1. Plain-English answer sentence (LEAD WITH TONS) ---
    html += '<p class="scalc-answer">';
    html += 'You need about <span class="num">' + fmt(tons, 2) + ' tons</span> of asphalt ';
    // Volume parenthetical — cubic yards (imperial) or cubic meters (metric).
    var volPart = isMetric ? (fmt(r.m3, 2) + ' cubic meters') : (fmt(yd3, 2) + ' cubic yards');
    // Bags parenthetical — only for tiny repairs where cold patch is realistic.
    if (tinyRepair) {
      html += '(' + volPart + ', or ' + bags + ' ' + esc(bagWord) + ' of 50 pound cold patch).';
    } else {
      html += '(' + volPart + ').';
    }
    html += '</p>';

    // --- 2. Cost line (only if a price was entered) ---
    if (r.hasPrice && r.cost != null) {
      html += '<p class="scalc-cost-line">At ' + esc(fmtMoneyPlain(r.price, 'USD')) + ' per ' +
              esc(PRICE_WORDS[r.priceUnit] || r.priceUnit) + ', the total cost is about <strong>' +
              esc(fmtMoney(r.cost, 'USD')) + '</strong>.</p>';
    }

    // --- 3. What this means ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What this means</h4>';
    var meaning = 'A ' + esc(depthPhrase) + ' compacted layer over ' + esc(areaPhrase) +
                  ' uses this much asphalt. Hot mix must be installed at 250 to 300 degrees F ' +
                  '&mdash; this is a job for a paving contractor.';
    html += '<p class="scalc-meaning">' + meaning + '</p>';

    // --- 4. What to do (bullets, not numbered) ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What to do</h4>';
    html += '<ul class="scalc-todo">';
    if (smallJob) {
      // Small / DIY repair track.
      if (tinyRepair) {
        html += '<li>For a small repair, buy ' + bags + ' ' + esc(bagWord) + ' of cold patch asphalt (50 pounds each) from a hardware store</li>';
      } else {
        html += '<li>For a driveway, consider asphalt millings (recycled, spread cold) from a landscape supplier &mdash; about ' + fmt(tons, 2) + ' tons</li>';
      }
      html += '<li>Spread with a wheelbarrow and rake to ' + esc(depthPlain) + ' deep</li>';
      html += '<li>Compact with a rented plate compactor ($50 to $80 per day)</li>';
      if (!tinyRepair) {
        html += '<li>For hot mix at this size, a paving contractor is still the safer call &mdash; the plant won\'t deliver less than a full truckload</li>';
      }
    } else {
      // Large / professional job track.
      html += '<li>This is a job for a paving contractor &mdash; hot asphalt must be installed at 250 to 300 degrees F</li>';
      html += '<li>The contractor orders ' + fmt(tons, 2) + ' tons from an asphalt plant, delivered in a hot mix truck</li>';
      html += '<li>Compact with a 10-ton vibratory roller &mdash; DIY rollers won\'t achieve proper density</li>';
      html += '<li>Don\'t drive on it for 3 to 5 days after installation</li>';
    }
    html += '</ul>';

    outEl.innerHTML = html;
    resultsEl.classList.add('calculated');

    // SR live region — short summary
    if (liveEl) {
      liveEl.textContent = 'You need about ' + fmt(tons, 2) + ' tons of asphalt.';
    }
  }

  function clearResults() {
    resultsEl.classList.remove('calculated');
    renderEmptyState();
    if (liveEl) liveEl.textContent = '';
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ---------- Reset ----------
  function resetForm() {
    // Defaults match the static worked example (600 sq ft at 3 in → 11.25 tons).
    $('#sc-area').value = '600';
    formEl.querySelector('[name="areaUnit"]').value = 'sqft';
    // Reset dimensions: keep just 1 row with default values
    var rows = $all('.scalc-row', rowsEl);
    for (var i = 1; i < rows.length; i++) rows[i].remove();
    var firstRow = rows[0];
    if (firstRow) {
      firstRow.querySelector('input[name^="len"]').value = '50';
      firstRow.querySelector('[name^="lenUnit"]').value = 'ft';
      firstRow.querySelector('input[name^="wid"]').value = '12';
      firstRow.querySelector('[name^="widUnit"]').value = 'ft';
    }
    $('#sc-depth').value = '3';
    formEl.querySelector('[name="depthUnit"]').value = 'in';
    $('#sc-price').value = '';
    formEl.querySelector('[name="priceUnit"]').value = 'perton';
    // Default mode
    var totalRadio = formEl.querySelector('input[name="areaMode"][value="total"]');
    if (totalRadio) totalRadio.checked = true;
    setMode('total');
    refreshRowsUI();
    clearResults();
  }

  // ---------- Init ----------
  var formEl, rowsEl, resultsEl, outEl, liveEl;

  function init() {
    formEl = document.getElementById('calc');
    rowsEl = document.getElementById('sc-rows');
    resultsEl = document.getElementById('results');
    outEl = document.getElementById('out');
    liveEl = document.getElementById('live');
    if (!formEl || !resultsEl || !outEl) return;

    // Initial UI state
    refreshRowsUI();

    // Show the friendly empty state in the results panel until Calculate is clicked.
    // (For noscript users, the static worked-example markup remains visible.)
    resultsEl.classList.remove('calculated');
    renderEmptyState();

    // Radio toggle for area mode
    formEl.addEventListener('change', function (e) {
      if (e.target.name === 'areaMode') {
        setMode(e.target.value);
      }
    });

    // Add another area row
    var addBtn = document.getElementById('sc-addrow');
    if (addBtn) addBtn.addEventListener('click', addRow);

    // Remove a row (event delegation)
    rowsEl.addEventListener('click', function (e) {
      var del = e.target.closest('[data-del]');
      if (del) removeRow(del);
    });

    // Calculate / submit
    formEl.addEventListener('submit', function (e) {
      e.preventDefault();
      var r = compute();
      render(r);
      // Scroll the results into view (gentle, only if off-screen)
      if (resultsEl.classList.contains('calculated')) {
        var rect = resultsEl.getBoundingClientRect();
        if (rect.bottom > window.innerHeight || rect.top < 0) {
          resultsEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }
    });

    // Clear button
    var clearBtn = document.getElementById('sc-clear');
    if (clearBtn) clearBtn.addEventListener('click', function () {
      resetForm();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
