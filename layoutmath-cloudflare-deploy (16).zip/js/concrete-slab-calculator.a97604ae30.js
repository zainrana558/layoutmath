/* Concrete slab calculator — two-column layout (form LEFT, results RIGHT).
   Simplified inputs (radio toggle, per-input unit dropdowns, +add slab rows,
   Calculate button). Results panel leads with cubic yards for big jobs (or
   80 lb bags when under 50 bags), then plain-English WHAT THIS MEANS and
   WHAT TO DO sections covering rebar (#4 at 16" OC) and a 4–6" compacted
   gravel base, plus an optional COST line. Units are spelled out. No live
   updates. */
(function () {
  'use strict';

  // ---------- Unit conversion tables ----------
  // All inputs are converted to a common internal unit (feet for length/depth,
  // square feet for area, cubic feet for volume). Results are converted out.

  // Length: factor to multiply by to get feet.
  var LEN_TO_FT = { ft: 1, m: 3.28084, yd: 3, in: 1 / 12, cm: 0.0328084 };
  // Area: factor to multiply by to get square feet.
  var AREA_TO_SQFT = { sqft: 1, sqm: 10.7639, sqyd: 9 };
  // Depth: factor to multiply by to get feet.
  var DEPTH_TO_FT = { in: 1 / 12, cm: 0.0328084, ft: 1, m: 3.28084, yd: 3 };
  // Volume: factor to multiply cubic feet by to get target.
  var FT3_TO_YD3 = 1 / 27;
  var FT3_TO_M3 = 0.0283168;
  // Concrete bag: an 80 lb bag of mix yields 0.60 ft³ (45 bags per cubic yard).
  var BAG_FT3 = 0.6;
  // Rebar: #4 bars at 16 inches on center each way; sticks are 20 ft long.
  var REBAR_SPACING_IN = 16;
  var REBAR_STICK_FT = 20;

  // ---------- Helpers ----------
  function parseNum(str) {
    if (str == null) return null;
    var s = String(str).trim();
    if (!s) return null;
    s = s.replace(/[$,\s]/g, '').replace(/[′’]/g, "'").replace(/[″“”]/g, '"');
    s = s.replace(/½/g, ' 1/2').replace(/¼/g, ' 1/4').replace(/¾/g, ' 3/4')
         .replace(/⅛/g, ' 1/8').replace(/⅜/g, ' 3/8').replace(/⅝/g, ' 5/8').replace(/⅞/g, ' 7/8')
         .replace(/⅓/g, ' 1/3').replace(/⅔/g, ' 2/3');
    var m = s.match(/^(-?\d+(?:\.\d+)?)['′]\s*(\d+(?:\.\d+)?)["″]$/);
    if (m) return Number(m[1]) * 12 + Number(m[2]);
    m = s.match(/^(-?\d+)\s+(\d+)\/(\d+)$/);
    if (m) {
      var d = Number(m[3]);
      if (d === 0) return null;
      return Number(m[1]) + Number(m[2]) / d;
    }
    m = s.match(/^(-?\d+)\/(\d+)$/);
    if (m) {
      var d2 = Number(m[2]);
      if (d2 === 0) return null;
      return Number(m[1]) / d2;
    }
    if (!/^-?\d*\.?\d+$/.test(s)) return null;
    var n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  function fmt(n, d) {
    if (!Number.isFinite(n)) return '—';
    return Number(n.toFixed(d)).toString();
  }

  function fmtMoney(n, cur) {
    if (!Number.isFinite(n)) return '—';
    var sym = cur === 'GBP' ? '£' : cur === 'EUR' ? '€' : '$';
    return sym + n.toFixed(2);
  }

  function fmtMoneyPlain(n, cur) {
    if (!Number.isFinite(n)) return '—';
    var sym = cur === 'GBP' ? '£' : cur === 'EUR' ? '€' : '$';
    return sym + (Number.isInteger(n) ? String(n) : n.toFixed(2));
  }

  function plural(n, sing) {
    return (n === 1) ? sing : sing + 's';
  }

  var SQFT_TO_AREA = { sqft: 1, sqm: 1 / 10.7639, sqyd: 1 / 9 };
  var AREA_WORDS = { sqft: 'square feet', sqm: 'square meters', sqyd: 'square yards' };
  var PRICE_WORDS = {
    peryd3: 'cubic yard', perbag: '80 pound bag'
  };

  function describeAreaWords(value, unit) {
    var v = (value >= 100 ? fmt(value, 0) : fmt(value, 1));
    return v + ' ' + AREA_WORDS[unit];
  }

  // e.g. "4-inch", "10-cm"
  function describeDepthPhrase(n, unit) {
    var v = (unit === 'in' || unit === 'cm') ? fmt(n, 1) : fmt(n, 2);
    var suf = { in: '-inch', cm: '-cm', ft: '-ft', m: '-m', yd: '-yd' }[unit] || (' ' + unit);
    return v + suf;
  }

  // e.g. "4 inches", "10 cm", "1 inch"
  function describeDepthPlain(n, unit) {
    var v = (unit === 'in' || unit === 'cm') ? fmt(n, 1) : fmt(n, 2);
    var lbl = { in: 'inches', cm: 'cm', ft: 'ft', m: 'm', yd: 'yd' }[unit] || unit;
    if (unit === 'in' && Number(v) === 1) lbl = 'inch';
    return v + ' ' + lbl;
  }

  // ---------- DOM ----------
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  // ---------- Row management for "Enter dimensions" ----------
  var MAX_ROWS = 5;
  function rowTemplate(idx) {
    var wrap = document.createElement('div');
    wrap.className = 'scalc-row';
    wrap.setAttribute('data-row', '');
    wrap.innerHTML =
      '<div class="field"><label for="sc-len-' + idx + '">Length</label>' +
        '<div class="inp">' +
          '<input id="sc-len-' + idx + '" name="len' + idx + '" type="text" inputmode="decimal" autocomplete="off" spellcheck="false" value="">' +
          '<select class="sc-unit" name="lenUnit' + idx + '" aria-label="Length unit">' +
            '<option value="ft" selected>ft</option><option value="m">m</option><option value="yd">yd</option><option value="in">in</option><option value="cm">cm</option>' +
          '</select>' +
        '</div>' +
      '</div>' +
      '<span class="scalc-x" aria-hidden="true">×</span>' +
      '<div class="field"><label for="sc-wid-' + idx + '">Width</label>' +
        '<div class="inp">' +
          '<input id="sc-wid-' + idx + '" name="wid' + idx + '" type="text" inputmode="decimal" autocomplete="off" spellcheck="false" value="">' +
          '<select class="sc-unit" name="widUnit' + idx + '" aria-label="Width unit">' +
            '<option value="ft" selected>ft</option><option value="m">m</option><option value="yd">yd</option><option value="in">in</option><option value="cm">cm</option>' +
          '</select>' +
        '</div>' +
      '</div>' +
      '<button type="button" class="scalc-del needs-js" data-del aria-label="Remove this slab">&times;</button>';
    return wrap;
  }

  function refreshRowsUI() {
    var rows = $all('.scalc-row', rowsEl);
    var n = rows.length;
    rows.forEach(function (r) {
      var del = r.querySelector('[data-del]');
      if (del) del.hidden = (n <= 1);
    });
    var addBtn = $('#sc-addrow');
    if (addBtn) addBtn.hidden = (n >= MAX_ROWS);
    var help = $('.scalc-rowhelp');
    if (help) help.hidden = (n < 2);
  }

  function addRow() {
    var rows = $all('.scalc-row', rowsEl);
    if (rows.length >= MAX_ROWS) return;
    var idx = rows.length;
    var newRow = rowTemplate(idx);
    rowsEl.appendChild(newRow);
    refreshRowsUI();
    var inp = newRow.querySelector('input');
    if (inp) inp.focus();
  }

  function removeRow(btn) {
    var row = btn.closest('.scalc-row');
    if (!row || $all('.scalc-row', rowsEl).length <= 1) return;
    row.remove();
    refreshRowsUI();
  }

  // ---------- Area mode toggle ----------
  function setMode(mode) {
    $all('.scalc-section', formEl).forEach(function (sec) {
      sec.hidden = (sec.getAttribute('data-mode') !== mode);
    });
  }

  // ---------- Compute ----------
  function computeAreaSqft() {
    var mode = formEl.querySelector('input[name="areaMode"]:checked');
    mode = mode ? mode.value : 'total';
    if (mode === 'total') {
      var area = parseNum($('#sc-area').value);
      var areaUnit = formEl.querySelector('[name="areaUnit"]').value;
      if (area == null || area <= 0) return { ok: false, msg: 'Enter the slab area.' };
      return {
        ok: true,
        sqft: area * AREA_TO_SQFT[areaUnit],
        describe: describeArea(area, areaUnit),
        primaryAreaValue: area,
        primaryAreaUnit: areaUnit
      };
    } else {
      var rows = $all('.scalc-row', rowsEl);
      var total = 0;
      var parts = [];
      var firstLenUnit = 'ft';
      for (var i = 0; i < rows.length; i++) {
        var len = parseNum(rows[i].querySelector('input[name^="len"]').value);
        var lenUnit = rows[i].querySelector('[name^="lenUnit"]').value;
        var wid = parseNum(rows[i].querySelector('input[name^="wid"]').value);
        var widUnit = rows[i].querySelector('[name^="widUnit"]').value;
        if (len == null || len <= 0 || wid == null || wid <= 0) {
          return { ok: false, msg: 'Enter length and width for every slab.' };
        }
        var lf = len * LEN_TO_FT[lenUnit];
        var wf = wid * LEN_TO_FT[widUnit];
        total += lf * wf;
        parts.push(describeDim(len, lenUnit, wid, widUnit));
        if (i === 0) firstLenUnit = lenUnit;
      }
      var primaryAreaUnit = 'sqft';
      if (firstLenUnit === 'm' || firstLenUnit === 'cm') primaryAreaUnit = 'sqm';
      else if (firstLenUnit === 'yd') primaryAreaUnit = 'sqyd';
      var primaryAreaValue = total * SQFT_TO_AREA[primaryAreaUnit];
      return {
        ok: true,
        sqft: total,
        describe: parts.join(' + '),
        primaryAreaValue: primaryAreaValue,
        primaryAreaUnit: primaryAreaUnit
      };
    }
  }

  function describeArea(n, unit) {
    var labels = { sqft: 'ft²', sqm: 'm²', sqyd: 'yd²' };
    var v = fmt(n, 0);
    return v + ' ' + labels[unit];
  }
  function describeDim(l, lu, w, wu) {
    var lbl = { ft: 'ft', m: 'm', yd: 'yd', in: 'in', cm: 'cm' };
    return fmt(l, 0) + lbl[lu] + ' × ' + fmt(w, 0) + lbl[wu];
  }
  function describeDepth(n, unit) {
    var lbl = { in: 'in', cm: 'cm', ft: 'ft', m: 'm', yd: 'yd' };
    var v = (unit === 'in' || unit === 'cm') ? fmt(n, 1) : fmt(n, 2);
    return v + ' ' + lbl[unit];
  }

  // Rebar estimate for a square slab of the given area, at 16" OC each way.
  // Sticks are 20 ft long. Returns {linearFt, sticks}.
  function rebarEstimate(sqft) {
    var side = Math.sqrt(sqft);
    var sideIn = side * 12;
    // Bars running in each direction: one at 0, one at the far edge, plus
    // one every REBAR_SPACING_IN inches in between. ceil(sideIn / sp) + 1
    // covers the full span with a bar at each edge.
    var nPer = Math.max(2, Math.ceil(sideIn / REBAR_SPACING_IN) + 1);
    var linearFt = 2 * nPer * side;
    var sticks = Math.ceil(linearFt / REBAR_STICK_FT - 1e-9);
    return { linearFt: linearFt, sticks: sticks };
  }

  function compute() {
    var areaRes = computeAreaSqft();
    if (!areaRes.ok) return areaRes;

    var depthInput = $('#sc-depth');
    var depth = parseNum(depthInput.value);
    var depthUnit = formEl.querySelector('[name="depthUnit"]').value;
    if (depth == null || depth <= 0) return { ok: false, msg: 'Enter a slab thickness greater than zero.' };

    var priceInput = $('#sc-price');
    var price = parseNum(priceInput.value);
    var priceUnit = formEl.querySelector('[name="priceUnit"]').value;
    var hasPrice = (price != null && price >= 0 && priceInput.value.trim() !== '');

    // Volume in cubic feet
    var depthFt = depth * DEPTH_TO_FT[depthUnit];
    var ft3 = areaRes.sqft * depthFt;
    var yd3 = ft3 * FT3_TO_YD3;
    var m3 = ft3 * FT3_TO_M3;

    // Bags of 80 lb concrete mix (0.6 ft³ each), rounded up.
    var bags = Math.ceil(ft3 / BAG_FT3 - 1e-9);

    // Rebar (#4 at 16" OC each way), assuming a square of the same total area.
    var rebar = rebarEstimate(areaRes.sqft);

    // Cost
    var cost = null;
    if (hasPrice) {
      if (priceUnit === 'peryd3') cost = yd3 * price;
      else if (priceUnit === 'perbag') cost = bags * price;
    }

    // Lead: bags if <50, else cubic yards. Metric always leads with cubic meters.
    var isMetric = (areaRes.primaryAreaUnit === 'sqm' || depthUnit === 'cm' || depthUnit === 'm');
    var leadBags = !isMetric && bags < 50;
    var leadM3 = isMetric;

    // Small job: under 50 bags — bag instructions. Otherwise bulk instructions.
    var smallJob = (bags < 50);

    return {
      ok: true,
      yd3: yd3, m3: m3, ft3: ft3,
      bags: bags,
      rebarSticks: rebar.sticks, rebarLinearFt: rebar.linearFt,
      cost: cost, hasPrice: hasPrice, price: price, priceUnit: priceUnit,
      areaDesc: areaRes.describe,
      depthDesc: describeDepth(depth, depthUnit),
      depthValue: depth, depthUnit: depthUnit,
      primaryAreaValue: areaRes.primaryAreaValue,
      primaryAreaUnit: areaRes.primaryAreaUnit,
      isMetric: isMetric, leadBags: leadBags, leadM3: leadM3,
      smallJob: smallJob
    };
  }

  // ---------- Render ----------
  function renderEmptyState() {
    outEl.innerHTML =
      '<div class="scalc-empty">' +
        '<p>Enter your slab area and thickness, then click <b>Calculate</b>.</p>' +
        '<p>The answer will show:</p>' +
        '<ul>' +
          '<li>How many cubic yards (or 80 pound bags) of concrete to buy</li>' +
          '<li>Sticks of #4 rebar at 16 inches on center, plus a gravel base</li>' +
          '<li>What to do next, step by step</li>' +
        '</ul>' +
      '</div>';
  }

  function render(r) {
    if (!r.ok) {
      outEl.innerHTML = '<p class="scalc-err">' + esc(r.msg) + '</p>';
      resultsEl.classList.add('calculated');
      if (liveEl) liveEl.textContent = r.msg;
      return;
    }

    var yd3 = r.yd3;
    var m3 = r.m3;
    var bags = r.bags;
    var bagWord = plural(bags, 'bag');
    var depthPhrase = describeDepthPhrase(r.depthValue, r.depthUnit);   // "4-inch" / "10-cm"
    var depthPlain  = describeDepthPlain(r.depthValue, r.depthUnit);    // "4 inches" / "10 cm"
    var areaPhrase  = describeAreaWords(r.primaryAreaValue, r.primaryAreaUnit);  // "120 square feet"

    var html = '';

    // --- 1. Plain-English answer sentence ---
    html += '<p class="scalc-answer">';
    if (r.leadBags) {
      html += 'You need about <span class="num">' + bags + ' ' + esc(bagWord) + '</span> of concrete ' +
              '(' + fmt(yd3, 2) + ' cubic yards of mix).';
    } else if (r.leadM3) {
      html += 'You need about <span class="num">' + fmt(m3, 2) + ' cubic meters</span> of concrete ' +
              '(about ' + fmt(yd3, 2) + ' cubic yards, or ' + bags + ' ' + esc(bagWord) + ' of 80 pound mix).';
    } else {
      html += 'You need about <span class="num">' + fmt(yd3, 2) + ' cubic yards</span> of concrete ' +
              '(or ' + bags + ' ' + esc(bagWord) + ' of 80 pound mix).';
    }
    html += '</p>';

    // --- 2. Cost line (only if a price was entered) ---
    if (r.hasPrice && r.cost != null) {
      html += '<p class="scalc-cost-line">At ' + esc(fmtMoneyPlain(r.price, 'USD')) + ' per ' +
              esc(PRICE_WORDS[r.priceUnit] || r.priceUnit) + ', the total cost is about <strong>' +
              esc(fmtMoney(r.cost, 'USD')) + '</strong>.</p>';
    }

    // --- 3. What this means ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What this means</h4>';
    var meaning = 'A ' + esc(depthPhrase) + ' slab over ' + esc(areaPhrase) + ' uses this much concrete. ' +
                  'Plan on ' + r.rebarSticks + ' stick' + (r.rebarSticks === 1 ? '' : 's') +
                  ' of #4 rebar (20 feet each) at 16 inches on center, plus a 4 to 6 inch compacted gravel base underneath.';
    if (r.smallJob) {
      meaning += ' For a pour this small, bags from a hardware store are usually the easiest option.';
    } else {
      meaning += ' At this size, ready-mix delivery by the cubic yard is cheaper than bags &mdash; add 10 percent extra for spillage and uneven subgrade.';
    }
    html += '<p class="scalc-meaning">' + meaning + '</p>';

    // --- 4. What to do (bullets, not numbered) ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What to do</h4>';
    html += '<ul class="scalc-todo">';
    if (r.isMetric) {
      if (r.smallJob) {
        html += '<li>Buy ' + bags + ' bags (80 pounds / 0.6 cubic feet each) of concrete mix</li>';
        html += '<li>Lay 4 to 6 inches (10 to 15 cm) of compacted gravel as a base</li>';
        html += '<li>Place rebar (#4 at 16 inches on center each way) on 2-inch chairs before pouring</li>';
        html += '<li>Pour and screed with a straight 2x4, then finish with a mag float</li>';
      } else {
        html += '<li>Order ' + fmt(m3, 2) + ' cubic meters (about ' + fmt(yd3, 2) + ' cubic yards) of ready-mix concrete, delivered in a mixer truck</li>';
        html += '<li>Add 10 percent extra for spillage and uneven subgrade</li>';
        html += '<li>Lay 4 to 6 inches (10 to 15 cm) of compacted gravel base first</li>';
        html += '<li>Place rebar grid (#4 at 16 inches on center) on chairs, then pour and screed</li>';
        html += '<li>Cure with a fine mist for 7 days &mdash; cover with plastic to retain moisture</li>';
      }
    } else {
      if (r.smallJob) {
        html += '<li>Buy ' + bags + ' bags (80 pounds each) of concrete mix</li>';
        html += '<li>Lay 4 to 6 inches of compacted gravel as a base</li>';
        html += '<li>Place rebar (#4 at 16 inches on center each way) on 2-inch chairs before pouring</li>';
        html += '<li>Pour and screed with a straight 2x4, then finish with a mag float</li>';
      } else {
        html += '<li>Order ' + fmt(yd3, 2) + ' cubic yards of ready-mix concrete (delivered in a mixer truck)</li>';
        html += '<li>Add 10 percent extra for spillage and uneven subgrade</li>';
        html += '<li>Lay 4 to 6 inches of compacted gravel base first</li>';
        html += '<li>Place rebar grid (#4 at 16 inches on center) on chairs, then pour and screed</li>';
        html += '<li>Cure with a fine mist for 7 days &mdash; cover with plastic to retain moisture</li>';
      }
    }
    html += '</ul>';

    outEl.innerHTML = html;
    resultsEl.classList.add('calculated');

    // SR live region — short summary
    if (liveEl) {
      var srLead = r.leadBags ? (bags + ' ' + bagWord)
                  : r.leadM3  ? (fmt(m3, 2) + ' cubic meters')
                  : (fmt(yd3, 2) + ' cubic yards');
      liveEl.textContent = 'You need about ' + srLead + ' of concrete, plus ' + r.rebarSticks + ' sticks of rebar.';
    }
  }

  function clearResults() {
    resultsEl.classList.remove('calculated');
    renderEmptyState();
    if (liveEl) liveEl.textContent = '';
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ---------- Reset ----------
  function resetForm() {
    $('#sc-area').value = '120';
    formEl.querySelector('[name="areaUnit"]').value = 'sqft';
    var rows = $all('.scalc-row', rowsEl);
    for (var i = 1; i < rows.length; i++) rows[i].remove();
    var firstRow = rows[0];
    if (firstRow) {
      firstRow.querySelector('input[name^="len"]').value = '12';
      firstRow.querySelector('[name^="lenUnit"]').value = 'ft';
      firstRow.querySelector('input[name^="wid"]').value = '10';
      firstRow.querySelector('[name^="widUnit"]').value = 'ft';
    }
    $('#sc-depth').value = '4';
    formEl.querySelector('[name="depthUnit"]').value = 'in';
    $('#sc-price').value = '';
    formEl.querySelector('[name="priceUnit"]').value = 'peryd3';
    var totalRadio = formEl.querySelector('input[name="areaMode"][value="total"]');
    if (totalRadio) totalRadio.checked = true;
    setMode('total');
    refreshRowsUI();
    clearResults();
  }

  // ---------- Init ----------
  var formEl, rowsEl, resultsEl, outEl, liveEl;

  function init() {
    formEl = document.getElementById('calc');
    rowsEl = document.getElementById('sc-rows');
    resultsEl = document.getElementById('results');
    outEl = document.getElementById('out');
    liveEl = document.getElementById('live');
    if (!formEl || !resultsEl || !outEl) return;

    refreshRowsUI();
    resultsEl.classList.remove('calculated');
    renderEmptyState();

    formEl.addEventListener('change', function (e) {
      if (e.target.name === 'areaMode') {
        setMode(e.target.value);
      }
    });

    var addBtn = document.getElementById('sc-addrow');
    if (addBtn) addBtn.addEventListener('click', addRow);

    rowsEl.addEventListener('click', function (e) {
      var del = e.target.closest('[data-del]');
      if (del) removeRow(del);
    });

    formEl.addEventListener('submit', function (e) {
      e.preventDefault();
      var r = compute();
      render(r);
      if (resultsEl.classList.contains('calculated')) {
        var rect = resultsEl.getBoundingClientRect();
        if (rect.bottom > window.innerHeight || rect.top < 0) {
          resultsEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }
    });

    var clearBtn = document.getElementById('sc-clear');
    if (clearBtn) clearBtn.addEventListener('click', function () {
      resetForm();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
