/* Concrete bag calculator — two-column layout (form LEFT, results RIGHT).
   Simplified inputs (radio toggle: enter the volume directly vs enter its
   length, width and depth; per-input unit dropdowns; bag-size radio;
   Calculate button). Results panel leads with BAG COUNT (that is what you
   buy), then plain-English WHAT THIS MEANS and WHAT TO DO sections. Units are
   spelled out. No live updates. */
(function () {
  'use strict';

  // ---------- Unit conversion tables ----------
  // All inputs are converted to a common internal unit (cubic feet). Results
  // are converted out for display only.

  // Length / depth: factor to multiply by to get feet.
  var LEN_TO_FT   = { ft: 1, m: 3.28084, yd: 3, in: 1 / 12, cm: 0.0328084 };
  var DEPTH_TO_FT = { in: 1 / 12, cm: 0.0328084, ft: 1, m: 3.28084, yd: 3 };
  // Volume: factor to multiply the input value by to get cubic feet.
  var VOL_TO_FT3 = { ft3: 1, yd3: 27, m3: 35.3147 };
  // Cubic feet to cubic yards / cubic meters, for display.
  var FT3_TO_YD3 = 1 / 27;
  // Bag yields (cubic feet of concrete per bag), keyed by bag weight in lb.
  // 80 lb is the standard size and the most economical.
  var BAG_YIELD = { 40: 0.30, 60: 0.45, 80: 0.60, 90: 0.675 };
  // Mixing water: about 3 quarts per 80 lb bag, scaled by bag weight.
  var WATER_QT_PER_LB = 3 / 80;

  // ---------- Helpers ----------
  function parseNum(str) {
    if (str == null) return null;
    var s = String(str).trim();
    if (!s) return null;
    s = s.replace(/[$,\s]/g, '').replace(/[′’]/g, "'").replace(/[″“”]/g, '"');
    s = s.replace(/½/g, ' 1/2').replace(/¼/g, ' 1/4').replace(/¾/g, ' 3/4')
         .replace(/⅛/g, ' 1/8').replace(/⅜/g, ' 3/8').replace(/⅝/g, ' 5/8').replace(/⅞/g, ' 7/8')
         .replace(/⅓/g, ' 1/3').replace(/⅔/g, ' 2/3');
    // "5' 6"" style — treat as feet+inches
    var m = s.match(/^(-?\d+(?:\.\d+)?)['′]\s*(\d+(?:\.\d+)?)["″]$/);
    if (m) return Number(m[1]) * 12 + Number(m[2]);
    // Mixed fraction like "3 1/2"
    m = s.match(/^(-?\d+)\s+(\d+)\/(\d+)$/);
    if (m) {
      var d = Number(m[3]);
      if (d === 0) return null;
      return Number(m[1]) + Number(m[2]) / d;
    }
    // Simple fraction "3/4"
    m = s.match(/^(-?\d+)\/(\d+)$/);
    if (m) {
      var d2 = Number(m[2]);
      if (d2 === 0) return null;
      return Number(m[1]) / d2;
    }
    // Plain decimal
    if (!/^-?\d*\.?\d+$/.test(s)) return null;
    var n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  // fmt(27, 1) -> "27"; fmt(1, 2) -> "1"; fmt(40.5, 1) -> "40.5"; fmt(2.47, 2) -> "2.47".
  function fmt(n, d) {
    if (!Number.isFinite(n)) return '—';
    return Number(n.toFixed(d)).toString();
  }

  function plural(n, sing) {
    return (Math.abs(n - 1) < 1e-9) ? sing : sing + 's';
  }

  // Integer with thousands separators: 3600 -> "3,600".
  function fmtInt(n) {
    if (!Number.isFinite(n)) return '—';
    return Math.round(n).toLocaleString('en-US');
  }

  // Cubic feet -> "27 cubic feet (1 cubic yard)".
  function describeVolumeFt3(ft3) {
    var yd3 = ft3 * FT3_TO_YD3;
    return fmt(ft3, 1) + ' ' + (Math.abs(ft3 - 1) < 1e-9 ? 'cubic foot' : 'cubic feet') +
           ' (' + fmt(yd3, 2) + ' ' + plural(yd3, 'cubic yard') + ')';
  }

  // Volume-mode input value + unit -> "1.5 cubic yards (40.5 cubic feet)".
  function describeVolumeInput(v, unit) {
    var ft3 = v * VOL_TO_FT3[unit];
    if (unit === 'ft3') {
      var yd3 = ft3 * FT3_TO_YD3;
      return fmt(v, 1) + ' ' + (Math.abs(v - 1) < 1e-9 ? 'cubic foot' : 'cubic feet') +
             ' (' + fmt(yd3, 2) + ' ' + plural(yd3, 'cubic yard') + ')';
    }
    if (unit === 'yd3') {
      return fmt(v, 2) + ' ' + plural(v, 'cubic yard') +
             ' (' + fmt(ft3, 1) + ' ' + (Math.abs(ft3 - 1) < 1e-9 ? 'cubic foot' : 'cubic feet') + ')';
    }
    // m3
    return fmt(v, 2) + ' ' + plural(v, 'cubic meter') +
           ' (' + fmt(ft3, 1) + ' ' + (Math.abs(ft3 - 1) < 1e-9 ? 'cubic foot' : 'cubic feet') + ')';
  }

  // Dimensions -> "9 ft × 3 ft × 12 in".
  function describeDims(l, lu, w, wu, d, du) {
    function ulbl(n, u) {
      var v = Number(n);
      if (u === 'ft') return v === 1 ? 'foot' : 'feet';
      if (u === 'in') return v === 1 ? 'inch' : 'inches';
      return { m: 'm', yd: 'yd', cm: 'cm' }[u] || u;
    }
    return fmt(l, 0) + ' ' + ulbl(l, lu) + ' × ' + fmt(w, 0) + ' ' + ulbl(w, wu) +
           ' × ' + fmt(d, 1) + ' ' + ulbl(d, du);
  }

  // ---------- DOM ----------
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  // ---------- Mode toggle ----------
  function setMode(mode) {
    $all('.scalc-section', formEl).forEach(function (sec) {
      sec.hidden = (sec.getAttribute('data-mode') !== mode);
    });
  }

  // ---------- Compute ----------
  function compute() {
    var modeEl = formEl.querySelector('input[name="volMode"]:checked');
    var mode = modeEl ? modeEl.value : 'volume';

    var ft3, volPhrase, dimPhrase;
    if (mode === 'volume') {
      var vol = parseNum($('#sc-vol').value);
      var volUnit = formEl.querySelector('[name="volUnit"]').value;
      if (vol == null || vol <= 0) return { ok: false, msg: 'Enter the volume of concrete to fill.' };
      ft3 = vol * VOL_TO_FT3[volUnit];
      volPhrase = describeVolumeInput(vol, volUnit);
      dimPhrase = null;
    } else {
      var len = parseNum($('#sc-len').value);
      var lenUnit = formEl.querySelector('[name="lenUnit"]').value;
      var wid = parseNum($('#sc-wid').value);
      var widUnit = formEl.querySelector('[name="widUnit"]').value;
      var dep = parseNum($('#sc-dep').value);
      var depUnit = formEl.querySelector('[name="depUnit"]').value;
      if (len == null || len <= 0 || wid == null || wid <= 0 || dep == null || dep <= 0) {
        return { ok: false, msg: 'Enter length, width and depth, all greater than zero.' };
      }
      ft3 = len * LEN_TO_FT[lenUnit] * wid * LEN_TO_FT[widUnit] * dep * DEPTH_TO_FT[depUnit];
      volPhrase = describeVolumeFt3(ft3);
      dimPhrase = describeDims(len, lenUnit, wid, widUnit, dep, depUnit);
    }

    var bagEl = formEl.querySelector('input[name="bagSize"]:checked');
    var bagSize = bagEl ? Number(bagEl.value) : 80;
    if (!BAG_YIELD.hasOwnProperty(bagSize)) bagSize = 80;
    var yld = BAG_YIELD[bagSize];

    // Bags are rounded up — you buy whole bags.
    var bags = Math.ceil(ft3 / yld - 1e-9);
    var weightLb = bags * bagSize;
    var largeJob = bags >= 50;
    // Mixing water, scaled from 3 quarts per 80 lb bag.
    var waterQt = Math.round(bagSize * WATER_QT_PER_LB * 4) / 4;

    return {
      ok: true,
      ft3: ft3, yd3: ft3 * FT3_TO_YD3,
      bags: bags, bagSize: bagSize, yld: yld,
      weightLb: weightLb, waterQt: waterQt,
      largeJob: largeJob,
      volPhrase: volPhrase, dimPhrase: dimPhrase, mode: mode
    };
  }

  // ---------- Render ----------
  function renderEmptyState() {
    outEl.innerHTML =
      '<div class="scalc-empty">' +
        '<p>Enter the volume to fill (or its length, width and depth), pick a bag size, then click <b>Calculate</b>.</p>' +
        '<p>The answer will show:</p>' +
        '<ul>' +
          '<li>How many bags of concrete mix to buy</li>' +
          '<li>What that means in plain English</li>' +
          '<li>What to do next</li>' +
        '</ul>' +
      '</div>';
  }

  function render(r) {
    if (!r.ok) {
      outEl.innerHTML = '<p class="scalc-err">' + esc(r.msg) + '</p>';
      resultsEl.classList.add('calculated');
      if (liveEl) liveEl.textContent = r.msg;
      return;
    }

    var bags = r.bags;
    var bagWord = plural(bags, 'bag');
    var size = r.bagSize;
    var weight = fmtInt(r.weightLb);
    var water = fmt(r.waterQt, 2);
    var volPhrase = r.volPhrase;

    var html = '';

    // --- 1. Plain-English answer sentence (leads with bag count) ---
    html += '<p class="scalc-answer">';
    html += 'You need about <span class="num">' + bags + ' ' + esc(bagWord) + '</span> of ' +
            size + ' pound concrete mix to fill ' + esc(volPhrase) + '.';
    html += '</p>';

    // --- 2. What this means ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What this means</h4>';
    var meaning = '';
    if (r.mode === 'dimensions' && r.dimPhrase) {
      meaning += 'A ' + esc(r.dimPhrase) + ' pour holds ' + esc(volPhrase) + '. ';
    }
    meaning += 'Filling ' + esc(volPhrase) + ' with ' + size + ' pound bags takes ' + bags + ' ' +
               esc(bagWord) + ' &mdash; about ' + weight + ' pounds of mix. ';
    meaning += r.largeJob
      ? 'At this many bags, ready-mix delivery is usually cheaper and far less labor.'
      : 'A pour you can handle from bags.';
    html += '<p class="scalc-meaning">' + meaning + '</p>';

    // --- 3. What to do (bullets, not numbered) ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What to do</h4>';
    html += '<ul class="scalc-todo">';
    if (!r.largeJob) {
      html += '<li>Buy ' + bags + ' ' + esc(bagWord) + ' (' + size + ' pounds each) from a hardware store &mdash; 80 pound bags are the most economical size</li>';
      html += '<li>Mix one bag at a time with about ' + water + ' quarts of water &mdash; don\'t mix more than you can place in 30 minutes</li>';
      html += '<li>Have a wheelbarrow or mixer ready, plus a hoe for mixing</li>';
      html += '<li>Wear gloves, safety glasses, and a mask when mixing &mdash; concrete dust is harmful to lungs</li>';
    } else {
      html += '<li>At this scale, consider ready-mix delivery &mdash; it\'s cheaper and less labor than mixing 50+ bags</li>';
      html += '<li>If mixing by hand: store bags off the ground on pallets &mdash; they absorb moisture and harden</li>';
      html += '<li>Use bags within 6 months of purchase &mdash; older bags may have lumps</li>';
      html += '<li>For post holes: pour dry mix and add water in the hole (fast and easy)</li>';
    }
    html += '</ul>';

    outEl.innerHTML = html;
    resultsEl.classList.add('calculated');

    // SR live region — short summary
    if (liveEl) {
      liveEl.textContent = 'You need about ' + bags + ' ' + bagWord + ' of ' + size + ' pound concrete mix.';
    }
  }

  function clearResults() {
    resultsEl.classList.remove('calculated');
    renderEmptyState();
    if (liveEl) liveEl.textContent = '';
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ---------- Reset ----------
  function resetForm() {
    // Defaults match the static worked example: 27 cubic feet (1 cubic yard),
    // 80 lb bags -> 45 bags.
    $('#sc-vol').value = '27';
    formEl.querySelector('[name="volUnit"]').value = 'ft3';
    $('#sc-len').value = '9';
    formEl.querySelector('[name="lenUnit"]').value = 'ft';
    $('#sc-wid').value = '3';
    formEl.querySelector('[name="widUnit"]').value = 'ft';
    $('#sc-dep').value = '12';
    formEl.querySelector('[name="depUnit"]').value = 'in';
    var r80 = formEl.querySelector('input[name="bagSize"][value="80"]');
    if (r80) r80.checked = true;
    var volRadio = formEl.querySelector('input[name="volMode"][value="volume"]');
    if (volRadio) volRadio.checked = true;
    setMode('volume');
    clearResults();
  }

  // ---------- "Load these numbers" buttons (worked examples) ----------
  // data-load carries a small JSON object in the new form's field schema:
  //   {mode:"volume"|"dimensions", volume, volUnit, len, lenUnit, wid, widUnit,
  //    dep, depUnit, bagSize}
  function applyLoad(d) {
    var mode = (d && d.mode === 'dimensions') ? 'dimensions' : 'volume';
    var modeRadio = formEl.querySelector('input[name="volMode"][value="' + mode + '"]');
    if (modeRadio) modeRadio.checked = true;
    setMode(mode);
    if (mode === 'volume') {
      if (d.volume != null) $('#sc-vol').value = String(d.volume);
      if (d.volUnit) formEl.querySelector('[name="volUnit"]').value = d.volUnit;
    } else {
      if (d.len != null) $('#sc-len').value = String(d.len);
      if (d.lenUnit) formEl.querySelector('[name="lenUnit"]').value = d.lenUnit;
      if (d.wid != null) $('#sc-wid').value = String(d.wid);
      if (d.widUnit) formEl.querySelector('[name="widUnit"]').value = d.widUnit;
      if (d.dep != null) $('#sc-dep').value = String(d.dep);
      if (d.depUnit) formEl.querySelector('[name="depUnit"]').value = d.depUnit;
    }
    if (d.bagSize != null) {
      var r = formEl.querySelector('input[name="bagSize"][value="' + d.bagSize + '"]');
      if (r) r.checked = true;
    }
    render(compute());
    var calc = document.getElementById('calculator');
    if (calc) calc.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  // ---------- Init ----------
  var formEl, resultsEl, outEl, liveEl;

  function init() {
    formEl = document.getElementById('calc');
    resultsEl = document.getElementById('results');
    outEl = document.getElementById('out');
    liveEl = document.getElementById('live');
    if (!formEl || !resultsEl || !outEl) return;

    // Show the friendly empty state in the results panel until Calculate is
    // clicked. (For noscript users, the static worked-example markup remains.)
    resultsEl.classList.remove('calculated');
    renderEmptyState();

    // Radio toggle for volume mode
    formEl.addEventListener('change', function (e) {
      if (e.target.name === 'volMode') {
        setMode(e.target.value);
      }
    });

    // "Load these numbers" buttons in the worked-examples section.
    document.addEventListener('click', function (e) {
      var btn = e.target.closest('[data-load]');
      if (!btn || formEl.contains(btn)) return;
      var data;
      try { data = JSON.parse(btn.getAttribute('data-load')); } catch (err) { return; }
      applyLoad(data);
    });

    // Calculate / submit
    formEl.addEventListener('submit', function (e) {
      e.preventDefault();
      var r = compute();
      render(r);
      // Scroll the results into view (gentle, only if off-screen)
      if (resultsEl.classList.contains('calculated')) {
        var rect = resultsEl.getBoundingClientRect();
        if (rect.bottom > window.innerHeight || rect.top < 0) {
          resultsEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }
    });

    // Clear button
    var clearBtn = document.getElementById('sc-clear');
    if (clearBtn) clearBtn.addEventListener('click', function () {
      resetForm();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
