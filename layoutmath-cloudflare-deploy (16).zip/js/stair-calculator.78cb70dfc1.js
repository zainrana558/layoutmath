/* Stair calculator — two-column layout (form LEFT, results RIGHT).
   Simplified inputs (total rise as feet+inches or inches, desired riser
   height, tread depth). Results panel leads with the NUMBER OF RISERS,
   then lists riser height, tread count and stringer length, followed by
   plain-English WHAT THIS MEANS and WHAT TO DO sections, with an inline
   IRC code check. Units are spelled out. No live updates. */
(function () {
  'use strict';

  // ---------- IRC limits ----------
  var IRC_MAX_RISER = 7.75;     // 7 3/4 in
  var IRC_MIN_TREAD = 10;       // 10 in
  var IRC_MAX_RISE_IN = 216;    // 18 ft total rise — beyond this, a landing is needed

  // ---------- Helpers ----------
  function parseNum(str) {
    if (str == null) return null;
    var s = String(str).trim();
    if (!s) return null;
    // Normalize fancy quote chars first.
    s = s.replace(/[\u2019\u2018]/g, "'").replace(/[\u201c\u201d\u2033]/g, '"').replace(/[\u2032\u02b9]/g, "'");
    // Mixed fraction with a space: "3 1/2", "7 1/2" (handle BEFORE stripping spaces).
    var m = s.match(/^(-?\d+(?:\.\d+)?)\s+(\d+)\s*\/\s*(\d+)$/);
    if (m) {
      var d = Number(m[3]);
      if (d === 0) return null;
      return Number(m[1]) + Number(m[2]) / d;
    }
    // "5' 6"" style → inches
    m = s.match(/^(-?\d+(?:\.\d+)?)['\u2032]\s*(\d+(?:\.\d+)?)["\u2033]$/);
    if (m) return Number(m[1]) * 12 + Number(m[2]);
    // "5'" → inches (feet only, with a prime)
    m = s.match(/^(-?\d+(?:\.\d+)?)['\u2032]$/);
    if (m) return Number(m[1]) * 12;
    // Replace fraction glyphs and strip remaining whitespace / $ / ,
    s = s.replace(/[$,\s]/g, '')
         .replace(/\u00bd/g, '1/2').replace(/\u00bc/g, '1/4').replace(/\u00be/g, '3/4')
         .replace(/\u215b/g, '1/8').replace(/\u215c/g, '3/8').replace(/\u215d/g, '5/8').replace(/\u215e/g, '7/8')
         .replace(/\u2153/g, '1/3').replace(/\u2154/g, '2/3');
    // Simple fraction "3/4"
    m = s.match(/^(-?\d+)\/(\d+)$/);
    if (m) {
      var d2 = Number(m[2]);
      if (d2 === 0) return null;
      return Number(m[1]) / d2;
    }
    // Plain decimal
    if (!/^-?\d*\.?\d+$/.test(s)) return null;
    var n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  function fmt(n, d) {
    if (!Number.isFinite(n)) return '\u2014';
    return Number(n.toFixed(d)).toString();
  }

  function plural(n, sing) {
    if (n === 1) return sing;
    // "inch" -> "inches" (takes -es); others just take -s
    if (sing === 'inch') return 'inches';
    return sing + 's';
  }

  // ---------- Fraction formatting (stair work uses 1/16" increments) ----------
  function gcd(a, b) { return b ? gcd(b, a % b) : a; }

  // Format inches as a fraction to the nearest 1/16, e.g. 7.2 → "7 3/16"
  function fmtFrac(inches) {
    var sign = inches < -1e-9 ? '-' : '';
    var abs = Math.abs(inches);
    var six = Math.round(abs * 16);
    var whole = Math.floor(six / 16);
    var rem = six % 16;
    if (rem === 0) return sign + String(whole);
    var g = gcd(rem, 16);
    var num = rem / g, den = 16 / g;
    return sign + (whole !== 0 ? whole + ' ' : '') + num + '/' + den;
  }

  // Format inches as ft+in fraction, e.g. 56.85 → "4 feet 8 7/8 inches"
  function fmtFtIn(inches) {
    if (!Number.isFinite(inches)) return '\u2014';
    var ft = Math.floor(inches / 12);
    var remIn = inches - ft * 12;
    if (ft === 0) return fmtFrac(remIn) + ' ' + plural(remIn, 'inch');
    return ft + ' ' + (ft === 1 ? 'foot' : 'feet') + ' ' + fmtFrac(remIn) + ' ' + plural(remIn, 'inch');
  }

  // Format total rise for prose: "3 feet", "3 feet 6 inches", "0 feet 6 inches" → "6 inches"
  function fmtRisePhrase(inches) {
    var ft = Math.floor(inches / 12);
    var remIn = inches - ft * 12;
    if (ft === 0) return fmtFrac(remIn) + ' ' + plural(remIn, 'inch');
    if (Math.abs(remIn) < 1e-9) return ft + ' ' + (ft === 1 ? 'foot' : 'feet');
    return ft + ' ' + (ft === 1 ? 'foot' : 'feet') + ' ' + fmtFrac(remIn) + ' ' + plural(remIn, 'inch');
  }

  // ---------- DOM ----------
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  // ---------- Mode toggle (ft+in vs inches only) ----------
  function setMode(mode) {
    $all('.scalc-section', formEl).forEach(function (sec) {
      sec.hidden = (sec.getAttribute('data-mode') !== mode);
    });
  }

  // ---------- Compute ----------
  function compute() {
    var modeEl = formEl.querySelector('input[name="riseMode"]:checked');
    var mode = modeEl ? modeEl.value : 'ftin';

    var riseIn;
    if (mode === 'ftin') {
      var ft = parseNum($('#sc-rise-ft').value);
      var inch = parseNum($('#sc-rise-in').value);
      if (ft == null) ft = 0;
      if (inch == null) inch = 0;
      if ((ft === 0 && inch === 0) || ft < 0 || inch < 0) {
        return { ok: false, msg: 'Enter the total rise from the lower floor to the upper floor.' };
      }
      riseIn = ft * 12 + inch;
    } else {
      var r = parseNum($('#sc-rise').value);
      if (r == null || r <= 0) {
        return { ok: false, msg: 'Enter the total rise in inches (greater than zero).' };
      }
      riseIn = r;
    }

    var target = parseNum($('#sc-target').value);
    if (target == null || target <= 0) {
      return { ok: false, msg: 'Enter a desired riser height (try 7 inches).' };
    }
    if (target > IRC_MAX_RISER) {
      return { ok: false, msg: 'Desired riser height is over the IRC max of 7\u00be inches. Try 7 inches.' };
    }

    var tread = parseNum($('#sc-tread').value);
    if (tread == null || tread <= 0) {
      return { ok: false, msg: 'Enter a tread depth (try 11 inches).' };
    }

    // Number of risers: round to the nearest target, then bump the count up
    // while the resulting riser would exceed the IRC max.
    var risers = Math.max(1, Math.round(riseIn / target));
    while (riseIn / risers > IRC_MAX_RISER + 1e-9) risers += 1;
    var riserHeight = riseIn / risers;

    // Treads: the upper floor acts as the last step, so one fewer tread than risers.
    var treads = Math.max(0, risers - 1);
    var totalRun = treads * tread;
    var stringer = Math.hypot(riseIn, totalRun);
    var angle = 180 * Math.atan2(riserHeight, tread) / Math.PI;

    // IRC checks
    var riserOk = riserHeight <= IRC_MAX_RISER + 1e-9;
    var treadOk = tread >= IRC_MIN_TREAD - 1e-9;
    var riseOk = riseIn <= IRC_MAX_RISE_IN + 1e-9;

    return {
      ok: true,
      riseIn: riseIn,
      target: target,
      tread: tread,
      risers: risers,
      riserHeight: riserHeight,
      treads: treads,
      totalRun: totalRun,
      stringer: stringer,
      angle: angle,
      riserOk: riserOk,
      treadOk: treadOk,
      riseOk: riseOk
    };
  }

  // ---------- Render ----------
  function renderEmptyState() {
    outEl.innerHTML =
      '<div class="scalc-empty">' +
        '<p>Enter the total rise, desired riser height and tread depth, then click <b>Calculate</b>.</p>' +
        '<p>The answer will show:</p>' +
        '<ul>' +
          '<li>How many risers (and treads) to cut</li>' +
          '<li>The riser height and the stringer length</li>' +
          '<li>What that means in plain English</li>' +
          '<li>What to do next</li>' +
        '</ul>' +
      '</div>';
  }

  function render(r) {
    if (!r.ok) {
      outEl.innerHTML = '<p class="scalc-err">' + esc(r.msg) + '</p>';
      resultsEl.classList.add('calculated');
      if (liveEl) liveEl.textContent = r.msg;
      return;
    }

    var riserWord = plural(r.risers, 'riser');
    var treadWord = plural(r.treads, 'tread');
    var riserH = fmtFrac(r.riserHeight);          // "7 3/16"
    var treadD = fmt(r.tread, 0);                 // "11"
    var stringerFt = fmt(r.stringer / 12, 2);     // "4.74"
    var stringerFtIn = fmtFtIn(r.stringer);       // "4 ft 8 7/8 in"
    var risePhrase = fmtRisePhrase(r.riseIn);     // "3 ft"
    var angleD = fmt(r.angle, 1);                 // "33.2"

    var html = '';

    // --- 1. Plain-English answer sentence (lead = number of risers) ---
    html += '<p class="scalc-answer">';
    html += 'You need <span class="num">' + r.risers + ' ' + esc(riserWord) + '</span> at ' +
            esc(riserH) + ' ' + plural(r.riserHeight, 'inch') + ' each &mdash; with ' + r.treads + ' ' + esc(treadWord) + ' at ' +
            esc(treadD) + ' ' + plural(r.tread, 'inch') + ' deep and a stringer about ' + esc(stringerFtIn) + ' long.';
    html += '</p>';

    // --- 2. Inline IRC note ---
    var checks = [];
    if (r.riserOk) {
      checks.push('riser ' + esc(riserH) + ' ' + plural(r.riserHeight, 'inch') + ' is within the IRC max of 7\u00be inches');
    } else {
      checks.push('riser ' + esc(riserH) + ' ' + plural(r.riserHeight, 'inch') + ' EXCEEDS the IRC max of 7\u00be inches &mdash; add a landing or revise');
    }
    if (r.treadOk) {
      checks.push('tread ' + esc(treadD) + ' ' + plural(r.tread, 'inch') + ' meets the IRC min of 10 inches');
    } else {
      checks.push('tread ' + esc(treadD) + ' ' + plural(r.tread, 'inch') + ' is UNDER the IRC min of 10 inches &mdash; deepen it');
    }
    if (!r.riseOk) {
      checks.push('total rise is over 18 feet &mdash; a landing is required');
    }
    html += '<p class="scalc-note">' + checks.join('; ') + '.</p>';

    // --- 3. What this means ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What this means</h4>';
    var meaning = 'A ' + esc(risePhrase) + ' stair with ' + r.risers + ' ' + esc(riserWord) +
                  ' at ' + esc(riserH) + ' ' + plural(r.riserHeight, 'inch') + ' each needs ' + r.treads + ' ' + esc(treadWord) +
                  ' at ' + esc(treadD) + ' ' + plural(r.tread, 'inch') + ' deep. The stringer length is about ' +
                  esc(stringerFt) + ' feet (' + esc(stringerFtIn) + ', at ' + esc(angleD) +
                  '\u00b0).';
    html += '<p class="scalc-meaning">' + meaning + '</p>';

    // --- 4. What to do (bullets) ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What to do</h4>';
    html += '<ul class="scalc-todo">';
    html += '<li>Build ' + r.risers + ' ' + esc(riserWord) + ' at ' + esc(riserH) +
            ' ' + plural(r.riserHeight, 'inch') + ' each &mdash; IRC max is 7\u00be inches' + (r.riserOk ? '' : ' (revise)') + '</li>';
    html += '<li>Cut ' + r.treads + ' ' + esc(treadWord) + ' at ' + esc(treadD) +
            ' ' + plural(r.tread, 'inch') + ' deep &mdash; IRC min is 10 inches' + (r.treadOk ? '' : ' (deepen)') + '</li>';
    html += '<li>Lay out the stringer with a framing square and stair gauges</li>';
    html += '<li>Test one stringer before cutting the rest &mdash; measure twice, cut once</li>';
    html += '</ul>';

    outEl.innerHTML = html;
    resultsEl.classList.add('calculated');

    // SR live region — short summary
    if (liveEl) {
      liveEl.textContent = 'You need ' + r.risers + ' ' + riserWord + ' at ' + riserH +
                           ' ' + plural(r.riserHeight, 'inch') + ' each. The stringer is about ' + stringerFtIn + '.';
    }
  }

  function clearResults() {
    resultsEl.classList.remove('calculated');
    renderEmptyState();
    if (liveEl) liveEl.textContent = '';
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ---------- Reset ----------
  function resetForm() {
    // Defaults match the static worked example.
    $('#sc-rise-ft').value = '3';
    $('#sc-rise-in').value = '0';
    $('#sc-rise').value = '36';
    $('#sc-target').value = '7';
    $('#sc-tread').value = '11';
    var ftinRadio = formEl.querySelector('input[name="riseMode"][value="ftin"]');
    if (ftinRadio) ftinRadio.checked = true;
    setMode('ftin');
    clearResults();
  }

  // ---------- Init ----------
  var formEl, resultsEl, outEl, liveEl;

  function init() {
    formEl = document.getElementById('calc');
    resultsEl = document.getElementById('results');
    outEl = document.getElementById('out');
    liveEl = document.getElementById('live');
    if (!formEl || !resultsEl || !outEl) return;

    // Show the friendly empty state until Calculate is clicked.
    // (For noscript users, the static worked-example markup remains visible.)
    resultsEl.classList.remove('calculated');
    renderEmptyState();

    // Mode toggle for total rise entry
    formEl.addEventListener('change', function (e) {
      if (e.target.name === 'riseMode') {
        setMode(e.target.value);
      }
    });

    // Calculate / submit
    formEl.addEventListener('submit', function (e) {
      e.preventDefault();
      var r = compute();
      render(r);
      if (resultsEl.classList.contains('calculated')) {
        var rect = resultsEl.getBoundingClientRect();
        if (rect.bottom > window.innerHeight || rect.top < 0) {
          resultsEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }
    });

    // Clear button
    var clearBtn = document.getElementById('sc-clear');
    if (clearBtn) clearBtn.addEventListener('click', resetForm);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
