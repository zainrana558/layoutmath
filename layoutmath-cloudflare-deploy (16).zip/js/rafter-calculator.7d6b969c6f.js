/* Rafter calculator — two-column layout (form LEFT, results RIGHT).
   Simplified inputs (building span in feet + roof pitch dropdown,
   Calculate button). Results panel leads with RAFTER LENGTH in feet,
   then plain-English WHAT THIS MEANS and WHAT TO DO sections.
   No area, no depth, no overhang, no birdsmouth — just span + pitch.
   Formula: rafter length = (span/2) * sqrt(1 + (pitch/12)^2).
   Units are feet throughout. No live updates. */
(function () {
  'use strict';

  // ---------- Helpers ----------
  function parseNum(str) {
    if (str == null) return null;
    var s = String(str).trim();
    if (!s) return null;
    s = s.replace(/[$,\s]/g, '').replace(/[′']/g, "'").replace(/[″"]/g, '"');
    s = s.replace(/½/g, ' 1/2').replace(/¼/g, ' 1/4').replace(/¾/g, ' 3/4')
         .replace(/⅛/g, ' 1/8').replace(/⅜/g, ' 3/8').replace(/⅝/g, ' 5/8').replace(/⅞/g, ' 7/8')
         .replace(/⅓/g, ' 1/3').replace(/⅔/g, ' 2/3');
    // "5' 6"" style — treat as feet+inches -> decimal feet
    var m = s.match(/^(-?\d+(?:\.\d+)?)['′]\s*(\d+(?:\.\d+)?)["″]$/);
    if (m) {
      var inches = Number(m[1]) * 12 + Number(m[2]);
      return inches / 12;
    }
    // Plain feet with ' suffix, e.g. "24'" -> 24
    m = s.match(/^(-?\d+(?:\.\d+)?)['′]$/);
    if (m) return Number(m[1]);
    // Mixed fraction like "3 1/2"
    m = s.match(/^(-?\d+)\s+(\d+)\/(\d+)$/);
    if (m) {
      var d = Number(m[3]);
      if (d === 0) return null;
      return Number(m[1]) + Number(m[2]) / d;
    }
    // Simple fraction "3/4"
    m = s.match(/^(-?\d+)\/(\d+)$/);
    if (m) {
      var d2 = Number(m[2]);
      if (d2 === 0) return null;
      return Number(m[1]) / d2;
    }
    // Plain decimal
    if (!/^-?\d*\.?\d+$/.test(s)) return null;
    var n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  function fmt(n, d) {
    if (!Number.isFinite(n)) return '—';
    return Number(n.toFixed(d)).toString();
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function $(sel, root) { return (root || document).querySelector(sel); }

  // ---------- Compute ----------
  // rafter length = (span/2) / cos(atan(pitch/12))
  //              = (span/2) * sqrt(1 + (pitch/12)^2)
  // rise = run * (pitch/12)
  function compute() {
    var span = parseNum($('#sc-span').value);
    if (span == null || span <= 0) {
      return { ok: false, msg: 'Enter the building span in feet.' };
    }

    var pitchSel = $('#sc-pitch');
    var pitch = parseInt(pitchSel.value, 10);
    if (!Number.isFinite(pitch) || pitch <= 0) {
      return { ok: false, msg: 'Choose a roof pitch.' };
    }

    var run = span / 2;
    var ratio = pitch / 12;
    var rise = run * ratio;
    var length = run * Math.sqrt(1 + ratio * ratio);
    var angle = Math.atan(ratio) * 180 / Math.PI;

    // Lumber size recommendation based on span (feet).
    // These are rules of thumb — verify against a code span table for the
    // actual snow load, species, grade, and spacing.
    var lumber;
    if (span <= 10)      lumber = '2x6 or 2x8';
    else if (span <= 12) lumber = '2x8';
    else if (span <= 16) lumber = '2x8 or 2x10';
    else if (span <= 20) lumber = '2x10';
    else                 lumber = '2x10 or 2x12';

    return {
      ok: true,
      span: span,
      pitch: pitch,
      run: run,
      rise: rise,
      length: length,
      angle: angle,
      lumber: lumber
    };
  }

  // ---------- Render ----------
  // Simplified, calculator.net-style result panel:
  //   1. ONE plain-English sentence with the lead number bolded inline
  //   2. "What this means" — 1-2 sentence explanation
  //   3. "What to do" — 4 short bullets (not numbered)
  // No stat cards. No competing big numbers. Just clean text.
  function renderEmptyState() {
    outEl.innerHTML =
      '<div class="scalc-empty">' +
        '<p>Enter the building span and roof pitch, then click <b>Calculate</b>.</p>' +
        '<p>The answer will show:</p>' +
        '<ul>' +
          '<li>How long to cut each common rafter (in feet)</li>' +
          '<li>What that means in plain English</li>' +
          '<li>What to do next</li>' +
        '</ul>' +
      '</div>';
  }

  function render(r) {
    if (!r.ok) {
      outEl.innerHTML = '<p class="scalc-err">' + esc(r.msg) + '</p>';
      resultsEl.classList.add('calculated');
      if (liveEl) liveEl.textContent = r.msg;
      return;
    }

    var lengthStr = fmt(r.length, 2);
    var runStr    = fmt(r.run, 2);
    var riseStr   = fmt(r.rise, 2);
    var angleStr  = fmt(r.angle, 1);
    var pitchStr  = r.pitch + ':12';
    var spanStr   = fmt(r.span, 0);

    var html = '';

    // --- 1. Plain-English answer sentence (LEAD with rafter length in feet) ---
    html += '<p class="scalc-answer">';
    html += 'Each common rafter is <span class="num">' + lengthStr + ' feet</span> long ' +
            '(run ' + runStr + ' feet, rise ' + riseStr + ' feet, at ' + angleStr + '&deg;).';
    html += '</p>';

    // --- 2. What this means ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What this means</h4>';
    html += '<p class="scalc-meaning">A ' + esc(spanStr) + ' foot building with a ' + esc(pitchStr) +
            ' roof pitch needs rafters ' + esc(lengthStr) + ' feet long. The run is ' + runStr +
            ' feet and the rise is ' + riseStr + ' feet.</p>';

    // --- 3. What to do (bullets, not numbered) ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What to do</h4>';
    html += '<ul class="scalc-todo">';
    html += '<li>Cut rafters at <strong>' + lengthStr + ' feet</strong> &mdash; add 12 to 18 inches for the tail (overhang)</li>';
    html += '<li>Space rafters at 16 or 24 inches on center &mdash; 16 is standard for most roofs</li>';
    if (r.span > 12) {
      html += '<li>Use ' + esc(r.lumber) + ' lumber for spans over 12 feet &mdash; check the span table</li>';
    } else {
      html += '<li>Use ' + esc(r.lumber) + ' lumber &mdash; check the span table for your load</li>';
    }
    html += '<li>Install a ridge board at the peak, then set rafters in pairs</li>';
    html += '</ul>';

    outEl.innerHTML = html;
    resultsEl.classList.add('calculated');

    // SR live region — short summary
    if (liveEl) {
      liveEl.textContent = 'Each common rafter is ' + lengthStr + ' feet long.';
    }
  }

  function clearResults() {
    resultsEl.classList.remove('calculated');
    renderEmptyState();
    if (liveEl) liveEl.textContent = '';
  }

  // ---------- Reset ----------
  function resetForm() {
    // Defaults match the static worked example.
    $('#sc-span').value = '24';
    var pitchSel = $('#sc-pitch');
    if (pitchSel) pitchSel.value = '6';
    clearResults();
  }

  // ---------- Init ----------
  var formEl, resultsEl, outEl, liveEl;

  function init() {
    formEl = document.getElementById('calc');
    resultsEl = document.getElementById('results');
    outEl = document.getElementById('out');
    liveEl = document.getElementById('live');
    if (!formEl || !resultsEl || !outEl) return;

    // Show the friendly empty state in the results panel until Calculate is clicked.
    // (For noscript users, the static worked-example markup remains visible.)
    resultsEl.classList.remove('calculated');
    renderEmptyState();

    // Calculate / submit
    formEl.addEventListener('submit', function (e) {
      e.preventDefault();
      var r = compute();
      render(r);
      // Scroll the results into view (gentle, only if off-screen)
      if (resultsEl.classList.contains('calculated')) {
        var rect = resultsEl.getBoundingClientRect();
        if (rect.bottom > window.innerHeight || rect.top < 0) {
          resultsEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }
    });

    // Clear button
    var clearBtn = document.getElementById('sc-clear');
    if (clearBtn) clearBtn.addEventListener('click', function () {
      resetForm();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
