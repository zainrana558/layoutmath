/* Feet and inches calculator — two-column layout (form LEFT, results RIGHT).
   Inputs: Value 1 (feet + inches), Operation dropdown (+, -, x, /),
   Value 2 (feet + inches). Results panel leads with the equation and the
   result in feet and inches, then plain-English WHAT THIS MEANS and
   WHAT TO DO sections. No live updates. */
(function () {
  'use strict';

  var M_PER_FT = 0.3048;

  // ---------- Helpers ----------
  function parseNum(str) {
    if (str == null) return null;
    var s = String(str).trim();
    if (!s) return null;
    s = s.replace(/[$,\s]/g, '');
    // Simple fraction "3/4"
    var m = s.match(/^(-?\d+)\/(\d+)$/);
    if (m) {
      var d = Number(m[2]);
      if (d === 0) return null;
      return Number(m[1]) / d;
    }
    // Plain decimal
    if (!/^-?\d*\.?\d+$/.test(s)) return null;
    var n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  function fmt(n, d) {
    if (!Number.isFinite(n)) return '—';
    // Avoid negative zero in display
    if (Math.abs(n) < 0.5 * Math.pow(10, -d)) n = 0;
    return Number(n.toFixed(d)).toString();
  }

  // Fixed-decimal format that keeps trailing zeros (e.g. 8 -> "8.00").
  function fmtFixed(n, d) {
    if (!Number.isFinite(n)) return '—';
    if (Math.abs(n) < 0.5 * Math.pow(10, -d)) n = 0;
    return n.toFixed(d);
  }

  function gcd(a, b) {
    a = Math.abs(a); b = Math.abs(b);
    while (b) { var t = b; b = a % b; a = t; }
    return a || 1;
  }

  // Format a length given in decimal feet as "X ft Y in" or "X ft Y/Z in".
  // Inches are rounded to the nearest 1/16.
  function formatFeetInches(decimalFeet) {
    var sign = '';
    var abs = decimalFeet;
    if (abs < 0) { sign = '\u2212'; abs = -abs; }
    var totalInches = abs * 12;
    var feet = Math.floor(totalInches / 12 + 1e-9);
    var inches = totalInches - feet * 12;
    var sixteenths = Math.round(inches * 16);
    if (sixteenths === 16) { feet += 1; sixteenths = 0; }
    var wholeIn = Math.floor(sixteenths / 16);
    var rem = sixteenths % 16;
    var inchText;
    if (rem === 0) {
      inchText = String(wholeIn);
    } else {
      var g = gcd(rem, 16);
      var num = rem / g;
      var den = 16 / g;
      inchText = wholeIn > 0 ? (wholeIn + ' ' + num + '/' + den) : (num + '/' + den);
    }
    return {
      sign: sign,
      feet: feet,
      inches: inchText,
      text: sign + feet + ' ' + (feet === 1 ? 'foot' : 'feet') + ' ' + inchText + ' ' + (inchText === '1' ? 'inch' : 'inches')
    };
  }

  // Describe a value entered as separate feet and inches fields.
  function describeValue(ftStr, inStr) {
    var ft = parseNum(ftStr);
    var inch = parseNum(inStr);
    if (ft == null && inch == null) return '\u2014';
    if (ft == null) ft = 0;
    if (inch == null) inch = 0;
    var totalFeet = (ft * 12 + inch) / 12;
    return formatFeetInches(totalFeet).text;
  }

  // ---------- DOM ----------
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  // ---------- Compute ----------
  function compute() {
    var ft1 = parseNum($('#sc-ft1').value);
    var in1 = parseNum($('#sc-in1').value);
    var ft2 = parseNum($('#sc-ft2').value);
    var in2 = parseNum($('#sc-in2').value);
    var op = formEl.querySelector('[name="op"]').value;

    if (ft1 == null && in1 == null) {
      return { ok: false, msg: 'Enter Value 1 (feet, inches, or both).' };
    }
    if (ft2 == null && in2 == null) {
      return { ok: false, msg: 'Enter Value 2 (feet, inches, or both).' };
    }
    if (ft1 == null) ft1 = 0;
    if (in1 == null) in1 = 0;
    if (ft2 == null) ft2 = 0;
    if (in2 == null) in2 = 0;

    if (ft1 < 0 || in1 < 0 || ft2 < 0 || in2 < 0) {
      return { ok: false, msg: 'Use numbers that are zero or more.' };
    }
    if (in1 >= 12 || in2 >= 12) {
      return { ok: false, msg: 'Keep the inches under 12 — use the feet box for the rest.' };
    }

    var v1In = ft1 * 12 + in1;     // value 1 in inches
    var v2In = ft2 * 12 + in2;     // value 2 in inches
    var v2Ft = v2In / 12;          // value 2 in decimal feet (used as scalar for x and /)
    var resultIn;
    var opSymbol;

    if (op === 'add') {
      resultIn = v1In + v2In;
      opSymbol = '+';
    } else if (op === 'sub') {
      resultIn = v1In - v2In;
      opSymbol = '\u2212';
    } else if (op === 'mul') {
      // Treat value 2 as a scalar (its decimal feet value).
      resultIn = v1In * v2Ft;
      opSymbol = '\u00d7';
    } else if (op === 'div') {
      if (v2Ft === 0) {
        return { ok: false, msg: 'Cannot divide by zero. Enter a value greater than zero for Value 2.' };
      }
      resultIn = v1In / v2Ft;
      opSymbol = '\u00f7';
    } else {
      return { ok: false, msg: 'Pick an operation.' };
    }

    var resultFeet = resultIn / 12;
    var resultMeters = resultFeet * M_PER_FT;
    var formatted = formatFeetInches(resultFeet);

    return {
      ok: true,
      v1Text: describeValue($('#sc-ft1').value, $('#sc-in1').value),
      v2Text: describeValue($('#sc-ft2').value, $('#sc-in2').value),
      opSymbol: opSymbol,
      resultText: formatted.text,
      resultFeet: resultFeet,
      resultMeters: resultMeters
    };
  }

  // ---------- Render ----------
  function renderEmptyState() {
    outEl.innerHTML =
      '<div class="scalc-empty">' +
        '<p>Enter two lengths in feet and inches, pick an operation, then click <b>Calculate</b>.</p>' +
        '<p>The answer will show:</p>' +
        '<ul>' +
          '<li>The equation and the result in feet and inches</li>' +
          '<li>What that means in decimal feet and meters</li>' +
          '<li>What to do next</li>' +
        '</ul>' +
      '</div>';
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function render(r) {
    if (!r.ok) {
      outEl.innerHTML = '<p class="scalc-err">' + esc(r.msg) + '</p>';
      resultsEl.classList.add('calculated');
      if (liveEl) liveEl.textContent = r.msg;
      return;
    }

    var html = '';

    // --- 1. Plain-English answer sentence (equation with bolded result) ---
    html += '<p class="scalc-answer">';
    html += esc(r.v1Text) + ' ' + esc(r.opSymbol) + ' ' + esc(r.v2Text) + ' = ';
    html += '<span class="num">' + esc(r.resultText) + '</span>.';
    html += '</p>';

    // --- 2. What this means ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What this means</h4>';
    html += '<p class="scalc-meaning">The result is ' + fmtFixed(r.resultFeet, 2) + ' feet (' +
            fmtFixed(r.resultMeters, 2) + ' meters).</p>';

    // --- 3. What to do (bullets) ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What to do</h4>';
    html += '<ul class="scalc-todo">';
    html += '<li>Use this result for your cut list or material order</li>';
    html += '<li>For fractions: round to the nearest 1/16 inch for cutting</li>';
    html += '<li>Double-check critical measurements &mdash; measure twice, cut once</li>';
    html += '<li>Convert to decimal feet if your supplier uses that format</li>';
    html += '</ul>';

    outEl.innerHTML = html;
    resultsEl.classList.add('calculated');

    if (liveEl) {
      liveEl.textContent = r.v1Text + ' ' + r.opSymbol + ' ' + r.v2Text + ' = ' + r.resultText;
    }
  }

  function clearResults() {
    resultsEl.classList.remove('calculated');
    renderEmptyState();
    if (liveEl) liveEl.textContent = '';
  }

  // ---------- Reset ----------
  function resetForm() {
    $('#sc-ft1').value = '5';
    $('#sc-in1').value = '3';
    formEl.querySelector('[name="op"]').value = 'add';
    $('#sc-ft2').value = '2';
    $('#sc-in2').value = '9';
    clearResults();
  }

  // ---------- Init ----------
  var formEl, resultsEl, outEl, liveEl;

  function init() {
    formEl = document.getElementById('calc');
    resultsEl = document.getElementById('results');
    outEl = document.getElementById('out');
    liveEl = document.getElementById('live');
    if (!formEl || !resultsEl || !outEl) return;

    resultsEl.classList.remove('calculated');
    renderEmptyState();

    formEl.addEventListener('submit', function (e) {
      e.preventDefault();
      var r = compute();
      render(r);
      if (resultsEl.classList.contains('calculated')) {
        var rect = resultsEl.getBoundingClientRect();
        if (rect.bottom > window.innerHeight || rect.top < 0) {
          resultsEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }
    });

    var clearBtn = document.getElementById('sc-clear');
    if (clearBtn) clearBtn.addEventListener('click', function () {
      resetForm();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
