/* Baluster calculator — scalc pattern (matches gravel-calculator).
   Two-column layout (form LEFT, results RIGHT). Simpler inputs (no area mode
   radio): run length + baluster width dropdown + max spacing + optional price
   per baluster. Results panel leads with BALUSTER COUNT, lists the actual gap
   and on-center spacing, then plain-English WHAT THIS MEANS and WHAT TO DO
   sections, and an optional COST line. IRC code: 4 inch max gap (a 4 inch
   sphere cannot pass). No live updates. */
(function () {
  'use strict';

  // ---------- Unit conversion ----------
  // Length: factor to multiply by to get inches.
  var LEN_TO_IN = { in: 1, ft: 12, yd: 36, m: 39.3701, cm: 0.393701 };
  // Spacing: factor to multiply by to get inches.
  var GAP_TO_IN = { in: 1, cm: 0.393701, mm: 0.0393701 };

  // Baluster width options — values are in inches.
  var WIDTH_LABELS = {
    '1.5':   '1\u00bd inch wood',
    '2':     '2 inch metal',
    '0.625': '\u215d inch iron'
  };

  // ---------- Helpers ----------
  function parseNum(str) {
    if (str == null) return null;
    var s = String(str).trim();
    if (!s) return null;
    s = s.replace(/[$,\s]/g, '').replace(/[\u2019\u2032]/g, "'").replace(/[\u201c\u201d\u2033]/g, '"');
    s = s.replace(/\u00bd/g, ' 1/2').replace(/\u00bc/g, ' 1/4').replace(/\u00be/g, ' 3/4')
         .replace(/\u215b/g, ' 1/8').replace(/\u215c/g, ' 3/8').replace(/\u215d/g, ' 5/8').replace(/\u215e/g, ' 7/8')
         .replace(/\u2153/g, ' 1/3').replace(/\u2154/g, ' 2/3');
    var m = s.match(/^(-?\d+(?:\.\d+)?)['\u2032]\s*(\d+(?:\.\d+)?)["\u2033]$/);
    if (m) return Number(m[1]) * 12 + Number(m[2]);
    m = s.match(/^(-?\d+)\s+(\d+)\/(\d+)$/);
    if (m) {
      var d = Number(m[3]);
      if (d === 0) return null;
      return Number(m[1]) + Number(m[2]) / d;
    }
    m = s.match(/^(-?\d+)\/(\d+)$/);
    if (m) {
      var d2 = Number(m[2]);
      if (d2 === 0) return null;
      return Number(m[1]) / d2;
    }
    if (!/^-?\d*\.?\d+$/.test(s)) return null;
    var n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  function fmt(n, d) {
    if (!Number.isFinite(n)) return '\u2014';
    return Number(n.toFixed(d)).toString();
  }

  function fmtMoney(n) {
    if (!Number.isFinite(n)) return '\u2014';
    return '$' + n.toFixed(2);
  }

  // Money without trailing .00 — for per-unit prices ($4 not $4.00)
  function fmtMoneyPlain(n) {
    if (!Number.isFinite(n)) return '\u2014';
    return '$' + (Number.isInteger(n) ? String(n) : n.toFixed(2));
  }

  function plural(n, sing) {
    return (n === 1) ? sing : sing + 's';
  }

  // Format inches as a friendly fraction string: 3.75 -> "3 3/4"
  function fmtInches(n) {
    if (!Number.isFinite(n)) return '\u2014';
    var sign = n < 0 ? '-' : '';
    n = Math.abs(n);
    var whole = Math.floor(n + 1e-9);
    var frac = n - whole;
    var fracStr = '';
    if (frac > 1e-6) {
      var sixteenths = Math.round(frac * 16);
      if (sixteenths === 16) { whole += 1; }
      else if (sixteenths === 0) { /* nothing */ }
      else {
        var num = sixteenths, den = 16;
        var gcd = function (a, b) { while (b) { var t = b; b = a % b; a = t; } return a; };
        var g = gcd(num, den);
        fracStr = ' ' + (num / g) + '/' + (den / g);
      }
    }
    return sign + whole + fracStr;
  }

  // Format a length (given in inches) for display in the chosen unit.
  function fmtLength(inches, unit) {
    var v;
    if (unit === 'in') v = inches;
    else if (unit === 'ft') v = inches / 12;
    else if (unit === 'yd') v = inches / 36;
    else if (unit === 'm') v = inches / 39.3701;
    else if (unit === 'cm') v = inches / 0.393701;
    else if (unit === 'mm') v = inches / 0.0393701;
    else v = inches;
    return fmt(v, (unit === 'in' || unit === 'cm' || unit === 'mm') ? 1 : 2);
  }

  function lengthWord(unit) {
    return { in: 'in', ft: 'ft', yd: 'yd', m: 'm', cm: 'cm', mm: 'mm' }[unit] || unit;
  }

  // ---------- DOM ----------
  function $(sel, root) { return (root || document).querySelector(sel); }

  // ---------- Compute ----------
  // N balusters with N+1 equal gaps. Minimum N so every gap <= maxGap.
  //   N = floor((R - G) / (W + G)) + 1   when R > G, else N = 0.
  // Actual gap = (R - N*W) / (N+1). On-center = W + actual gap.
  function compute() {
    var runInput = $('#sc-run');
    var run = parseNum(runInput.value);
    var runUnit = formEl.querySelector('[name="runUnit"]').value;
    if (run == null || run <= 0) return { ok: false, msg: 'Enter the run length.' };

    var widthStr = formEl.querySelector('[name="width"]').value;
    var widthIn = parseNum(widthStr);
    if (widthIn == null || widthIn <= 0) return { ok: false, msg: 'Pick a baluster width.' };

    var gapInput = $('#sc-gap');
    var gap = parseNum(gapInput.value);
    var gapUnit = formEl.querySelector('[name="gapUnit"]').value;
    if (gap == null || gap <= 0) return { ok: false, msg: 'Enter a maximum spacing greater than zero.' };

    var priceInput = $('#sc-price');
    var price = parseNum(priceInput.value);
    var hasPrice = (price != null && price >= 0 && priceInput.value.trim() !== '');

    // Convert to inches
    var R = run * LEN_TO_IN[runUnit];
    var W = widthIn;
    var G = gap * GAP_TO_IN[gapUnit];

    // Compute count
    var N;
    if (R <= G + 1e-9) {
      N = 0;
    } else {
      N = Math.floor((R - G) / (W + G) + 1e-9) + 1;
      if (N < 0) N = 0;
    }

    // Actual gap and on-center spacing
    var actualGap = (N === 0) ? R : (R - N * W) / (N + 1);
    var onCenter = W + actualGap;

    // Cost
    var cost = hasPrice ? N * price : null;

    return {
      ok: true,
      count: N,
      widthIn: W,
      widthStr: widthStr,
      widthLabel: WIDTH_LABELS[widthStr] || (fmt(W, 3) + ' inch'),
      runIn: R,
      runValue: run,
      runUnit: runUnit,
      maxGapIn: G,
      maxGapValue: gap,
      maxGapUnit: gapUnit,
      actualGapIn: actualGap,
      onCenterIn: onCenter,
      hasPrice: hasPrice,
      price: price,
      cost: cost
    };
  }

  // ---------- Render ----------
  // Simplified, calculator.net-style result panel:
  //   1. ONE plain-English sentence with the lead number bolded inline
  //   2. Optional cost line (only if a price was entered)
  //   3. "What this means" — 1-2 sentence explanation
  //   4. "What to do" — 3-4 short bullets (not numbered)
  function renderEmptyState() {
    outEl.innerHTML =
      '<div class="scalc-empty">' +
        '<p>Enter the run length, baluster width and max spacing, then click <b>Calculate</b>.</p>' +
        '<p>The answer will show:</p>' +
        '<ul>' +
          '<li>How many balusters to buy</li>' +
          '<li>The actual gap and on-center spacing</li>' +
          '<li>What that means in plain English</li>' +
          '<li>What to do next</li>' +
        '</ul>' +
      '</div>';
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function render(r) {
    if (!r.ok) {
      outEl.innerHTML = '<p class="scalc-err">' + esc(r.msg) + '</p>';
      resultsEl.classList.add('calculated');
      if (liveEl) liveEl.textContent = r.msg;
      return;
    }

    var N = r.count;
    var runPhrase = fmtLength(r.runIn, r.runUnit) + ' ' + lengthWord(r.runUnit);
    var widthPhrase = r.widthLabel;
    var maxGapPhrase = fmtLength(r.maxGapIn, 'in') + ' inches';
    var actualGapPhrase = fmtInches(r.actualGapIn) + '\u2033 (' + fmt(r.actualGapIn, 2) + '\u2033)';
    var onCenterPhrase = fmtInches(r.onCenterIn) + '\u2033 (' + fmt(r.onCenterIn, 2) + '\u2033)';

    var html = '';

    // --- 1. Plain-English answer sentence ---
    html += '<p class="scalc-answer">';
    if (N === 0) {
      html += 'You need <span class="num">0 balusters</span> &mdash; the run is shorter than the max gap, so it is left open.';
    } else {
      html += 'You need <span class="num">' + N + ' ' + esc(plural(N, 'baluster')) + '</span> for a ' +
              esc(runPhrase) + ' run (' + esc(actualGapPhrase) + ' gaps, ' + esc(onCenterPhrase) + ' on center).';
    }
    html += '</p>';

    // --- 2. Cost line (only if a price was entered) ---
    if (r.hasPrice && r.cost != null) {
      html += '<p class="scalc-cost-line">At ' + esc(fmtMoneyPlain(r.price)) + ' per baluster, the total cost is about <strong>' +
              esc(fmtMoney(r.cost)) + '</strong>.</p>';
    }

    // --- 3. What this means ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What this means</h4>';
    var meaning = 'A ' + esc(runPhrase) + ' run with ' + esc(widthPhrase) + ' at ' + esc(maxGapPhrase) +
                  ' spacing needs this many balusters. IRC code requires a 4 inch maximum gap &mdash; a 4 inch sphere cannot pass.';
    html += '<p class="scalc-meaning">' + meaning + '</p>';

    // --- 4. What to do (bullets, not numbered) ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What to do</h4>';
    html += '<ul class="scalc-todo">';
    var bays = N + 1;
    html += '<li>Buy ' + N + ' ' + esc(plural(N, 'baluster')) + ' (' + esc(widthPhrase) + ') for your ' + esc(runPhrase) + ' run</li>';
    html += '<li>Space them at ' + esc(maxGapPhrase) + ' or less &mdash; IRC code requires a 4 inch max gap</li>';
    html += '<li>Mark the run in ' + bays + ' equal ' + esc(plural(bays, 'bay')) + ', then lay out balusters within each bay</li>';
    html += '<li>Attach with screws or nails at top and bottom, plumb before fastening</li>';
    html += '</ul>';

    outEl.innerHTML = html;
    resultsEl.classList.add('calculated');

    // SR live region — short summary
    if (liveEl) {
      liveEl.textContent = 'You need ' + N + ' ' + plural(N, 'baluster') + ' for a ' + runPhrase + ' run.';
    }
  }

  function clearResults() {
    resultsEl.classList.remove('calculated');
    renderEmptyState();
    if (liveEl) liveEl.textContent = '';
  }

  // ---------- Reset ----------
  function resetForm() {
    // Defaults match the static worked example (13 balusters, 3.75" gap).
    $('#sc-run').value = '6';
    formEl.querySelector('[name="runUnit"]').value = 'ft';
    formEl.querySelector('[name="width"]').value = '1.5';
    $('#sc-gap').value = '4';
    formEl.querySelector('[name="gapUnit"]').value = 'in';
    $('#sc-price').value = '';
    clearResults();
  }

  // ---------- Init ----------
  var formEl, resultsEl, outEl, liveEl;

  function init() {
    formEl = document.getElementById('calc');
    resultsEl = document.getElementById('results');
    outEl = document.getElementById('out');
    liveEl = document.getElementById('live');
    if (!formEl || !resultsEl || !outEl) return;

    // Show the friendly empty state in the results panel until Calculate is clicked.
    // (For noscript users, the static worked-example markup remains visible.)
    resultsEl.classList.remove('calculated');
    renderEmptyState();

    // Calculate / submit
    formEl.addEventListener('submit', function (e) {
      e.preventDefault();
      var r = compute();
      render(r);
      // Scroll the results into view (gentle, only if off-screen)
      if (resultsEl.classList.contains('calculated')) {
        var rect = resultsEl.getBoundingClientRect();
        if (rect.bottom > window.innerHeight || rect.top < 0) {
          resultsEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }
    });

    // Clear button
    var clearBtn = document.getElementById('sc-clear');
    if (clearBtn) clearBtn.addEventListener('click', function () {
      resetForm();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
