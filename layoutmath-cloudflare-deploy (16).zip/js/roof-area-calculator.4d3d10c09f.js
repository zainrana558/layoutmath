/* Roof area calculator — two-column layout (form LEFT, results RIGHT).
   Simplified inputs (building length + building width + roof pitch
   dropdown 1:12 to 12:12, Calculate button). Results panel leads with
   SQUARE FEET of roof surface, then plain-English WHAT THIS MEANS and
   WHAT TO DO sections. Units are spelled out. No live updates. */
(function () {
  'use strict';

  // ---------- Pitch multipliers ----------
  // roof area = footprint area × pitch multiplier
  // multiplier = sqrt(1 + (rise/12)^2), rounded to 3 decimals per industry tables.
  var PITCH_MULTIPLIERS = {
    1: 1.003, 2: 1.014, 3: 1.031, 4: 1.054, 5: 1.083,
    6: 1.118, 7: 1.158, 8: 1.202, 9: 1.250, 10: 1.302, 12: 1.414
  };

  // ---------- Unit conversion ----------
  // Length: factor to multiply by to get feet.
  var LEN_TO_FT = { ft: 1, m: 3.28084, yd: 3, in: 1 / 12, cm: 0.0328084 };
  // Square feet back to a target area unit.
  var SQFT_TO_AREA = { sqft: 1, sqm: 1 / 10.7639, sqyd: 1 / 9 };
  var AREA_WORDS = { sqft: 'square feet', sqm: 'square meters', sqyd: 'square yards' };
  var AREA_ATTR = { sqft: 'square foot', sqm: 'square meter', sqyd: 'square yard' };
  var LEN_WORD = { ft: 'foot', m: 'meter', yd: 'yard', in: 'inch', cm: 'cm' };
  var LEN_ABBR = { ft: 'ft', m: 'm', yd: 'yd', in: 'in', cm: 'cm' };

  // ---------- Constants ----------
  var SQFT_PER_SQUARE = 100;         // 1 roofing square = 100 sq ft
  var WASTE_PCT = 10;                // +10% for cuts, valleys, hips
  var LIN_FT_PER_RIDGE_BUNDLE = 20;  // one bundle of hip-and-ridge caps covers ~20 linear ft

  // ---------- Helpers ----------
  function parseNum(str) {
    if (str == null) return null;
    var s = String(str).trim();
    if (!s) return null;
    // Allow $, common unit suffixes and fraction chars.
    s = s.replace(/[$,\s]/g, '').replace(/[′’]/g, "'").replace(/[″“”]/g, '"');
    s = s.replace(/½/g, ' 1/2').replace(/¼/g, ' 1/4').replace(/¾/g, ' 3/4')
         .replace(/⅛/g, ' 1/8').replace(/⅜/g, ' 3/8').replace(/⅝/g, ' 5/8').replace(/⅞/g, ' 7/8')
         .replace(/⅓/g, ' 1/3').replace(/⅔/g, ' 2/3');
    // "5' 6"" style — treat as feet+inches if it has ' and "
    var m = s.match(/^(-?\d+(?:\.\d+)?)['′]\s*(\d+(?:\.\d+)?)["″]$/);
    if (m) return Number(m[1]) * 12 + Number(m[2]);
    // Mixed fraction like "3 1/2"
    m = s.match(/^(-?\d+)\s+(\d+)\/(\d+)$/);
    if (m) {
      var d = Number(m[3]);
      if (d === 0) return null;
      return Number(m[1]) + Number(m[2]) / d;
    }
    // Simple fraction "3/4"
    m = s.match(/^(-?\d+)\/(\d+)$/);
    if (m) {
      var d2 = Number(m[2]);
      if (d2 === 0) return null;
      return Number(m[1]) / d2;
    }
    // Plain decimal
    if (!/^-?\d*\.?\d+$/.test(s)) return null;
    var n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  function fmt(n, d) {
    if (!Number.isFinite(n)) return '—';
    return Number(n.toFixed(d)).toString();
  }

  // Group-formatted integer (e.g. 1,342)
  function fmtInt(n) {
    if (!Number.isFinite(n)) return '—';
    return Math.round(n).toLocaleString('en-US');
  }

  function plural(n, sing) {
    return (n === 1) ? sing : sing + 's';
  }

  // ---------- DOM ----------
  function $(sel, root) { return (root || document).querySelector(sel); }

  // ---------- Description helpers ----------
  // "40 × 30 foot" (same unit, singular attributive) OR "40 feet × 9 meters" (mixed, spelled out).
  function describeDims(len, wid, lenUnit, widUnit) {
    var lv = fmtDim(len, lenUnit);
    var wv = fmtDim(wid, widUnit);
    if (lenUnit === widUnit) {
      return lv + ' \u00d7 ' + wv + ' ' + (LEN_WORD[lenUnit] || lenUnit);
    }
    return lv + ' ' + lenUnitWord(len, lenUnit) + ' \u00d7 ' + wv + ' ' + lenUnitWord(wid, widUnit);
  }
  // Plural-aware spelled-out unit word for a length value (used in mixed-unit display).
  function lenUnitWord(n, unit) {
    if (unit === 'ft') return n === 1 ? 'foot' : 'feet';
    if (unit === 'in') return n === 1 ? 'inch' : 'inches';
    if (unit === 'cm') return 'cm';
    var sing = LEN_WORD[unit] || unit;
    return n === 1 ? sing : sing + 's';
  }
  function fmtDim(n, unit) {
    return (unit === 'in' || unit === 'cm') ? fmt(n, 1) : fmt(n, 0);
  }
  // "1,342 square feet" / "12.4 square meters" — plural noun form (area count).
  function describeAreaWords(value, unit) {
    var v = (value >= 100) ? fmtInt(value) : fmt(value, 1);
    return v + ' ' + AREA_WORDS[unit];
  }
  // "1,200 square foot" / "100 square meter" — singular attributive form (footprint modifier).
  function describeAreaAttr(value, unit) {
    var v = (value >= 100) ? fmtInt(value) : fmt(value, 1);
    return v + ' ' + AREA_ATTR[unit];
  }

  // ---------- Compute ----------
  function compute() {
    var lenInput = $('#sc-len');
    var len = parseNum(lenInput.value);
    var lenUnit = formEl.querySelector('[name="lenUnit"]').value;
    if (len == null || len <= 0) return { ok: false, msg: 'Enter the building length.' };

    var widInput = $('#sc-wid');
    var wid = parseNum(widInput.value);
    var widUnit = formEl.querySelector('[name="widUnit"]').value;
    if (wid == null || wid <= 0) return { ok: false, msg: 'Enter the building width.' };

    var pitch = String(formEl.querySelector('[name="pitch"]').value);
    var mult = PITCH_MULTIPLIERS[pitch];
    if (mult == null) return { ok: false, msg: 'Pick a roof pitch.' };

    var lenFt = len * LEN_TO_FT[lenUnit];
    var widFt = wid * LEN_TO_FT[widUnit];
    var footprintSqft = lenFt * widFt;
    var roofSqft = footprintSqft * mult;
    var squares = roofSqft / SQFT_PER_SQUARE;
    var squaresToBuy = Math.ceil(squares * (1 + WASTE_PCT / 100) - 1e-9);
    // Ridge runs the length of the building (simple gable). One bundle covers ~20 linear ft.
    var ridgeBundles = Math.ceil(lenFt / LIN_FT_PER_RIDGE_BUNDLE - 1e-9);

    // Pick a friendly primary area unit based on the length unit.
    var primaryAreaUnit = 'sqft';
    if (lenUnit === 'm' || lenUnit === 'cm') primaryAreaUnit = 'sqm';
    else if (lenUnit === 'yd') primaryAreaUnit = 'sqyd';

    return {
      ok: true,
      len: len, lenUnit: lenUnit,
      wid: wid, widUnit: widUnit,
      lenFt: lenFt,
      pitch: pitch, mult: mult,
      footprintSqft: footprintSqft,
      roofSqft: roofSqft,
      squares: squares,
      squaresToBuy: squaresToBuy,
      ridgeBundles: ridgeBundles,
      primaryAreaUnit: primaryAreaUnit,
      primaryRoofArea: roofSqft * SQFT_TO_AREA[primaryAreaUnit],
      primaryFootprint: footprintSqft * SQFT_TO_AREA[primaryAreaUnit]
    };
  }

  // ---------- Render ----------
  // Simplified, calculator.net-style result panel:
  //   1. ONE plain-English sentence with the lead number bolded inline
  //   2. "What this means" — 1-2 sentence explanation
  //   3. "What to do" — short bullets (not numbered)
  // No stat cards. No competing big numbers. Just clean text.
  function renderEmptyState() {
    outEl.innerHTML =
      '<div class="scalc-empty">' +
        '<p>Enter the building length, building width, and roof pitch, then click <b>Calculate</b>.</p>' +
        '<p>The answer will show:</p>' +
        '<ul>' +
          '<li>Square feet of roof surface (and roofing squares)</li>' +
          '<li>What that means in plain English</li>' +
          '<li>What to do next</li>' +
        '</ul>' +
      '</div>';
  }

  function render(r) {
    if (!r.ok) {
      outEl.innerHTML = '<p class="scalc-err">' + esc(r.msg) + '</p>';
      resultsEl.classList.add('calculated');
      if (liveEl) liveEl.textContent = r.msg;
      return;
    }

    var dimsPhrase        = describeDims(r.len, r.wid, r.lenUnit, r.widUnit);
    var areaPhrase        = describeAreaWords(r.primaryRoofArea, r.primaryAreaUnit);     // "1,342 square feet" (count)
    var footprintAttr     = describeAreaAttr(r.primaryFootprint, r.primaryAreaUnit);   // "1,200 square foot" (attributive)
    var multPlain         = fmt(r.mult, 3);
    var pctMore           = (r.mult - 1) * 100;

    var html = '';

    // --- 1. Plain-English answer sentence ---
    html += '<p class="scalc-answer">';
    html += 'A ' + esc(dimsPhrase) + ' building with a ' + esc(r.pitch) + ':12 roof has about <span class="num">' +
            esc(areaPhrase) + '</span> of roof surface. ';
    html += 'That&rsquo;s ' + esc(multPlain) + ' times the ' + esc(footprintAttr) + ' footprint.';
    html += '</p>';

    // --- 2. What this means ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What this means</h4>';
    var meaning = 'The roof is bigger than the footprint because it slopes. A ' + esc(r.pitch) + ':12 pitch makes the roof about ' +
                  fmt(pctMore, 1) + ' percent larger than the ' + esc(footprintAttr) + ' building below it. ' +
                  'Roofing is sold by the &ldquo;square&rdquo; &mdash; one square covers 100 square feet.';
    html += '<p class="scalc-meaning">' + meaning + '</p>';

    // --- 3. What to do (bullets, not numbered) ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What to do</h4>';
    html += '<ul class="scalc-todo">';
    html += '<li>Order ' + r.squaresToBuy + ' ' + plural(r.squaresToBuy, 'square') + ' of shingles (1 square = 100 sq ft) plus 10 percent for waste</li>';
    html += '<li>Add ' + r.ridgeBundles + ' ' + plural(r.ridgeBundles, 'bundle') + ' of ridge caps for the peak</li>';
    html += '<li>Install underlayment (30 pound felt) over the entire roof before shingles</li>';
    html += '<li>Use drip edge on all eaves and rakes to prevent water damage</li>';
    html += '</ul>';

    outEl.innerHTML = html;
    resultsEl.classList.add('calculated');

    // SR live region — short summary
    if (liveEl) {
      liveEl.textContent = 'About ' + fmtInt(r.primaryRoofArea) + ' ' + AREA_WORDS[r.primaryAreaUnit] + ' of roof surface.';
    }
  }

  function clearResults() {
    resultsEl.classList.remove('calculated');
    renderEmptyState();
    if (liveEl) liveEl.textContent = '';
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ---------- Reset ----------
  function resetForm() {
    // Defaults match the static worked example.
    $('#sc-len').value = '40';
    formEl.querySelector('[name="lenUnit"]').value = 'ft';
    $('#sc-wid').value = '30';
    formEl.querySelector('[name="widUnit"]').value = 'ft';
    formEl.querySelector('[name="pitch"]').value = '6';
    clearResults();
  }

  // ---------- Init ----------
  var formEl, resultsEl, outEl, liveEl;

  function init() {
    formEl = document.getElementById('calc');
    resultsEl = document.getElementById('results');
    outEl = document.getElementById('out');
    liveEl = document.getElementById('live');
    if (!formEl || !resultsEl || !outEl) return;

    // Show the friendly empty state in the results panel until Calculate is clicked.
    // (For noscript users, the static worked-example markup remains visible.)
    resultsEl.classList.remove('calculated');
    renderEmptyState();

    // Calculate / submit
    formEl.addEventListener('submit', function (e) {
      e.preventDefault();
      var r = compute();
      render(r);
      // Scroll the results into view (gentle, only if off-screen)
      if (resultsEl.classList.contains('calculated')) {
        var rect = resultsEl.getBoundingClientRect();
        if (rect.bottom > window.innerHeight || rect.top < 0) {
          resultsEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }
    });

    // Clear button
    var clearBtn = document.getElementById('sc-clear');
    if (clearBtn) clearBtn.addEventListener('click', resetForm);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
