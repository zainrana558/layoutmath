/* Deck calculator — two-column layout (form LEFT, results RIGHT).
   Simplified inputs (radio toggle, +add area rows, Calculate button).
   Results panel leads with BOARD COUNT, lists equivalent linear feet, then
   plain-English WHAT THIS MEANS and WHAT TO DO sections, and an optional
   COST line. Units are spelled out. No live updates.
   Assumes 16-foot stock boards, a 1/8 inch gap, and 10% waste — the standard
   for pressure-treated 5/4×6 decking. */
(function () {
  'use strict';

  // ---------- Assumptions (sensible defaults) ----------
  // Stock board length, feet. 16 ft is the most common deck-board length.
  var BOARD_LENGTH_FT = 16;
  // Gap between boards, inches. 1/8" is typical for wood decking.
  var GAP_IN = 0.125;
  // Waste factor for cuts and mistakes. 10% for a straight layout.
  var WASTE_PCT = 10;

  // ---------- Unit conversion tables ----------
  // All inputs are converted to a common internal unit (feet for length,
  // square feet for area). Results are converted out where needed.

  // Length: factor to multiply by to get feet.
  var LEN_TO_FT = { ft: 1, m: 3.28084, yd: 3, in: 1 / 12, cm: 0.0328084 };
  // Area: factor to multiply by to get square feet.
  var AREA_TO_SQFT = { sqft: 1, sqm: 10.7639, sqyd: 9, acre: 43560 };
  // Square feet back to a target area unit.
  var SQFT_TO_AREA = { sqft: 1, sqm: 1 / 10.7639, sqyd: 1 / 9, acre: 1 / 43560 };
  var AREA_WORDS = { sqft: 'square feet', sqm: 'square meters', sqyd: 'square yards', acre: 'acres' };

  // Short label for each board-width option, used in prose.
  var BOARD_SHORT = {
    '5.5': '5.5 inch',
    '3.5': '3.5 inch',
    '7.25': '7.25 inch'
  };
  // Nominal name for each board-width option, shown in the lead sentence.
  var BOARD_NOMINAL = {
    '5.5': '5.5 inch (5/4×6 standard)',
    '3.5': '3.5 inch (2×4)',
    '7.25': '7.25 inch (2×6)'
  };

  // ---------- Helpers ----------
  function parseNum(str) {
    if (str == null) return null;
    var s = String(str).trim();
    if (!s) return null;
    // Allow $ and common unit suffixes / fraction chars.
    s = s.replace(/[$,\s]/g, '').replace(/[′’]/g, "'").replace(/[″“”]/g, '"');
    s = s.replace(/½/g, ' 1/2').replace(/¼/g, ' 1/4').replace(/¾/g, ' 3/4')
         .replace(/⅛/g, ' 1/8').replace(/⅜/g, ' 3/8').replace(/⅝/g, ' 5/8').replace(/⅞/g, ' 7/8')
         .replace(/⅓/g, ' 1/3').replace(/⅔/g, ' 2/3');
    // "5' 6"" style or "5-6" style — treat as feet+inches if it has ' and "
    var m = s.match(/^(-?\d+(?:\.\d+)?)['′]\s*(\d+(?:\.\d+)?)["″]$/);
    if (m) return Number(m[1]) * 12 + Number(m[2]);
    // Mixed fraction like "3 1/2"
    m = s.match(/^(-?\d+)\s+(\d+)\/(\d+)$/);
    if (m) {
      var d = Number(m[3]);
      if (d === 0) return null;
      return Number(m[1]) + Number(m[2]) / d;
    }
    // Simple fraction "3/4"
    m = s.match(/^(-?\d+)\/(\d+)$/);
    if (m) {
      var d2 = Number(m[2]);
      if (d2 === 0) return null;
      return Number(m[1]) / d2;
    }
    // Plain decimal
    if (!/^-?\d*\.?\d+$/.test(s)) return null;
    var n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  function fmt(n, d) {
    if (!Number.isFinite(n)) return '—';
    return Number(n.toFixed(d)).toString();
  }

  function fmtMoney(n, cur) {
    if (!Number.isFinite(n)) return '—';
    var sym = cur === 'GBP' ? '£' : cur === 'EUR' ? '€' : '$';
    return sym + n.toFixed(2);
  }

  // Money without trailing .00 — for per-unit prices ($22 not $22.00)
  function fmtMoneyPlain(n, cur) {
    if (!Number.isFinite(n)) return '—';
    var sym = cur === 'GBP' ? '£' : cur === 'EUR' ? '€' : '$';
    return sym + (Number.isInteger(n) ? String(n) : n.toFixed(2));
  }

  function plural(n, sing) {
    return (n === 1) ? sing : sing + 's';
  }

  function describeAreaWords(value, unit) {
    var v = (unit === 'acre') ? fmt(value, 2)
            : (value >= 100 ? fmt(value, 0) : fmt(value, 1));
    return v + ' ' + AREA_WORDS[unit];
  }

  // ---------- DOM ----------
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  // ---------- Row management for "Enter dimensions" ----------
  var MAX_ROWS = 5;
  function rowTemplate(idx) {
    var wrap = document.createElement('div');
    wrap.className = 'scalc-row';
    wrap.setAttribute('data-row', '');
    wrap.innerHTML =
      '<div class="field"><label for="sc-len-' + idx + '">Length</label>' +
        '<div class="inp">' +
          '<input id="sc-len-' + idx + '" name="len' + idx + '" type="text" inputmode="decimal" autocomplete="off" spellcheck="false" value="">' +
          '<select class="sc-unit" name="lenUnit' + idx + '" aria-label="Length unit">' +
            '<option value="ft" selected>ft</option><option value="m">m</option><option value="yd">yd</option><option value="in">in</option><option value="cm">cm</option>' +
          '</select>' +
        '</div>' +
      '</div>' +
      '<span class="scalc-x" aria-hidden="true">×</span>' +
      '<div class="field"><label for="sc-wid-' + idx + '">Width</label>' +
        '<div class="inp">' +
          '<input id="sc-wid-' + idx + '" name="wid' + idx + '" type="text" inputmode="decimal" autocomplete="off" spellcheck="false" value="">' +
          '<select class="sc-unit" name="widUnit' + idx + '" aria-label="Width unit">' +
            '<option value="ft" selected>ft</option><option value="m">m</option><option value="yd">yd</option><option value="in">in</option><option value="cm">cm</option>' +
          '</select>' +
        '</div>' +
      '</div>' +
      '<button type="button" class="scalc-del needs-js" data-del aria-label="Remove this area">&times;</button>';
    return wrap;
  }

  function refreshRowsUI() {
    var rows = $all('.scalc-row', rowsEl);
    var n = rows.length;
    rows.forEach(function (r) {
      var del = r.querySelector('[data-del]');
      if (del) del.hidden = (n <= 1);
    });
    var addBtn = $('#sc-addrow');
    if (addBtn) addBtn.hidden = (n >= MAX_ROWS);
    var help = $('.scalc-rowhelp');
    if (help) help.hidden = (n < 2);
  }

  function addRow() {
    var rows = $all('.scalc-row', rowsEl);
    if (rows.length >= MAX_ROWS) return;
    var idx = rows.length;
    var newRow = rowTemplate(idx);
    rowsEl.appendChild(newRow);
    refreshRowsUI();
    // Focus the new length input
    var inp = newRow.querySelector('input');
    if (inp) inp.focus();
  }

  function removeRow(btn) {
    var row = btn.closest('.scalc-row');
    if (!row || $all('.scalc-row', rowsEl).length <= 1) return;
    row.remove();
    refreshRowsUI();
  }

  // ---------- Area mode toggle ----------
  function setMode(mode) {
    $all('.scalc-section', formEl).forEach(function (sec) {
      sec.hidden = (sec.getAttribute('data-mode') !== mode);
    });
  }

  // ---------- Compute area ----------
  function computeAreaSqft() {
    var mode = formEl.querySelector('input[name="areaMode"]:checked');
    mode = mode ? mode.value : 'total';
    if (mode === 'total') {
      var area = parseNum($('#sc-area').value);
      var areaUnit = formEl.querySelector('[name="areaUnit"]').value;
      if (area == null || area <= 0) return { ok: false, msg: 'Enter the deck area to cover.' };
      return {
        ok: true,
        sqft: area * AREA_TO_SQFT[areaUnit],
        describe: describeArea(area, areaUnit),
        primaryAreaValue: area,
        primaryAreaUnit: areaUnit
      };
    } else {
      var rows = $all('.scalc-row', rowsEl);
      var total = 0;
      var parts = [];
      var firstLenUnit = 'ft';
      for (var i = 0; i < rows.length; i++) {
        var len = parseNum(rows[i].querySelector('input[name^="len"]').value);
        var lenUnit = rows[i].querySelector('[name^="lenUnit"]').value;
        var wid = parseNum(rows[i].querySelector('input[name^="wid"]').value);
        var widUnit = rows[i].querySelector('[name^="widUnit"]').value;
        if (len == null || len <= 0 || wid == null || wid <= 0) {
          return { ok: false, msg: 'Enter length and width for every area.' };
        }
        var lf = len * LEN_TO_FT[lenUnit];
        var wf = wid * LEN_TO_FT[widUnit];
        total += lf * wf;
        parts.push(describeDim(len, lenUnit, wid, widUnit));
        if (i === 0) firstLenUnit = lenUnit;
      }
      // Pick a friendly primary area unit based on the first row's length unit.
      var primaryAreaUnit = 'sqft';
      if (firstLenUnit === 'm' || firstLenUnit === 'cm') primaryAreaUnit = 'sqm';
      else if (firstLenUnit === 'yd') primaryAreaUnit = 'sqyd';
      var primaryAreaValue = total * SQFT_TO_AREA[primaryAreaUnit];
      return {
        ok: true,
        sqft: total,
        describe: parts.join(' + '),
        primaryAreaValue: primaryAreaValue,
        primaryAreaUnit: primaryAreaUnit
      };
    }
  }

  function describeArea(n, unit) {
    var labels = { sqft: 'ft²', sqm: 'm²', sqyd: 'yd²', acre: 'acres' };
    var v = (unit === 'acre') ? fmt(n, 2) : fmt(n, 0);
    return v + ' ' + labels[unit];
  }
  function describeDim(l, lu, w, wu) {
    var lbl = { ft: 'ft', m: 'm', yd: 'yd', in: 'in', cm: 'cm' };
    return fmt(l, 0) + lbl[lu] + ' × ' + fmt(w, 0) + lbl[wu];
  }

  // ---------- Compute ----------
  function compute() {
    var areaRes = computeAreaSqft();
    if (!areaRes.ok) return areaRes;

    var boardWidth = parseFloat(formEl.querySelector('[name="boardWidth"]').value);
    if (!Number.isFinite(boardWidth) || boardWidth <= 0) {
      return { ok: false, msg: 'Pick a board width.' };
    }
    var spacing = parseInt(formEl.querySelector('[name="spacing"]').value, 10);
    if (!Number.isFinite(spacing) || spacing <= 0) {
      return { ok: false, msg: 'Pick a joist spacing.' };
    }

    // Optional price per board
    var priceInput = $('#sc-price');
    var price = parseNum(priceInput.value);
    var hasPrice = (price != null && price >= 0 && priceInput.value.trim() !== '');

    // Linear feet of decking needed to cover the area.
    // coverage_per_row_ft = (board_width + gap) / 12   → feet of width per row
    // linear_ft = area_sqft / coverage_per_row_ft
    var coveragePerRowFt = (boardWidth + GAP_IN) / 12;
    var linearFt = areaRes.sqft / coveragePerRowFt;

    // Whole boards needed before waste, assuming BOARD_LENGTH_FT stock.
    var boardsNoWaste = Math.ceil(linearFt / BOARD_LENGTH_FT - 1e-9);
    if (boardsNoWaste < 1) boardsNoWaste = 1;
    // Add waste, round up to a whole board.
    var boards = Math.ceil(boardsNoWaste * (1 + WASTE_PCT / 100) - 1e-9);

    // Cost
    var cost = null;
    if (hasPrice) cost = boards * price;

    return {
      ok: true,
      boards: boards,
      boardsNoWaste: boardsNoWaste,
      linearFt: linearFt,
      cost: cost,
      hasPrice: hasPrice,
      price: price,
      boardWidth: boardWidth,
      spacing: spacing,
      areaDesc: areaRes.describe,
      primaryAreaValue: areaRes.primaryAreaValue,
      primaryAreaUnit: areaRes.primaryAreaUnit
    };
  }

  // ---------- Render ----------
  // Simplified, calculator.net-style result panel:
  //   1. ONE plain-English sentence with the lead number bolded inline
  //   2. Optional cost line (only if a price was entered)
  //   3. "What this means" — 1-2 sentence explanation
  //   4. "What to do" — 4 short bullets (not numbered)
  // No stat cards. No competing big numbers. Just clean text.
  function renderEmptyState() {
    outEl.innerHTML =
      '<div class="scalc-empty">' +
        '<p>Enter your deck area and board size, then click <b>Calculate</b>.</p>' +
        '<p>The answer will show:</p>' +
        '<ul>' +
          '<li>How many deck boards to buy (with 10% extra for cuts and waste)</li>' +
          '<li>What that means in plain English</li>' +
          '<li>What to do next</li>' +
        '</ul>' +
      '</div>';
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function render(r) {
    if (!r.ok) {
      outEl.innerHTML = '<p class="scalc-err">' + esc(r.msg) + '</p>';
      resultsEl.classList.add('calculated');
      if (liveEl) liveEl.textContent = r.msg;
      return;
    }

    var boards = r.boards;
    var boardWord = plural(boards, 'deck board');
    var bwKey = String(r.boardWidth);
    var boardShort = BOARD_SHORT[bwKey] || (fmt(r.boardWidth, 2) + ' inch');
    var areaPhrase = describeAreaWords(r.primaryAreaValue, r.primaryAreaUnit);

    var html = '';

    // --- 1. Plain-English answer sentence (lead with board count) ---
    html += '<p class="scalc-answer">';
    html += 'You need about <span class="num">' + boards + ' ' + esc(boardWord) + '</span> ' +
            '(' + esc(boardShort) + ', ' + BOARD_LENGTH_FT + '-foot stock) ' +
            '&mdash; about ' + fmt(r.linearFt, 0) + ' linear feet of decking.';
    html += '</p>';

    // --- 2. Cost line (only if a price was entered) ---
    if (r.hasPrice && r.cost != null) {
      html += '<p class="scalc-cost-line">At ' + esc(fmtMoneyPlain(r.price, 'USD')) + ' per board, ' +
              'the total cost is about <strong>' + esc(fmtMoney(r.cost, 'USD')) + '</strong>.</p>';
    }

    // --- 3. What this means ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What this means</h4>';
    var meaning = 'Covering ' + esc(areaPhrase) + ' with ' + esc(boardShort) + ' deck boards on ' +
                  r.spacing + ' inch joist centers uses this many boards, with ' + WASTE_PCT +
                  ' percent extra for cuts and waste.';
    html += '<p class="scalc-meaning">' + meaning + '</p>';

    // --- 4. What to do (bullets, not numbered) ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What to do</h4>';
    html += '<ul class="scalc-todo">';
    html += '<li>Buy ' + boards + ' ' + esc(boardWord) + ' (' + esc(boardShort) + ') plus ' +
            WASTE_PCT + ' percent extra for cuts and waste</li>';
    html += '<li>Space joists at ' + r.spacing + ' inches on center ' +
            '(12 inches for diagonal decking, 24 inches for 2&times;6 boards)</li>';
    html += '<li>Fasten boards with 2 screws per joist, gap boards 1/8 to 1/4 inch for drainage</li>';
    html += '<li>Seal or stain cut ends to prevent moisture damage</li>';
    html += '</ul>';

    outEl.innerHTML = html;
    resultsEl.classList.add('calculated');

    // SR live region — short summary
    if (liveEl) {
      liveEl.textContent = 'You need about ' + boards + ' ' + boardWord + '.';
    }
  }

  function clearResults() {
    resultsEl.classList.remove('calculated');
    renderEmptyState();
    if (liveEl) liveEl.textContent = '';
  }

  // ---------- Reset ----------
  function resetForm() {
    // Defaults match the static worked example (192 sqft, 5.5" boards, 16" joists -> 29 boards).
    $('#sc-area').value = '192';
    formEl.querySelector('[name="areaUnit"]').value = 'sqft';
    // Reset dimensions: keep just 1 row with default values
    var rows = $all('.scalc-row', rowsEl);
    for (var i = 1; i < rows.length; i++) rows[i].remove();
    var firstRow = rows[0];
    if (firstRow) {
      firstRow.querySelector('input[name^="len"]').value = '16';
      firstRow.querySelector('[name^="lenUnit"]').value = 'ft';
      firstRow.querySelector('input[name^="wid"]').value = '12';
      firstRow.querySelector('[name^="widUnit"]').value = 'ft';
    }
    formEl.querySelector('[name="boardWidth"]').value = '5.5';
    formEl.querySelector('[name="spacing"]').value = '16';
    $('#sc-price').value = '';
    // Default mode
    var totalRadio = formEl.querySelector('input[name="areaMode"][value="total"]');
    if (totalRadio) totalRadio.checked = true;
    setMode('total');
    refreshRowsUI();
    clearResults();
  }

  // ---------- Init ----------
  var formEl, rowsEl, resultsEl, outEl, liveEl;

  function init() {
    formEl = document.getElementById('calc');
    rowsEl = document.getElementById('sc-rows');
    resultsEl = document.getElementById('results');
    outEl = document.getElementById('out');
    liveEl = document.getElementById('live');
    if (!formEl || !resultsEl || !outEl) return;

    // Initial UI state
    refreshRowsUI();

    // Show the friendly empty state in the results panel until Calculate is clicked.
    // (For noscript users, the static worked-example markup remains visible.)
    resultsEl.classList.remove('calculated');
    renderEmptyState();

    // Radio toggle for area mode
    formEl.addEventListener('change', function (e) {
      if (e.target.name === 'areaMode') {
        setMode(e.target.value);
      }
    });

    // Add another area row
    var addBtn = document.getElementById('sc-addrow');
    if (addBtn) addBtn.addEventListener('click', addRow);

    // Remove a row (event delegation)
    rowsEl.addEventListener('click', function (e) {
      var del = e.target.closest('[data-del]');
      if (del) removeRow(del);
    });

    // Calculate / submit
    formEl.addEventListener('submit', function (e) {
      e.preventDefault();
      var r = compute();
      render(r);
      // Scroll the results into view (gentle, only if off-screen)
      if (resultsEl.classList.contains('calculated')) {
        var rect = resultsEl.getBoundingClientRect();
        if (rect.bottom > window.innerHeight || rect.top < 0) {
          resultsEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }
    });

    // Clear button
    var clearBtn = document.getElementById('sc-clear');
    if (clearBtn) clearBtn.addEventListener('click', function () {
      resetForm();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
