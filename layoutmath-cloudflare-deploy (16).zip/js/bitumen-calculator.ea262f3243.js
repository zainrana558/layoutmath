/* Bitumen (tar) calculator — two-column layout (form LEFT, results RIGHT).
   Simplified inputs: radio toggle for area (total vs dimensions), an
   application type dropdown (prime/tack/seal coat) that sets a preset spray
   rate, an editable rate field, and an optional price per gallon.
   Results panel leads with GALLONS (or LITERS for metric), then plain-English
   WHAT THIS MEANS and WHAT TO DO sections. No live updates. */
(function () {
  'use strict';

  // ---------- Unit conversion tables ----------
  // All inputs are converted to a common internal unit (square feet for area,
  // gallons for volume). Results are converted out.

  // Length: factor to multiply by to get feet.
  var LEN_TO_FT = { ft: 1, m: 3.28084, yd: 3, in: 1 / 12, cm: 0.0328084 };
  // Area: factor to multiply by to get square feet.
  var AREA_TO_SQFT = { sqft: 1, sqm: 10.7639, sqyd: 9, acre: 43560 };
  // Square feet back to a target area unit.
  var SQFT_TO_AREA = { sqft: 1, sqm: 1 / 10.7639, sqyd: 1 / 9, acre: 1 / 43560 };
  var AREA_WORDS = { sqft: 'square feet', sqm: 'square meters', sqyd: 'square yards', acre: 'acres' };

  // Rate conversions to gal/yd² (internal canonical unit).
  // 1 gal/yd² = 4.527 L/m²  →  1 L/m² = 0.2209 gal/yd²
  var GALYD2_TO_LM2 = 4.527;
  var RATE_TO_GALYD2 = { galperyd2: 1, lperm2: 1 / GALYD2_TO_LM2 };
  // 1 US gallon = 3.78541 liters
  var GAL_TO_L = 3.78541;
  // Bitumen weight: specific gravity 1.03 × water 8.3454 lb/gal = 8.596 lb/gal.
  var LB_PER_GAL = 8.596;

  // Application type presets (gal/yd²) and prose.
  var APP_PRESETS = { prime: 0.30, tack: 0.10, seal: 0.15 };
  var APP_LABELS = { prime: 'prime coat', tack: 'tack coat', seal: 'seal coat' };
  var APP_MEANINGS = {
    prime: 'Prime coats help asphalt bond to the gravel base.',
    tack: 'Tack coats prevent delamination between layers.',
    seal: 'Seal coats protect the surface.'
  };

  // ---------- Helpers ----------
  function parseNum(str) {
    if (str == null) return null;
    var s = String(str).trim();
    if (!s) return null;
    s = s.replace(/[$,\s]/g, '').replace(/[′’]/g, "'").replace(/[″“”]/g, '"');
    s = s.replace(/½/g, ' 1/2').replace(/¼/g, ' 1/4').replace(/¾/g, ' 3/4')
         .replace(/⅛/g, ' 1/8').replace(/⅜/g, ' 3/8').replace(/⅝/g, ' 5/8').replace(/⅞/g, ' 7/8')
         .replace(/⅓/g, ' 1/3').replace(/⅔/g, ' 2/3');
    var m = s.match(/^(-?\d+(?:\.\d+)?)['′]\s*(\d+(?:\.\d+)?)["″]$/);
    if (m) return Number(m[1]) * 12 + Number(m[2]);
    m = s.match(/^(-?\d+)\s+(\d+)\/(\d+)$/);
    if (m) {
      var d = Number(m[3]);
      if (d === 0) return null;
      return Number(m[1]) + Number(m[2]) / d;
    }
    m = s.match(/^(-?\d+)\/(\d+)$/);
    if (m) {
      var d2 = Number(m[2]);
      if (d2 === 0) return null;
      return Number(m[1]) / d2;
    }
    if (!/^-?\d*\.?\d+$/.test(s)) return null;
    var n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  function fmt(n, d) {
    if (!Number.isFinite(n)) return '—';
    return Number(n.toFixed(d)).toString();
  }

  function fmtMoney(n, cur) {
    if (!Number.isFinite(n)) return '—';
    var sym = cur === 'GBP' ? '£' : cur === 'EUR' ? '€' : '$';
    return sym + n.toFixed(2);
  }

  // Money without trailing .00 — for per-unit prices ($4 not $4.00)
  function fmtMoneyPlain(n, cur) {
    if (!Number.isFinite(n)) return '—';
    var sym = cur === 'GBP' ? '£' : cur === 'EUR' ? '€' : '$';
    return sym + (Number.isInteger(n) ? String(n) : n.toFixed(2));
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function describeAreaWords(value, unit) {
    var v = (unit === 'acre') ? fmt(value, 2)
            : (value >= 100 ? fmt(value, 0) : fmt(value, 1));
    return v + ' ' + AREA_WORDS[unit];
  }

  // ---------- DOM ----------
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  // ---------- Row management for "Enter dimensions" ----------
  var MAX_ROWS = 5;
  function rowTemplate(idx) {
    var wrap = document.createElement('div');
    wrap.className = 'scalc-row';
    wrap.setAttribute('data-row', '');
    wrap.innerHTML =
      '<div class="field"><label for="sc-len-' + idx + '">Length</label>' +
        '<div class="inp">' +
          '<input id="sc-len-' + idx + '" name="len' + idx + '" type="text" inputmode="decimal" autocomplete="off" spellcheck="false" value="">' +
          '<select class="sc-unit" name="lenUnit' + idx + '" aria-label="Length unit">' +
            '<option value="ft" selected>ft</option><option value="m">m</option><option value="yd">yd</option><option value="in">in</option><option value="cm">cm</option>' +
          '</select>' +
        '</div>' +
      '</div>' +
      '<span class="scalc-x" aria-hidden="true">×</span>' +
      '<div class="field"><label for="sc-wid-' + idx + '">Width</label>' +
        '<div class="inp">' +
          '<input id="sc-wid-' + idx + '" name="wid' + idx + '" type="text" inputmode="decimal" autocomplete="off" spellcheck="false" value="">' +
          '<select class="sc-unit" name="widUnit' + idx + '" aria-label="Width unit">' +
            '<option value="ft" selected>ft</option><option value="m">m</option><option value="yd">yd</option><option value="in">in</option><option value="cm">cm</option>' +
          '</select>' +
        '</div>' +
      '</div>' +
      '<button type="button" class="scalc-del needs-js" data-del aria-label="Remove this area">&times;</button>';
    return wrap;
  }

  function refreshRowsUI() {
    var rows = $all('.scalc-row', rowsEl);
    var n = rows.length;
    rows.forEach(function (r) {
      var del = r.querySelector('[data-del]');
      if (del) del.hidden = (n <= 1);
    });
    var addBtn = $('#sc-addrow');
    if (addBtn) addBtn.hidden = (n >= MAX_ROWS);
    var help = $('.scalc-rowhelp');
    if (help) help.hidden = (n < 2);
  }

  function addRow() {
    var rows = $all('.scalc-row', rowsEl);
    if (rows.length >= MAX_ROWS) return;
    var idx = rows.length;
    var newRow = rowTemplate(idx);
    rowsEl.appendChild(newRow);
    refreshRowsUI();
    var inp = newRow.querySelector('input');
    if (inp) inp.focus();
  }

  function removeRow(btn) {
    var row = btn.closest('.scalc-row');
    if (!row || $all('.scalc-row', rowsEl).length <= 1) return;
    row.remove();
    refreshRowsUI();
  }

  // ---------- Area mode toggle ----------
  function setMode(mode) {
    $all('.scalc-section', formEl).forEach(function (sec) {
      sec.hidden = (sec.getAttribute('data-mode') !== mode);
    });
  }

  // ---------- Application type → rate sync ----------
  // When the application type dropdown changes, set the rate field to the
  // preset value (in the current rate unit). The user can still override it.
  function syncRateFromAppType() {
    var appSel = $('#sc-apptype');
    var rateInput = $('#sc-rate');
    var rateUnitSel = formEl.querySelector('[name="rateUnit"]');
    if (!appSel || !rateInput || !rateUnitSel) return;
    var appType = appSel.value;
    var presetGalYd2 = APP_PRESETS[appType];
    if (typeof presetGalYd2 !== 'number') return;
    if (rateUnitSel.value === 'lperm2') {
      rateInput.value = fmt(presetGalYd2 * GALYD2_TO_LM2, 3);
    } else {
      rateInput.value = fmt(presetGalYd2, 2);
    }
    prevRateUnit = rateUnitSel.value;
  }

  // When the rate UNIT changes, convert the existing rate value into the new
  // unit (so the actual application rate is preserved, not the number).
  var prevRateUnit = 'galperyd2';
  function onRateUnitChange(e) {
    var newUnit = e.target.value;
    var rateInput = $('#sc-rate');
    var rate = parseNum(rateInput.value);
    if (rate != null && rate > 0 && prevRateUnit && prevRateUnit !== newUnit) {
      var galYd2 = rate * RATE_TO_GALYD2[prevRateUnit];
      var newVal = (newUnit === 'lperm2') ? galYd2 * GALYD2_TO_LM2 : galYd2;
      rateInput.value = fmt(newVal, newUnit === 'lperm2' ? 3 : 2);
    }
    prevRateUnit = newUnit;
  }

  // ---------- Compute ----------
  function computeAreaSqft() {
    var mode = formEl.querySelector('input[name="areaMode"]:checked');
    mode = mode ? mode.value : 'total';
    if (mode === 'total') {
      var area = parseNum($('#sc-area').value);
      var areaUnit = formEl.querySelector('[name="areaUnit"]').value;
      if (area == null || area <= 0) return { ok: false, msg: 'Enter the area to cover.' };
      return {
        ok: true,
        sqft: area * AREA_TO_SQFT[areaUnit],
        describe: describeArea(area, areaUnit),
        primaryAreaValue: area,
        primaryAreaUnit: areaUnit
      };
    } else {
      var rows = $all('.scalc-row', rowsEl);
      var total = 0;
      var parts = [];
      var firstLenUnit = 'ft';
      for (var i = 0; i < rows.length; i++) {
        var len = parseNum(rows[i].querySelector('input[name^="len"]').value);
        var lenUnit = rows[i].querySelector('[name^="lenUnit"]').value;
        var wid = parseNum(rows[i].querySelector('input[name^="wid"]').value);
        var widUnit = rows[i].querySelector('[name^="widUnit"]').value;
        if (len == null || len <= 0 || wid == null || wid <= 0) {
          return { ok: false, msg: 'Enter length and width for every area.' };
        }
        var lf = len * LEN_TO_FT[lenUnit];
        var wf = wid * LEN_TO_FT[widUnit];
        total += lf * wf;
        parts.push(describeDim(len, lenUnit, wid, widUnit));
        if (i === 0) firstLenUnit = lenUnit;
      }
      var primaryAreaUnit = 'sqft';
      if (firstLenUnit === 'm' || firstLenUnit === 'cm') primaryAreaUnit = 'sqm';
      else if (firstLenUnit === 'yd') primaryAreaUnit = 'sqyd';
      var primaryAreaValue = total * SQFT_TO_AREA[primaryAreaUnit];
      return {
        ok: true,
        sqft: total,
        describe: parts.join(' + '),
        primaryAreaValue: primaryAreaValue,
        primaryAreaUnit: primaryAreaUnit
      };
    }
  }

  function describeArea(n, unit) {
    var labels = { sqft: 'ft²', sqm: 'm²', sqyd: 'yd²', acre: 'acres' };
    var v = (unit === 'acre') ? fmt(n, 2) : fmt(n, 0);
    return v + ' ' + labels[unit];
  }
  function describeDim(l, lu, w, wu) {
    var lbl = { ft: 'ft', m: 'm', yd: 'yd', in: 'in', cm: 'cm' };
    return fmt(l, 0) + lbl[lu] + ' × ' + fmt(w, 0) + lbl[wu];
  }

  function compute() {
    var areaRes = computeAreaSqft();
    if (!areaRes.ok) return areaRes;

    // Application type
    var appSel = $('#sc-apptype');
    var appType = appSel ? appSel.value : 'tack';
    if (!APP_PRESETS[appType]) appType = 'tack';

    // Spray rate
    var rateInput = $('#sc-rate');
    var rate = parseNum(rateInput.value);
    var rateUnit = formEl.querySelector('[name="rateUnit"]').value;
    if (rate == null || rate <= 0) return { ok: false, msg: 'Enter a spray rate greater than zero.' };

    // Convert rate to gal/yd² (canonical)
    var rateGalYd2 = rate * RATE_TO_GALYD2[rateUnit];

    // Area in square yards and square meters
    var sqft = areaRes.sqft;
    var sqyd = sqft / 9;
    var sqm = sqft / 10.7639;

    // Volume
    var gallons = sqyd * rateGalYd2;
    var liters = gallons * GAL_TO_L;

    // Weight (bitumen at SG 1.03)
    var lb = gallons * LB_PER_GAL;
    var tons = lb / 2000;

    // Optional price
    var priceInput = $('#sc-price');
    var price = parseNum(priceInput.value);
    var priceUnit = formEl.querySelector('[name="priceUnit"]').value;
    var hasPrice = (price != null && price >= 0 && priceInput.value.trim() !== '');

    var cost = null;
    if (hasPrice) {
      if (priceUnit === 'pergal') cost = gallons * price;
      else if (priceUnit === 'perliter') cost = liters * price;
    }

    // Metric lead if area is sqm OR rate is L/m²
    var isMetric = (areaRes.primaryAreaUnit === 'sqm' || rateUnit === 'lperm2');

    // Rate phrase for "what this means"
    var rateDesc = (rateUnit === 'lperm2')
      ? fmt(rate, 3) + ' liters per square meter'
      : fmt(rate, 2) + ' gallons per square yard';

    return {
      ok: true,
      gallons: gallons, liters: liters, lb: lb, tons: tons,
      cost: cost, hasPrice: hasPrice, price: price, priceUnit: priceUnit,
      areaDesc: areaRes.describe,
      appType: appType,
      rateDesc: rateDesc,
      rateValue: rate, rateUnit: rateUnit,
      primaryAreaValue: areaRes.primaryAreaValue,
      primaryAreaUnit: areaRes.primaryAreaUnit,
      isMetric: isMetric
    };
  }

  // ---------- Render ----------
  function renderEmptyState() {
    outEl.innerHTML =
      '<div class="scalc-empty">' +
        '<p>Enter the area and pick the application type, then click <b>Calculate</b>.</p>' +
        '<p>The answer will show:</p>' +
        '<ul>' +
          '<li>How many gallons (or liters) of bitumen to spray</li>' +
          '<li>What that means in plain English</li>' +
          '<li>What to do next</li>' +
        '</ul>' +
      '</div>';
  }

  function render(r) {
    if (!r.ok) {
      outEl.innerHTML = '<p class="scalc-err">' + esc(r.msg) + '</p>';
      resultsEl.classList.add('calculated');
      hidePeek();
      if (liveEl) liveEl.textContent = r.msg;
      return;
    }

    var gallons = r.gallons;
    var liters = r.liters;
    var lb = r.lb;
    var lbWord = (lb === 1) ? 'pound' : 'pounds';
    var areaPhrase = describeAreaWords(r.primaryAreaValue, r.primaryAreaUnit);
    var appLabel = APP_LABELS[r.appType];
    var appMeaning = APP_MEANINGS[r.appType];

    var html = '';

    // --- 1. Plain-English answer sentence (leads with gallons / liters) ---
    html += '<p class="scalc-answer">';
    if (r.isMetric) {
      html += 'You need about <span class="num">' + fmt(liters, 1) + ' liters</span> of bitumen ' +
              '(' + fmt(gallons, 2) + ' gallons, or ' + fmt(lb, 0) + ' ' + lbWord + ').';
    } else {
      html += 'You need about <span class="num">' + fmt(gallons, 1) + ' gallons</span> of bitumen ' +
              '(' + fmt(liters, 1) + ' liters, or ' + fmt(lb, 0) + ' ' + lbWord + ').';
    }
    html += '</p>';

    // --- 2. Cost line (only if a price was entered) ---
    if (r.hasPrice && r.cost != null) {
      var priceWord = r.priceUnit === 'pergal' ? 'gallon' : 'liter';
      html += '<p class="scalc-cost-line">At ' + esc(fmtMoneyPlain(r.price, 'USD')) + ' per ' +
              esc(priceWord) + ', the total cost is about <strong>' +
              esc(fmtMoney(r.cost, 'USD')) + '</strong>.</p>';
    }

    // --- 3. What this means ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What this means</h4>';
    var meaning = 'A ' + esc(appLabel) + ' at ' + esc(r.rateDesc) + ' over ' + esc(areaPhrase) +
                  ' uses this much bitumen. ' + appMeaning;
    html += '<p class="scalc-meaning">' + meaning + '</p>';

    // --- 4. What to do (bullets, not numbered) ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What to do</h4>';
    html += '<ul class="scalc-todo">';
    if (r.appType === 'seal') {
      html += '<li>For sealing driveways, use asphalt sealer &mdash; a different, easier product than hot bitumen</li>';
      html += '<li>Buy about ' + (r.isMetric ? fmt(liters, 0) + ' liters' : fmt(gallons, 0) + ' gallons') +
              ' of driveway sealer from a hardware store</li>';
      html += '<li>Apply with a squeegee in two thin coats &mdash; don&rsquo;t apply it thick</li>';
      html += '<li>Don&rsquo;t apply if rain is expected within 24 hours</li>';
      html += '<li>Wait 6 to 12 months after new asphalt is laid before sealing</li>';
    } else {
      html += '<li>This is a professional product &mdash; hire a paving contractor for ' + esc(appLabel) + 's</li>';
      if (r.appType === 'prime') {
        html += '<li>Prime coat is applied to the gravel base before asphalt to help bonding</li>';
      } else {
        html += '<li>Tack coat is applied between old and new asphalt layers to prevent delamination</li>';
      }
      html += '<li>Don&rsquo;t let traffic on a prime coat for 24 to 48 hours</li>';
      if (r.hasPrice && r.cost != null) {
        html += '<li>Budget about ' + esc(fmtMoney(r.cost, 'USD')) + ' for the binder at your price</li>';
      } else {
        html += '<li>Suppliers sell by the gallon, liter, ton or tonne &mdash; check which one your quote uses</li>';
      }
    }
    html += '</ul>';

    outEl.innerHTML = html;
    resultsEl.classList.add('calculated');

    // Peek button (floating "jump to result" bar)
    showPeek(r.isMetric ? (fmt(liters, 1) + ' liters') : (fmt(gallons, 1) + ' gallons'));

    // SR live region — short summary
    if (liveEl) {
      var srLead = r.isMetric ? (fmt(liters, 1) + ' liters') : (fmt(gallons, 1) + ' gallons');
      liveEl.textContent = 'You need about ' + srLead + ' of bitumen.';
    }
  }

  // ---------- Peek button ----------
  function showPeek(text) {
    if (!peekEl) return;
    var pv = $('.pv', peekEl);
    if (pv) pv.textContent = text;
    peekEl.removeAttribute('hidden');
    peekEl.classList.add('on');
  }
  function hidePeek() {
    if (!peekEl) return;
    peekEl.setAttribute('hidden', '');
    peekEl.classList.remove('on');
  }

  function clearResults() {
    resultsEl.classList.remove('calculated');
    renderEmptyState();
    hidePeek();
    if (liveEl) liveEl.textContent = '';
  }

  // ---------- Reset ----------
  function resetForm() {
    $('#sc-area').value = '600';
    formEl.querySelector('[name="areaUnit"]').value = 'sqft';
    var rows = $all('.scalc-row', rowsEl);
    for (var i = 1; i < rows.length; i++) rows[i].remove();
    var firstRow = rows[0];
    if (firstRow) {
      firstRow.querySelector('input[name^="len"]').value = '50';
      firstRow.querySelector('[name^="lenUnit"]').value = 'ft';
      firstRow.querySelector('input[name^="wid"]').value = '12';
      firstRow.querySelector('[name^="widUnit"]').value = 'ft';
    }
    var appSel = $('#sc-apptype');
    if (appSel) appSel.value = 'tack';
    formEl.querySelector('[name="rateUnit"]').value = 'galperyd2';
    prevRateUnit = 'galperyd2';
    $('#sc-rate').value = '0.10';
    $('#sc-price').value = '';
    formEl.querySelector('[name="priceUnit"]').value = 'pergal';
    var totalRadio = formEl.querySelector('input[name="areaMode"][value="total"]');
    if (totalRadio) totalRadio.checked = true;
    setMode('total');
    refreshRowsUI();
    clearResults();
  }

  // ---------- Init ----------
  var formEl, rowsEl, resultsEl, outEl, liveEl, peekEl;

  function init() {
    formEl = document.getElementById('calc');
    rowsEl = document.getElementById('sc-rows');
    resultsEl = document.getElementById('results');
    outEl = document.getElementById('out');
    liveEl = document.getElementById('live');
    peekEl = document.getElementById('peek');
    if (!formEl || !resultsEl || !outEl) return;

    refreshRowsUI();
    resultsEl.classList.remove('calculated');
    renderEmptyState();

    // Radio toggle for area mode
    formEl.addEventListener('change', function (e) {
      if (e.target.name === 'areaMode') {
        setMode(e.target.value);
      }
      if (e.target.id === 'sc-apptype') {
        syncRateFromAppType();
      }
    });

    // Rate unit change → convert the displayed rate value
    var rateUnitSel = formEl.querySelector('[name="rateUnit"]');
    if (rateUnitSel) {
      prevRateUnit = rateUnitSel.value || 'galperyd2';
      rateUnitSel.addEventListener('change', onRateUnitChange);
    }

    var addBtn = document.getElementById('sc-addrow');
    if (addBtn) addBtn.addEventListener('click', addRow);

    rowsEl.addEventListener('click', function (e) {
      var del = e.target.closest('[data-del]');
      if (del) removeRow(del);
    });

    formEl.addEventListener('submit', function (e) {
      e.preventDefault();
      var r = compute();
      render(r);
      if (resultsEl.classList.contains('calculated')) {
        var rect = resultsEl.getBoundingClientRect();
        if (rect.bottom > window.innerHeight || rect.top < 0) {
          resultsEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }
    });

    var clearBtn = document.getElementById('sc-clear');
    if (clearBtn) clearBtn.addEventListener('click', resetForm);

    if (peekEl) {
      peekEl.addEventListener('click', function () {
        if (resultsEl) resultsEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
