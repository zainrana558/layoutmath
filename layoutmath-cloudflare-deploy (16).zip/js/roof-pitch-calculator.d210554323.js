/* Roof pitch calculator — two-column layout (form LEFT, results RIGHT).
   Simplified inputs (rise + run, both inches, Calculate button).
   Results panel leads with the pitch ratio (e.g., "6:12 pitch"),
   shows angle in degrees and percent slope, then plain-English
   WHAT THIS MEANS and WHAT TO DO sections. No live updates. */
(function () {
  'use strict';

  // ---------- Helpers ----------
  // Parse a number from a text input. Accepts decimals ("6", "6.5"),
  // simple fractions ("3/4"), mixed fractions ("3 1/2"), the unicode
  // fraction characters (½, ¼, …), and feet+inches ("5' 6"" -> 66 inches).
  function parseNum(str) {
    if (str == null) return null;
    var s = String(str).trim();
    if (!s) return null;
    // Strip $ and commas, but keep internal whitespace (for mixed fractions).
    s = s.replace(/[$,]/g, '').replace(/[′’]/g, "'").replace(/[″“”]/g, '"');
    // Expand fraction characters with a leading space so they parse as mixed.
    s = s.replace(/½/g, ' 1/2').replace(/¼/g, ' 1/4').replace(/¾/g, ' 3/4')
         .replace(/⅛/g, ' 1/8').replace(/⅜/g, ' 3/8').replace(/⅝/g, ' 5/8').replace(/⅞/g, ' 7/8')
         .replace(/⅓/g, ' 1/3').replace(/⅔/g, ' 2/3');
    // "5' 6"" style -> feet + inches -> total inches
    var m = s.match(/^(-?\d+(?:\.\d+)?)['′]\s*(\d+(?:\.\d+)?)["″]$/);
    if (m) return Number(m[1]) * 12 + Number(m[2]);
    // Mixed fraction "3 1/2"
    m = s.match(/^(-?\d+)\s+(\d+)\/(\d+)$/);
    if (m) {
      var d = Number(m[3]);
      if (d === 0) return null;
      return Number(m[1]) + Number(m[2]) / d;
    }
    // Simple fraction "3/4"
    m = s.match(/^(-?\d+)\/(\d+)$/);
    if (m) {
      var d2 = Number(m[2]);
      if (d2 === 0) return null;
      return Number(m[1]) / d2;
    }
    // Plain decimal — strip any remaining internal spaces ("1 000" -> "1000")
    s = s.replace(/\s/g, '');
    if (!/^-?\d*\.?\d+$/.test(s)) return null;
    var n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  // Format a number with up to `d` decimals, trimming trailing zeros.
  function fmt(n, d) {
    if (!Number.isFinite(n)) return '—';
    return Number(n.toFixed(d)).toString();
  }

  // Format the pitch X value: integer if whole, else 1 decimal.
  function fmtPitch(n) {
    if (!Number.isFinite(n)) return '—';
    return Number(n.toFixed(1)).toString();
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ---------- Compute ----------
  // rise, run in inches. Returns pitch (X:12), angle (deg), percent slope,
  // a category ("low" | "common" | "steep"), and a short label for prose.
  function compute() {
    var rise = parseNum(riseInput.value);
    var run = parseNum(runInput.value);
    if (rise == null || rise < 0) {
      return { ok: false, msg: 'Enter a rise of zero or more.' };
    }
    if (run == null || run <= 0) {
      return { ok: false, msg: 'Enter a run greater than zero.' };
    }

    var ratio = rise / run;                       // rise per unit run
    var pitch = 12 * ratio;                       // X in X:12
    var angle = Math.atan(ratio) * 180 / Math.PI; // degrees
    var pct = 100 * ratio;                        // percent slope

    var category, label;
    if (pitch < 4) {
      category = 'low';
      label = 'a low slope';
    } else if (pitch < 10) {
      category = 'common';
      label = 'a common pitch';
    } else {
      category = 'steep';
      label = 'a steep roof';
    }

    return {
      ok: true,
      rise: rise, run: run,
      pitch: pitch, angle: angle, pct: pct,
      category: category, label: label
    };
  }

  // ---------- Render ----------
  function renderEmptyState() {
    outEl.innerHTML =
      '<div class="scalc-empty">' +
        '<p>Enter the rise and run, then click <b>Calculate</b>.</p>' +
        '<p>The answer will show:</p>' +
        '<ul>' +
          '<li>The roof pitch as X:12 (e.g., 6:12)</li>' +
          '<li>The angle in degrees and the percent slope</li>' +
          '<li>What that means and what to do next</li>' +
        '</ul>' +
      '</div>';
  }

  function render(r) {
    if (!r.ok) {
      outEl.innerHTML = '<p class="scalc-err">' + esc(r.msg) + '</p>';
      resultsEl.classList.add('calculated');
      if (liveEl) liveEl.textContent = r.msg;
      return;
    }

    var pitchStr = fmtPitch(r.pitch) + ':12';
    var angleStr = fmt(r.angle, 1);
    var pctStr = fmt(r.pct, 1);
    var riseStr = fmt(r.rise, 2);
    var runStr = fmt(r.run, 2);

    var html = '';

    // --- 1. Plain-English answer (leads with the pitch ratio) ---
    html += '<p class="scalc-answer">';
    html += 'A <span class="num">' + esc(pitchStr) + '</span> pitch &mdash; ' +
            esc(angleStr) + '&deg; (' + esc(pctStr) + '% slope).';
    html += '</p>';

    // --- 2. What this means ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What this means</h4>';
    html += '<p class="scalc-meaning">A roof with ' + esc(riseStr) + ' inches of rise over ' +
            esc(runStr) + ' inches of run has a ' + esc(pitchStr) + ' pitch &mdash; ' +
            esc(r.label) + '.</p>';

    // --- 3. What to do (bullets) ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What to do</h4>';
    html += '<ul class="scalc-todo">';
    if (r.category === 'low') {
      if (r.pitch <= 2) {
        // True low slope — shingles won't work.
        html += '<li>Use membrane roofing (torch-down, TPO, or EPDM) &mdash; shingles won&rsquo;t work below 2:12</li>';
        html += '<li>Ensure proper drainage &mdash; low slopes pool water if not perfectly flat</li>';
      } else {
        // Borderline (2:12 to under 4:12) — shingles can work with extra underlayment.
        html += '<li>Standard shingles can work, but follow the manufacturer&rsquo;s underlayment requirements closely (often double underlayment below 4:12)</li>';
        html += '<li>Add ice and water shield at eaves and valleys &mdash; borderline pitches are vulnerable to ice dams and wind-driven rain</li>';
      }
    } else if (r.category === 'common') {
      html += '<li>Standard asphalt shingles work well &mdash; follow manufacturer&rsquo;s underlayment requirements</li>';
      if (r.pitch <= 6) {
        html += '<li>Walkable with safety equipment up to about 6:12</li>';
      } else {
        html += '<li>Above 6:12, use roof jacks or a harness &mdash; too steep to walk safely</li>';
      }
    } else {
      // Steep (10:12 or more)
      html += '<li>Use scaffolding or roof jacks &mdash; too steep to walk safely</li>';
      html += '<li>Consider slate or tile &mdash; steep roofs shed water fast and show materials better</li>';
      html += '<li>Budget extra for labor &mdash; steep roofs take longer to install</li>';
    }
    html += '</ul>';

    outEl.innerHTML = html;
    resultsEl.classList.add('calculated');

    // SR live region — short summary
    if (liveEl) {
      liveEl.textContent = 'A ' + pitchStr + ' pitch roof — ' + angleStr +
                           ' degrees, ' + pctStr + ' percent slope, ' + r.label + '.';
    }
  }

  function clearResults() {
    resultsEl.classList.remove('calculated');
    renderEmptyState();
    if (liveEl) liveEl.textContent = '';
  }

  // ---------- Reset ----------
  function resetForm() {
    // Defaults match the static worked example (rise 6, run 12 -> 6:12).
    riseInput.value = '6';
    runInput.value = '12';
    clearResults();
  }

  // ---------- Init ----------
  var formEl, resultsEl, outEl, liveEl, riseInput, runInput;

  function init() {
    formEl = document.getElementById('calc');
    resultsEl = document.getElementById('results');
    outEl = document.getElementById('out');
    liveEl = document.getElementById('live');
    riseInput = document.getElementById('sc-rise');
    runInput = document.getElementById('sc-run');
    if (!formEl || !resultsEl || !outEl || !riseInput || !runInput) return;

    // Show the friendly empty state until Calculate is clicked.
    // (For noscript users, the static worked-example markup remains visible.)
    resultsEl.classList.remove('calculated');
    renderEmptyState();

    // Calculate / submit
    formEl.addEventListener('submit', function (e) {
      e.preventDefault();
      var r = compute();
      render(r);
      // Scroll the results into view (gentle, only if off-screen)
      if (resultsEl.classList.contains('calculated')) {
        var rect = resultsEl.getBoundingClientRect();
        if (rect.bottom > window.innerHeight || rect.top < 0) {
          resultsEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }
    });

    // Clear button
    var clearBtn = document.getElementById('sc-clear');
    if (clearBtn) clearBtn.addEventListener('click', resetForm);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
