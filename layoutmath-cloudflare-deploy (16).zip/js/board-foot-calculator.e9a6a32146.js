/* Board foot calculator — two-column layout (form LEFT, results RIGHT).
   Simplified inputs (radio toggle for single vs multiple boards, per-input
   unit dropdowns, Calculate button). Results panel leads with BOARD FEET,
   then plain-English WHAT THIS MEANS and WHAT TO DO sections, and an
   optional COST line. Units are spelled out. No live updates.

   Board foot = 144 cubic inches = 1 ft × 1 ft × 1 in.
   Per board: thickness(in) × width(in) × length(ft) / 12
            = thickness(in) × width(in) × length(in) / 144
*/
(function () {
  'use strict';

  // ---------- Unit conversion tables ----------
  // All inputs are converted to inches (for thickness/width) or feet (for length).
  // Thickness/width: factor to multiply by to get inches.
  var SMALL_TO_IN = { in: 1, mm: 1 / 25.4, cm: 1 / 2.54 };
  // Length: factor to multiply by to get feet.
  var LEN_TO_FT = { ft: 1, m: 3.28084, yd: 3, in: 1 / 12, cm: 0.0328084 };

  // ---------- Helpers ----------
  function parseNum(str) {
    if (str == null) return null;
    var s = String(str).trim();
    if (!s) return null;
    // Allow $ and common unit suffixes / fraction chars.
    s = s.replace(/[$,\s]/g, '').replace(/[′’]/g, "'").replace(/[″“”]/g, '"');
    s = s.replace(/½/g, ' 1/2').replace(/¼/g, ' 1/4').replace(/¾/g, ' 3/4')
         .replace(/⅛/g, ' 1/8').replace(/⅜/g, ' 3/8').replace(/⅝/g, ' 5/8').replace(/⅞/g, ' 7/8')
         .replace(/⅓/g, ' 1/3').replace(/⅔/g, ' 2/3');
    // "5' 6"" style or "5-6" style — treat as feet+inches if it has ' and "
    var m = s.match(/^(-?\d+(?:\.\d+)?)['′]\s*(\d+(?:\.\d+)?)["″]$/);
    if (m) return Number(m[1]) * 12 + Number(m[2]);
    // Mixed fraction like "3 1/2"
    m = s.match(/^(-?\d+)\s+(\d+)\/(\d+)$/);
    if (m) {
      var d = Number(m[3]);
      if (d === 0) return null;
      return Number(m[1]) + Number(m[2]) / d;
    }
    // Simple fraction "3/4"
    m = s.match(/^(-?\d+)\/(\d+)$/);
    if (m) {
      var d2 = Number(m[2]);
      if (d2 === 0) return null;
      return Number(m[1]) / d2;
    }
    // Plain decimal
    if (!/^-?\d*\.?\d+$/.test(s)) return null;
    var n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  function fmt(n, d) {
    if (!Number.isFinite(n)) return '—';
    return Number(n.toFixed(d)).toString();
  }

  function fmtMoney(n, cur) {
    if (!Number.isFinite(n)) return '—';
    var sym = cur === 'GBP' ? '£' : cur === 'EUR' ? '€' : '$';
    return sym + n.toFixed(2);
  }

  // Money without trailing .00 — for per-unit prices ($40 not $40.00)
  function fmtMoneyPlain(n, cur) {
    if (!Number.isFinite(n)) return '—';
    var sym = cur === 'GBP' ? '£' : cur === 'EUR' ? '€' : '$';
    return sym + (Number.isInteger(n) ? String(n) : n.toFixed(2));
  }

  function plural(n, sing) {
    return (n === 1) ? sing : sing + 's';
  }

  // ---------- Size formatting ----------
  // Format a size in inches for the "1×6" / "1.5×6.5" notation.
  // Whole inches become integers; fractional inches show 2 decimals (trimmed).
  function fmtInches(n) {
    if (!Number.isFinite(n)) return '—';
    if (Math.abs(n - Math.round(n)) < 1e-6) return String(Math.round(n));
    return fmt(n, 2);
  }

  // Format a length in feet for prose: "8 feet", "1 foot", "8.5 feet".
  function fmtLengthFeet(n) {
    if (!Number.isFinite(n)) return '—';
    if (Math.abs(n - Math.round(n)) < 1e-6) {
      var v = Math.round(n);
      return v + ' ' + (v === 1 ? 'foot' : 'feet');
    }
    return fmt(n, 2) + ' feet';
  }

  // ---------- DOM ----------
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  // ---------- Mode toggle ----------
  // "single" mode hides the quantity field; "multiple" mode shows it.
  function setMode(mode) {
    $all('.scalc-section', formEl).forEach(function (sec) {
      sec.hidden = (sec.getAttribute('data-mode') !== mode);
    });
  }

  // ---------- Compute ----------
  function compute() {
    var thickInput = $('#sc-thick');
    var thick = parseNum(thickInput.value);
    var thickUnit = formEl.querySelector('[name="thicknessUnit"]').value;
    if (thick == null || thick <= 0) return { ok: false, msg: 'Enter a board thickness greater than zero.' };

    var widthInput = $('#sc-width');
    var width = parseNum(widthInput.value);
    var widthUnit = formEl.querySelector('[name="widthUnit"]').value;
    if (width == null || width <= 0) return { ok: false, msg: 'Enter a board width greater than zero.' };

    var lengthInput = $('#sc-length');
    var length = parseNum(lengthInput.value);
    var lengthUnit = formEl.querySelector('[name="lengthUnit"]').value;
    if (length == null || length <= 0) return { ok: false, msg: 'Enter a board length greater than zero.' };

    var modeRadio = formEl.querySelector('input[name="boardMode"]:checked');
    var mode = modeRadio ? modeRadio.value : 'single';
    var qty = 1;
    if (mode === 'multiple') {
      var q = parseNum($('#sc-qty').value);
      if (q == null || q <= 0) return { ok: false, msg: 'Enter how many boards (1 or more).' };
      qty = Math.floor(q);
      if (qty < 1) return { ok: false, msg: 'Enter how many boards (1 or more).' };
    }

    // Optional price per board foot
    var priceInput = $('#sc-price');
    var price = parseNum(priceInput.value);
    var hasPrice = (price != null && price >= 0 && priceInput.value.trim() !== '');

    // Convert to inches / feet
    var thickIn = thick * SMALL_TO_IN[thickUnit];
    var widthIn = width * SMALL_TO_IN[widthUnit];
    var lengthFt = length * LEN_TO_FT[lengthUnit];

    // Board feet per board: thickness(in) × width(in) × length(ft) / 12
    var bfEach = (thickIn * widthIn * lengthFt) / 12;
    var totalBF = bfEach * qty;

    var cost = null;
    if (hasPrice) cost = totalBF * price;

    return {
      ok: true,
      bfEach: bfEach,
      totalBF: totalBF,
      qty: qty,
      mode: mode,
      cost: cost, hasPrice: hasPrice, price: price,
      thickIn: thickIn, widthIn: widthIn, lengthFt: lengthFt
    };
  }

  // ---------- Render ----------
  // Result panel layout (calculator.net-style):
  //   1. ONE plain-English sentence with the lead number bolded inline
  //   2. Optional cost line (only if a price was entered)
  //   3. "What this means" — 1-2 sentence explanation
  //   4. "What to do" — 3-4 short bullets (not numbered)
  function renderEmptyState() {
    outEl.innerHTML =
      '<div class="scalc-empty">' +
        '<p>Enter the thickness, width and length of your board, then click <b>Calculate</b>.</p>' +
        '<p>The answer will show:</p>' +
        '<ul>' +
          '<li>How many board feet of lumber to buy</li>' +
          '<li>What that means in plain English</li>' +
          '<li>What to do next</li>' +
        '</ul>' +
      '</div>';
  }

  function render(r) {
    if (!r.ok) {
      outEl.innerHTML = '<p class="scalc-err">' + esc(r.msg) + '</p>';
      resultsEl.classList.add('calculated');
      if (liveEl) liveEl.textContent = r.msg;
      return;
    }

    var totalBF = r.totalBF;
    var bfEach = r.bfEach;
    var qty = r.qty;
    var multiple = (r.mode === 'multiple' && qty > 1);

    // Size notation in inches (always), e.g. "1×6", "1.5×6.5", "2×4"
    var sizeStr = fmtInches(r.thickIn) + '×' + fmtInches(r.widthIn);
    var lengthStr = fmtLengthFeet(r.lengthFt);

    var html = '';

    // --- 1. Plain-English answer sentence (lead with BOARD FEET) ---
    html += '<p class="scalc-answer">';
    if (multiple) {
      html += 'Buy about <span class="num">' + fmt(totalBF, 1) + ' board feet</span> of ' +
              esc(sizeStr) + ' lumber (' + qty + ' ' + plural(qty, 'board') + ' at ' +
              fmt(bfEach, 2) + ' board feet each).';
    } else {
      html += 'Buy about <span class="num">' + fmt(totalBF, 2) + ' board feet</span> of ' +
              esc(sizeStr) + ' lumber.';
    }
    html += '</p>';

    // --- 2. Cost line (only if a price was entered) ---
    if (r.hasPrice && r.cost != null) {
      html += '<p class="scalc-cost-line">At ' + esc(fmtMoneyPlain(r.price, 'USD')) +
              ' per board foot, the total cost is about <strong>' +
              esc(fmtMoney(r.cost, 'USD')) + '</strong>.</p>';
    }

    // --- 3. What this means ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What this means</h4>';
    var meaning = 'A ' + esc(sizeStr) + ' board ' + esc(lengthStr) + ' long contains ' +
                  fmt(bfEach, 2) + ' board feet. ';
    if (multiple) {
      meaning += 'For ' + qty + ' ' + plural(qty, 'board') + ', that\u2019s ' +
                 fmt(totalBF, 1) + ' board feet total. ';
    }
    meaning += 'One board foot is 144 cubic inches &mdash; a piece 1 foot square by 1 inch thick.';
    html += '<p class="scalc-meaning">' + meaning + '</p>';

    // --- 4. What to do (bullets, not numbered) ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What to do</h4>';
    html += '<ul class="scalc-todo">';
    html += '<li>Buy ' + fmt(totalBF, 1) + ' board feet of ' + esc(sizeStr) + ' lumber</li>';
    html += '<li>For framing: use pressure-treated lumber for outdoor use, SPF for indoor</li>';
    html += '<li>Check each board for crown (bow) and install crown up</li>';
    html += '<li>Store lumber flat and dry until installation &mdash; don\u2019t let it warp</li>';
    html += '</ul>';

    outEl.innerHTML = html;
    resultsEl.classList.add('calculated');

    // SR live region — short summary
    if (liveEl) {
      liveEl.textContent = 'Buy about ' + fmt(totalBF, 1) + ' board feet of ' + sizeStr + ' lumber.';
    }
  }

  function clearResults() {
    resultsEl.classList.remove('calculated');
    renderEmptyState();
    if (liveEl) liveEl.textContent = '';
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ---------- Reset ----------
  function resetForm() {
    // Defaults match the static worked example.
    $('#sc-thick').value = '1';
    formEl.querySelector('[name="thicknessUnit"]').value = 'in';
    $('#sc-width').value = '6';
    formEl.querySelector('[name="widthUnit"]').value = 'in';
    $('#sc-length').value = '8';
    formEl.querySelector('[name="lengthUnit"]').value = 'ft';
    $('#sc-qty').value = '10';
    $('#sc-price').value = '';
    // Default mode = single
    var singleRadio = formEl.querySelector('input[name="boardMode"][value="single"]');
    if (singleRadio) singleRadio.checked = true;
    setMode('single');
    clearResults();
  }

  // ---------- Init ----------
  var formEl, resultsEl, outEl, liveEl;

  function init() {
    formEl = document.getElementById('calc');
    resultsEl = document.getElementById('results');
    outEl = document.getElementById('out');
    liveEl = document.getElementById('live');
    if (!formEl || !resultsEl || !outEl) return;

    // Show the friendly empty state in the results panel until Calculate is clicked.
    // (For noscript users, the static worked-example markup remains visible.)
    resultsEl.classList.remove('calculated');
    renderEmptyState();

    // Radio toggle for board mode
    formEl.addEventListener('change', function (e) {
      if (e.target.name === 'boardMode') {
        setMode(e.target.value);
      }
    });

    // Calculate / submit
    formEl.addEventListener('submit', function (e) {
      e.preventDefault();
      var r = compute();
      render(r);
      // Scroll the results into view (gentle, only if off-screen)
      if (resultsEl.classList.contains('calculated')) {
        var rect = resultsEl.getBoundingClientRect();
        if (rect.bottom > window.innerHeight || rect.top < 0) {
          resultsEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }
    });

    // Clear button
    var clearBtn = document.getElementById('sc-clear');
    if (clearBtn) clearBtn.addEventListener('click', function () {
      resetForm();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
