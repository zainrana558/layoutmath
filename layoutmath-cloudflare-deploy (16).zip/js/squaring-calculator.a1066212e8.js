/* Squaring calculator — two-column layout (form LEFT, results RIGHT).
   Two length inputs (side A, side B). Results panel leads with the
   DIAGONAL LENGTH (Pythagorean theorem: diagonal = sqrt(a² + b²)),
   then plain-English WHAT THIS MEANS and WHAT TO DO sections, and the
   classic 3-4-5 quick-check tip. Units are spelled out. No live updates. */
(function () {
  'use strict';

  // ---------- Unit conversion tables ----------
  // All inputs are converted to feet for the Pythagorean calculation,
  // then converted back out for display.

  // Length: factor to multiply by to get feet.
  var LEN_TO_FT = { ft: 1, m: 3.28084, yd: 3, in: 1 / 12, cm: 0.0328084 };
  // Feet back to a target length unit.
  var FT_TO_LEN = { ft: 1, m: 1 / 3.28084, yd: 1 / 3, in: 12, cm: 1 / 0.0328084 };

  // Spelled-out labels for prose (singular / plural).
  var LEN_LABELS = {
    ft: { one: 'foot',  many: 'feet'  },
    m:  { one: 'meter', many: 'meters' },
    yd: { one: 'yard',  many: 'yards'  },
    in: { one: 'inch',  many: 'inches' },
    cm: { one: 'cm',    many: 'cm'     }
  };

  // ---------- Helpers ----------
  function parseNum(str) {
    if (str == null) return null;
    var s = String(str).trim();
    if (!s) return null;
    // Allow $ and common unit suffixes / fraction chars.
    s = s.replace(/[$,\s]/g, '').replace(/[′’]/g, "'").replace(/[″“”]/g, '"');
    s = s.replace(/½/g, ' 1/2').replace(/¼/g, ' 1/4').replace(/¾/g, ' 3/4')
         .replace(/⅛/g, ' 1/8').replace(/⅜/g, ' 3/8').replace(/⅝/g, ' 5/8').replace(/⅞/g, ' 7/8')
         .replace(/⅓/g, ' 1/3').replace(/⅔/g, ' 2/3');
    // "5' 6"" style — treat as feet+inches (inches, regardless of selected unit,
    // because the ' and " marks are explicit). Returns inches.
    var m = s.match(/^(-?\d+(?:\.\d+)?)['′]\s*(\d+(?:\.\d+)?)["″]$/);
    if (m) return Number(m[1]) * 12 + Number(m[2]);
    // "5 6" style (feet inches) when input is a feet unit — interpret as feet+inches.
    // Only applies when there is a space-separated second number; we already stripped
    // spaces above, so this branch is for "6-6" dash style.
    m = s.match(/^(-?\d+(?:\.\d+)?)-(\d+(?:\.\d+)?)$/);
    if (m) return Number(m[1]) * 12 + Number(m[2]);
    // Mixed fraction like "3 1/2"
    m = s.match(/^(-?\d+)\s+(\d+)\/(\d+)$/);
    if (m) {
      var d = Number(m[3]);
      if (d === 0) return null;
      return Number(m[1]) + Number(m[2]) / d;
    }
    // Simple fraction "3/4"
    m = s.match(/^(-?\d+)\/(\d+)$/);
    if (m) {
      var d2 = Number(m[2]);
      if (d2 === 0) return null;
      return Number(m[1]) / d2;
    }
    // Plain decimal
    if (!/^-?\d*\.?\d+$/.test(s)) return null;
    var n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  function fmt(n, d) {
    if (!Number.isFinite(n)) return '—';
    return Number(n.toFixed(d)).toString();
  }

  // Spelled-out length for prose: "6 feet", "1 foot", "8 inches", "1.83 meters".
  function describeLen(n, unit) {
    var v = (unit === 'in' || unit === 'cm') ? fmt(n, 1) : fmt(n, 2);
    var labels = LEN_LABELS[unit] || LEN_LABELS.ft;
    var lbl = (Number(v) === 1) ? labels.one : labels.many;
    return v + ' ' + lbl;
  }

  // Short form for the peek pill: "10 ft", "8 in", "5 m".
  function describeLenShort(n, unit) {
    var v = (unit === 'in' || unit === 'cm') ? fmt(n, 1) : fmt(n, 2);
    return v + ' ' + unit;
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ---------- DOM ----------
  function $(sel, root) { return (root || document).querySelector(sel); }

  // ---------- Compute ----------
  // Detect whether the user typed an explicit feet+inches string (e.g. "5' 6"",
  // "5-6", "6′"). When they do, parseNum returns INCHES, and we treat the value
  // as feet for both calculation and display (the ' / " marks override the
  // unit dropdown). Otherwise the parsed value is in the selected dropdown unit.
  function isFeetInchesNotation(raw) {
    return /['′″"”]|-\d/.test(String(raw == null ? '' : raw).trim());
  }

  function resolveSide(raw, unit) {
    if (isFeetInchesNotation(raw)) {
      // parseNum returned inches — convert to feet. Display unit is feet.
      return { ft: (parseNum(raw) / 12), dispUnit: 'ft' };
    }
    var v = parseNum(raw);
    return { ft: v * LEN_TO_FT[unit], dispUnit: unit, val: v };
  }

  function compute() {
    var aRaw = $('#sc-a').value;
    var aUnit = formEl.querySelector('[name="aUnit"]').value;
    var bRaw = $('#sc-b').value;
    var bUnit = formEl.querySelector('[name="bUnit"]').value;

    var a = parseNum(aRaw);
    var b = parseNum(bRaw);

    if (a == null || a <= 0) return { ok: false, msg: 'Enter a length for side A greater than zero.' };
    if (b == null || b <= 0) return { ok: false, msg: 'Enter a length for side B greater than zero.' };

    var A = resolveSide(aRaw, aUnit);
    var B = resolveSide(bRaw, bUnit);

    var aFt = A.ft;
    var bFt = B.ft;
    var diagFt = Math.sqrt(aFt * aFt + bFt * bFt);

    // Display each side in its own unit; the diagonal follows side A's unit
    // (the primary side).
    var aDispUnit = A.dispUnit;
    var bDispUnit = B.dispUnit;
    var dUnit = aDispUnit;

    var aDisp = aFt * FT_TO_LEN[aDispUnit];
    var bDisp = bFt * FT_TO_LEN[bDispUnit];
    var dDisp = diagFt * FT_TO_LEN[dUnit];

    return {
      ok: true,
      a: aDisp, aUnit: aDispUnit,
      b: bDisp, bUnit: bDispUnit,
      diagonal: dDisp, dUnit: dUnit
    };
  }

  // ---------- Render ----------
  // Simplified, calculator.net-style result panel:
  //   1. ONE plain-English sentence with the lead number bolded inline
  //   2. "What this means" — 1-2 sentence explanation
  //   3. "What to do" — 4 short bullets (not numbered)
  // No stat cards. No competing big numbers. Just clean text.
  function renderEmptyState() {
    outEl.innerHTML =
      '<div class="scalc-empty">' +
        '<p>Enter side A and side B from the corner, then click <b>Calculate</b>.</p>' +
        '<p>The answer will show:</p>' +
        '<ul>' +
          '<li>The diagonal length that makes the corner square</li>' +
          '<li>What that means in plain English</li>' +
          '<li>What to do next</li>' +
        '</ul>' +
      '</div>';
  }

  function render(r) {
    if (!r.ok) {
      outEl.innerHTML = '<p class="scalc-err">' + esc(r.msg) + '</p>';
      resultsEl.classList.add('calculated');
      if (liveEl) liveEl.textContent = r.msg;
      return;
    }

    var aDesc = describeLen(r.a, r.aUnit);
    var bDesc = describeLen(r.b, r.bUnit);
    var dDesc = describeLen(r.diagonal, r.dUnit);

    var html = '';

    // --- 1. Plain-English answer sentence ---
    html += '<p class="scalc-answer">For a corner with side A at <span class="num">' +
            esc(aDesc) + '</span> and side B at <span class="num">' + esc(bDesc) +
            '</span>, the diagonal should be <span class="num">' + esc(dDesc) +
            '</span> for a perfect square corner.</p>';

    // --- 2. What this means ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What this means</h4>';
    html += '<p class="scalc-meaning">Measure both sides and the diagonal &mdash; if the diagonal matches this number, the corner is square. The 3-4-5 method uses any triangle in the ratio 3:4:5; you can scale it up for bigger corners.</p>';

    // --- 3. What to do (bullets, not numbered) ---
    html += '<div class="scalc-sep"></div>';
    html += '<h4 class="scalc-sec-h">What to do</h4>';
    html += '<ul class="scalc-todo">';
    html += '<li>Mark side A at ' + esc(aDesc) + ' and side B at ' + esc(bDesc) + ' from the corner</li>';
    html += '<li>Measure the diagonal &mdash; it should be ' + esc(dDesc) + ' for a square corner</li>';
    html += '<li>If the diagonal is too long, push the sides in; if too short, pull them out</li>';
    html += '<li>For a quick check: use a 3-4-5 triangle (3 feet, 4 feet, 5 feet diagonal) &mdash; multiply by 2 or 3 for larger corners</li>';
    html += '</ul>';

    outEl.innerHTML = html;
    resultsEl.classList.add('calculated');

    // SR live region — short summary
    if (liveEl) {
      liveEl.textContent = 'The diagonal should be ' + dDesc + ' for a square corner.';
    }

    // Update the peek pill value (pill is hidden by default, but populate in case)
    var peek = document.getElementById('peek');
    if (peek) {
      var pv = peek.querySelector('.pv');
      if (pv) pv.textContent = describeLenShort(r.diagonal, r.dUnit);
    }
  }

  function clearResults() {
    resultsEl.classList.remove('calculated');
    renderEmptyState();
    if (liveEl) liveEl.textContent = '';
  }

  // ---------- Reset ----------
  function resetForm() {
    // Defaults match the static worked example (6 ft × 8 ft → 10 ft diagonal).
    $('#sc-a').value = '6';
    formEl.querySelector('[name="aUnit"]').value = 'ft';
    $('#sc-b').value = '8';
    formEl.querySelector('[name="bUnit"]').value = 'ft';
    clearResults();
  }

  // ---------- Init ----------
  var formEl, resultsEl, outEl, liveEl;

  function init() {
    formEl = document.getElementById('calc');
    resultsEl = document.getElementById('results');
    outEl = document.getElementById('out');
    liveEl = document.getElementById('live');
    if (!formEl || !resultsEl || !outEl) return;

    // Show the friendly empty state in the results panel until Calculate is clicked.
    // (For noscript users, the static worked-example markup remains visible.)
    resultsEl.classList.remove('calculated');
    renderEmptyState();

    // Calculate / submit
    formEl.addEventListener('submit', function (e) {
      e.preventDefault();
      var r = compute();
      render(r);
      // Scroll the results into view (gentle, only if off-screen)
      if (resultsEl.classList.contains('calculated')) {
        var rect = resultsEl.getBoundingClientRect();
        if (rect.bottom > window.innerHeight || rect.top < 0) {
          resultsEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }
    });

    // Clear button
    var clearBtn = document.getElementById('sc-clear');
    if (clearBtn) clearBtn.addEventListener('click', function () {
      resetForm();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
